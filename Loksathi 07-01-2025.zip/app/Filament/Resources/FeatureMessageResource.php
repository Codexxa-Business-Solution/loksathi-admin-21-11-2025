<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FeatureMessageResource\Pages;
use App\Filament\Resources\FeatureMessageResource\RelationManagers;
use App\Models\FeatureMessage;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;

class FeatureMessageResource extends Resource
{
    protected static ?string $model = FeatureMessage::class;

    protected static ?string $navigationIcon = 'heroicon-o-collection';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Select::make('group_message_id')
                    ->searchable()
                    ->relationship('message', 'name')
                    ->required(),
                TextInput::make('index')
                    ->numeric()
                    ->required()
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('message.name')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('index'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListFeatureMessages::route('/'),
            'create' => Pages\CreateFeatureMessage::route('/create'),
            'edit' => Pages\EditFeatureMessage::route('/{record}/edit'),
        ];
    }
}
