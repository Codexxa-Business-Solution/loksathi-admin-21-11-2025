<?php

namespace App\Jobs;

use App\Enums\GroupType;
use App\Models\Group;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class UpdateGroupMessageCount implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    //
    public function __construct()
    {
        //
    }

    //
    public function handle()
    {

        // group
        $groups = Group::all();

        foreach ($groups as $group) {

            // update message count
            switch ($group->type) {
                case GroupType::TYPE_GROUP:
                case GroupType::TYPE_POEM:
                case GroupType::TYPE_ARTICLE:
                    $group->group_message_count = $group->messages()
                        ->where('is_published', true)
                        ->where('scheduled_at', '<', Carbon::now())
                        ->count();
                    break;
                case GroupType::TYPE_QUIZ:
                    $group->group_message_count = $group->quiz_messages()
                        ->where('is_published', true)
                        ->where('scheduled_at', '<', Carbon::now())
                        ->count();
                    break;
                case GroupType::TYPE_BLOOD_GROUP:
                    $group->group_message_count = $group->blood_messages()
                        ->where('is_published', true)
                        ->count();
                    break;
                case GroupType::TYPE_BUY_SELL:
                    $group->group_message_count = $group->buy_messages()
                        ->where('is_published', true)
                        ->count();
                    break;
                case GroupType::TYPE_DISCUSS:
                    $group->group_message_count = $group->discuss_messages()
                        ->where('is_published', true)
                        ->count();
                    break;
            }

            // save
            $group->save();

        }


    }
}
