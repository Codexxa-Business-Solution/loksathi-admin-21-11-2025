<?php

namespace App\Jobs;

use App\Models\GroupMessage;
use App\Models\News;
use App\Models\QuizMessage;
use App\Models\Status;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendPushNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    //
    public function __construct()
    {
        //
    }

    //
    public function handle()
    {

        // group notifications
        $groupMessages = GroupMessage::query()
            ->with('group')
            ->where('is_published', true)
            ->where('is_scheduled', true)
            ->where('is_notified', true)
            ->whereBetween('scheduled_at', [Carbon::now()->subMinutes(2), Carbon::now()])
            ->get();

        // quiz notifications
        $quizMessages = QuizMessage::query()
            ->with('group')
            ->where('is_published', true)
            ->where('is_scheduled', true)
            ->where('is_notified', true)
            ->whereBetween('scheduled_at', [Carbon::now()->subMinutes(2), Carbon::now()])
            ->get();

        // status notifications
        $statuses = Status::query()
            ->where('is_scheduled', true)
            ->where('is_notified', true)
            ->whereBetween('scheduled_at', [Carbon::now()->subMinutes(2), Carbon::now()])
            ->get();

        // news notifications
        $news = News::query()
            ->where('is_published', true)
            ->where('is_scheduled', true)
            ->where('is_notified', true)
            ->whereBetween('scheduled_at', [Carbon::now()->subMinutes(2), Carbon::now()])
            ->get();

        // --------------------------------
        // send group message notifications
        foreach ($groupMessages as $groupMessage) {
            PushService::sendGroupMessageNotification($groupMessage);
        }

        // send quiz message notifications
        foreach ($quizMessages as $quizMessage) {
            PushService::sendQuizMessageNotification($quizMessage);
        }

        // send status notifications
        foreach ($statuses as $status) {
            PushService::sendStatusNotification($status);
        }

        // send news notifications
        foreach ($news as $new) {
            PushService::sendNewsNotification($new);
        }


    }
}
