<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class BuySellMessageResource extends JsonResource
{
    //
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'images' => $this->images,
            'description' => $this->description,
            'comment_count' => $this->comment_count,
            'display_time' => $this->display_time,
            'whatsapp_number' => $this->whatsapp_number,
            'type' => $this->type,
            'group' => [
                'id' => $this->group->id,
                'name' => $this->group->name,
            ],
            'user' => [
                'id' => $this->user->id,
                'name' => $this->user->name,
                'phone' => $this->user->phone,
                'email' => $this->user->email,
                'image' => $this->user->image,
            ]
        ];
    }
}
