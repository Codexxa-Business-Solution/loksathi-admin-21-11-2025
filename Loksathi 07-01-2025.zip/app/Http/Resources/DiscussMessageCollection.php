<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class DiscussMessageCollection extends ResourceCollection
{
    //
    public function toArray($request): array
    {
        return [
            'data' => DiscussMessageResource::collection($this->items()),
            "current_page" => $this->currentPage(),
            "from" => $this->firstItem(),
            "next_page_url" => $this->nextPageUrl(),
            "path" => $this->path(),
            "per_page" => $this->perPage(),
            "prev_page_url" => $this->previousPageUrl(),
            "to" => $this->lastItem(),
        ];
    }
}
