<?php

namespace App\Http\Livewire\Admin\Featured;

use App\Enums\AppConstants;
use App\Enums\FeaturedType;
use App\Models\FeaturedPodcast;
use App\Models\Podcast;
use App\Models\PodcastCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;
use Livewire\Component;
use Livewire\WithFileUploads;

class PodcastCreate extends Component
{

    use WithFileUploads;

    public $image;
    public $podcasts = array();
    public $podcastCategories = array();
    public $podcastType = FeaturedType::TYPE_ITEM;
    public $featuredPodcast;
    public $featuredPodcastId;
    public $featuredPodcastCategoryId;

    public function render()
    {
        $this->podcasts = Podcast::all();
        $this->podcastCategories = PodcastCategory::all();
        if (count($this->podcasts) > 0)
            $this->featuredPodcastId = $this->podcasts[0]['id'];
        if (count($this->podcastCategories) > 0)
            $this->featuredPodcastCategoryId = $this->podcastCategories[0]['id'];
        return view('livewire.admin.featured.podcast-create');
    }

    // store
    public function store()
    {

        if ($this->podcastType == FeaturedType::TYPE_ITEM) {
            if (!$this->featuredPodcastId) {
                Session::flash("error", "Please select podcast first");
                return;
            }
        } else if ($this->podcastType == FeaturedType::TYPE_CATEGORY) {
            if (!$this->featuredPodcastCategoryId) {
                Session::flash("error", "Please select podcast category first");
                return;
            }
        }

        // image
        $featuredPodcast = new FeaturedPodcast();
        $featuredPodcast->type = $this->podcastType;
        $featuredPodcast->podcast_id = $this->featuredPodcastId;
        $featuredPodcast->podcast_category_id = $this->featuredPodcastCategoryId;

        $bunnyCdnStorage = new BunnyCdnStorage();
        $name = $bunnyCdnStorage->uploadLivewire($this->image, AppConstants::FEATURED_DIR_NAME);
        $featuredPodcast->image = $name;

        $featuredPodcast->save();

        Session::flash("success", "Featured Podcast Saved Successfully.");

    }

}
