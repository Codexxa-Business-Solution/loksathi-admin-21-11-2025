<?php

namespace App\Http\Livewire\Admin\Featured;

use App\Enums\AppConstants;
use App\Enums\FeaturedType;
use App\Models\FeaturedProduct;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;
use Livewire\Component;
use Livewire\WithFileUploads;

class ProductCreate extends Component
{

    use WithFileUploads;

    public $image;
    public $products = array();
    public $productCategories = array();
    public $productType = FeaturedType::TYPE_ITEM;
    public $featuredPodcast;
    public $featuredProductId;
    public $featuredProductCategoryId;

    public function render()
    {
        $this->products = Product::all();
        $this->productCategories = ProductCategory::all();
        if (count($this->products) > 0)
            $this->featuredProductId = $this->products[0]['id'];
        if (count($this->productCategories) > 0)
            $this->featuredProductCategoryId = $this->productCategories[0]['id'];
        return view('livewire.admin.featured.product-create');
    }

    // store
    public function store()
    {

        if ($this->productType == FeaturedType::TYPE_ITEM) {
            if (!$this->featuredProductId) {
                Session::flash("error", "Please select product first");
                return;
            }
        } else if ($this->productType == FeaturedType::TYPE_CATEGORY) {
            if (!$this->featuredProductCategoryId) {
                Session::flash("error", "Please select product category first");
                return;
            }
        }

        // image
        $featuredProduct = new FeaturedProduct();
        $featuredProduct->type = $this->productType;
        $featuredProduct->product_id = $this->featuredProductId;
        $featuredProduct->product_category_id = $this->featuredProductCategoryId;

        $bunnyCdnStorage = new BunnyCdnStorage();
        $name = $bunnyCdnStorage->uploadLivewire($this->image, AppConstants::FEATURED_DIR_NAME);
        $featuredProduct->image = $name;

        $featuredProduct->save();

        Session::flash("success", "Featured Product Saved Successfully.");

    }

}
