<?php

namespace App\Http\Livewire\Admin\Quizzes;

use App\Enums\GroupType;
use App\Models\Group;
use App\Models\QuizCategory;
use App\Models\QuizMessage;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use Livewire\Component;

class Create extends Component
{

    public $quizId;
    public $quiz;
    public $quizCategories;
    public $quizGroups;
    public $questions = array();
    public $quizCategory;
    public $quizGroup;
    public $name;
    public $message;
    public $index;
    public $is_notified = false;
    public $is_published = false;
    public $is_pinned = false;
    public $is_scheduled = false;
    public $scheduled_at;

    public function mount()
    {

        $this->quizId = request()->get('quizId');
        $this->quiz = QuizMessage::find($this->quizId);

        // setup
        $this->setupQuiz();

    }

    public function render()
    {
        $this->quizCategories = QuizCategory::all();
        $this->quizGroups = Group::where('type', GroupType::TYPE_QUIZ)->get();
        if (!$this->quizCategory)
            if (count($this->quizCategories) > 0)
                $this->quizCategory = $this->quizCategories[0]->id;
        if (!$this->quizGroup)
            if (count($this->quizGroups) > 0)
                $this->quizGroup = $this->quizGroups[0]->id;
        return view('livewire.admin.quizzes.create');
    }

    // setup endpoint if endpoint id not null
    private function setupQuiz()
    {
        if ($this->quiz != null) {
            $this->name = $this->quiz->name;
            $this->quizCategory = $this->quiz->quiz_category_id;
            $this->quizGroup = $this->quiz->quiz_group_id;
            $this->index = $this->quiz->index;
            $this->message = $this->quiz->message;
            $this->is_published = $this->quiz->is_published;
            $this->is_notified = $this->quiz->is_notified;
            $this->is_pinned = $this->quiz->is_pinned;
            $this->is_scheduled = $this->quiz->is_scheduled;
            $this->scheduled_at = Carbon::parse($this->quiz->scheduled_at)->format('d/m/Y g:i A');
            if ($this->quiz->questions) {
                $this->questions = $this->quiz->questions;
            } else {
                $this->addNewQuizQuestion();
                $this->addNewQuizQuestion();
            }
        } else {
            $this->addNewQuizQuestion();
            $this->addNewQuizQuestion();
        }

    }

    // add new parameter
    public function addNewQuizQuestion()
    {
        $this->questions[] = [
            'question' => '',
            'choices' => array('', '', '', ''),
            'answer' => '',
            'hint' => '',
        ];
    }

    public function addNewChoiceToQuestion($questionId)
    {
        $this->questions[$questionId]['choices'][] = '';
    }

    // add new parameter
    public function removeQuizQuestion($id)
    {
        unset($this->questions[$id]);
    }

    public function removeChoiceToQuestion($questionId, $id)
    {
        unset($this->questions[$questionId]['choices'][$id]);
        $newArray = array_values($this->questions[$questionId]['choices']);
        $this->questions[$questionId]['choices'] = $newArray;
    }

    public function store()
    {

        if ($this->quiz == null) {
            $this->quiz = new QuizMessage();
        }

        $this->quiz->quiz_category_id = $this->quizCategory;
        $this->quiz->quiz_group_id = $this->quizGroup;
        $this->quiz->index = $this->index;
        $this->quiz->name = $this->name;
        $this->quiz->message = $this->message;
        $this->quiz->is_notified = $this->is_notified;
        $this->quiz->is_pinned = $this->is_pinned;
        $this->quiz->is_published = $this->is_published;
        $this->quiz->is_scheduled = $this->is_scheduled;
        if (!$this->scheduled_at) {
            $this->scheduled_at = Carbon::now();
        }
        $this->quiz->scheduled_at = Carbon::parse($this->scheduled_at);
        $this->quiz->save();


        // send instant push notification
        if (!$this->quiz->is_scheduled && $this->quiz->is_notified && $this->quiz->is_published) {
            PushService::sendQuizMessageNotification($this->quiz);
        }

        $this->quizId = $this->quiz->id;

    }

    public function storeQuestions()
    {

        // store quiz first
        $this->store();

        if ($this->quiz != null) {

            $this->quiz->questions = $this->questions;
            $this->quiz->save();

            $this->emit('question_save');

            Session::flash('success', 'Quiz saved successfully');

        }

    }

}
