<?php

namespace App\Http\Livewire\Admin\Products;

use App\Enums\AppConstants;
use App\Enums\ProductType;
use App\Models\Podcast;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Livewire\Component;
use Livewire\WithFileUploads;
use Ramsey\Uuid\Uuid;

class Create extends Component
{

    use WithFileUploads;

    public $productId;
    public $productCategory;
    public $productCategories;
    public $productName;
    public $productDescription;
    public $productImage;
    public $productSku;
    public $productIndex;
    public $productType = ProductType::TYPE_BOOK;
    public $product;
    public $variants = array();
    public $is_published = false;
    public $is_upcoming = false;
    public $is_featured = false;
    public $podcasts = array();
    public $podcastId;

    public function mount()
    {

        $this->productId = request()->get('productId');
        $this->product = Product::find($this->productId);

        // setup
        $this->setupProduct();

    }

    // setup product
    private function setupProduct()
    {

        if ($this->product != null) {
            $this->productCategory = $this->product->product_category_id;
            $this->productType = $this->product->type;
            $this->productIndex = $this->product->index;
            $this->productName = $this->product->name;
            $this->productSku = $this->product->sku_id;
            $this->productDescription = $this->product->message;
            $this->is_upcoming = $this->product->is_upcoming;
            $this->is_featured = $this->product->is_featured;
            $this->is_published = $this->product->is_published;
            if ($this->product->variants) {
                $this->variants = $this->convertVariants();
            } else {
                $this->addNewVariant();
            }
        } else {
            $this->addNewVariant();
        }

    }

    private function convertVariants(): array
    {
        $variants = array();
        foreach ($this->product->variants as $variant) {

            if ($this->productType == ProductType::TYPE_BOOK) {
                $variants[$variant['sku']] = array(
                    'price' => $this->safeArrayValue($variant, 'price'),
                    'quantity' => $this->safeArrayValue($variant, 'quantity'),
                    'publication_name' => $this->safeArrayValue($variant, 'publication_name'),
                );
            }

            if ($this->productType == ProductType::TYPE_SHIRT) {
                $variants[$variant['sku']] = array(
                    'price' => $this->safeArrayValue($variant, 'price'),
                    'quantity' => $this->safeArrayValue($variant, 'quantity'),
                    'size' => $this->safeArrayValue($variant, 'size'),
                    'color' => $this->safeArrayValue($variant, 'color')
                );
            }
        }
        return $variants;
    }

    public function render()
    {
        $this->productCategories = ProductCategory::all();
        $this->podcasts = Podcast::all();
        if (!$this->productCategory)
            if (count($this->productCategories) > 0)
                $this->productCategory = $this->productCategories[0]->id;
        return view('livewire.admin.products.create');
    }

    // setup default
    public function addNewVariant()
    {

        $sku = 'VR' . Str::replace("-", "", Str::upper(Uuid::uuid4()));

        if ($this->productType == ProductType::TYPE_BOOK) {
            $this->variants[$sku] = [
                'price' => '',
                'quantity' => '',
                'publication_name' => '',
            ];
        }

        if ($this->productType == ProductType::TYPE_SHIRT) {
            $this->variants[$sku] = [
                'price' => '',
                'quantity' => '',
                'size' => '',
                'color' => ''
            ];
        }

    }

    // remove variants
    public function removeVariants($variantId)
    {
        unset($this->variants[$variantId]);
    }

    // add variants
    public function addVariants()
    {
        $this->addNewVariant();
    }

    // store product
    public function store()
    {

        if ($this->product == null) {
            $this->product = new Product();
        }

        $sku = Str::replace("-", "", Str::upper(Uuid::uuid4()));

        $this->product->product_category_id = $this->productCategory;
        $this->product->type = $this->productType;
        $this->product->index = $this->productIndex;
        $this->product->name = $this->productName;
        $this->product->message = $this->productDescription;
        $this->product->sku_id = 'SMB' . $sku;
        $this->product->is_upcoming = $this->is_upcoming;
        $this->product->is_featured = $this->is_featured;
        $this->product->is_published = $this->is_published;

        if ($this->productImage) {
            $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUploadLivewire($this->productImage, AppConstants::PRODUCT_DIR_NAME, $this->product->image);
            $this->product->image = $name;
        }

        $this->product->save();

        $this->productId = $this->product->id;

    }

    // store variants
    public function storeVariants()
    {

        if (count($this->variants) > 1 && $this->productType = ProductType::TYPE_BOOK) {
            Session::flash('error', 'Product type book only has single variant.');
            return;
        }

        if ($this->product != null) {

            $variants = array();
            foreach ($this->variants as $key => $variant) {
                $variants[] = array(
                    'sku' => $key,
                    'price' => $this->safeArrayValue($variant, 'price'),
                    'quantity' => $this->safeArrayValue($variant, 'quantity'),
                    'size' => $this->safeArrayValue($variant, 'size'),
                    'color' => $this->safeArrayValue($variant, 'color'),
                    'publication_name' => $this->safeArrayValue($variant, 'publication_name'),
                );
            }

            $this->product->variants = $variants;
            $this->product->save();

            Session::flash('success', 'Product saved successfully');

        }

    }

    // store variants
    public function associatePodcast()
    {

        if ($this->product != null) {

            $this->product->podcast_id = $this->podcastId;
            $this->product->save();

            Session::flash('success', 'Product saved successfully');

        }

    }

    // safe array
    private function safeArrayValue($array, $key)
    {
        if (array_key_exists($key, $array)) {
            return $array[$key];
        }
        return null;
    }

}
