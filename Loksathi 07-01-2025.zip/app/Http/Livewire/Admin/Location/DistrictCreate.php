<?php

namespace App\Http\Livewire\Admin\Location;

use Livewire\Component;

class DistrictCreate extends Component
{
    public function render()
    {
        return view('livewire.admin.location.district-create');
    }
}
