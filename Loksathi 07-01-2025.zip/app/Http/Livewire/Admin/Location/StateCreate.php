<?php

namespace App\Http\Livewire\Admin\Location;

use Livewire\Component;

class StateCreate extends Component
{
    public function render()
    {
        return view('livewire.admin.location.state-create');
    }
}
