<?php

namespace App\Http\Livewire\Admin\Location;

use Livewire\Component;

class TalukaCreate extends Component
{
    public function render()
    {
        return view('livewire.admin.location.taluka-create');
    }
}
