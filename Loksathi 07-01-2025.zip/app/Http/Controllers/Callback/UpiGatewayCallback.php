<?php

namespace App\Http\Controllers\Callback;

use App\Enums\PaymentStatus;
use App\Http\Controllers\Controller;
use App\Models\PlanPurchase;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class UpiGatewayCallback extends Controller
{
    //
    public function __invoke(Request $request)
    {
        //
        \Log::debug("data callback = " . json_encode($request->all()));


        if ($request->get('udf1') == 'plan_purchase') {

            // business
            $planPurchase = PlanPurchase::where('order_id', $request->get('client_txn_id'))
                ->first();

            if ($planPurchase) {

                if ($request->get('status') == 'success') {

                    // plan purchase update
                    $planPurchase->status = PaymentStatus::STATUS_PAID;
                    $planPurchase->expired_at = Carbon::today()->addDays($planPurchase->plan_days);
                    $planPurchase->save();

                    //
                    $user = $planPurchase->user;
                    $user->is_premium = true;
                    $user->plan_expired_at = Carbon::today()->addDays($planPurchase->plan_days);
                    $user->save();

                    // send notification
                    PushService::sendPlanNotification($user, $user->name . ", Your Plan Is Activated! Now Enjoy Full App");

                }

            }

        }

    }
}
