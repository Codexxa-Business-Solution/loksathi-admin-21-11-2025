<?php

namespace App\Http\Controllers;

use App\Models\News;
use App\Models\GroupMessage;
use App\Models\Status;
use App\Models\Business;
use App\Models\Group;
use App\Models\Comment;
use App\Models\Podcast;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\JobListing;


class RouterController extends Controller
{
    public function __invoke(Request $request)
    {
        return $this->index($request);
    }

    public function index(Request $request)
    {
        $type = $request->get('s');
        $metaTags = $this->getDefaultMetaTags();

        try {
            switch ($type) {
                case 'news':
                    $metaTags = $this->getNewsMetaTags($request);
                    break;
                
                case 'group_message':
                    $metaTags = $this->getGroupMessageMetaTags($request);
                    break;
                
                case 'job_listings':
                    $metaTags = $this->getJobListingMetaTags($request);
                    break;
                    
                case 'extras':
                    $metaTags = $this->getExtraMetaTags($request);
                    break;
                
                case 'quiz_message':
                    $metaTags = $this->getQuizMessageMetaTags($request);
                    break;
                
                case 'status':
                    $metaTags = $this->getStatusMetaTags($request);
                    break;
                
                case 'podcast':
                    $metaTags = $this->getPodcastMetaTags($request);
                    break;
                
                case 'business':
                    $metaTags = $this->getBusinessMetaTags($request);
                    break;
                
                case 'blood_message':
                    $metaTags = $this->getBloodMessageMetaTags($request);
                    break;
                
                case 'buy_sell_message':
                    $metaTags = $this->getBuySellMessageMetaTags($request);
                    break;
                
                case 'discuss_message':
                    $metaTags = $this->getDiscussMessageMetaTags($request);
                    break;
                
                case 'comment':
                    $metaTags = $this->getCommentMetaTags($request);
                    break;
                
                case 'live_video':
                    $metaTags = $this->getLiveVideoMetaTags($request);
                    break;
                
                default:
                    // Use default meta tags for unknown types
                    break;
            }
        } catch (\Exception $e) {
            Log::error('Router error: ' . $e->getMessage());
            // Use default meta tags on error
        }

        return view('router.index', compact('metaTags', 'request'));
    }

    private function getNewsMetaTags(Request $request)
    {
        $newsId = $request->get('news_id');
        $news = News::find($newsId);

        if (!$news) {
            return $this->getDefaultMetaTags();
        }

        $imageUrl = $news->image ? 'https://loksathinews.in/' . $news->image : 'https://loksathinews.in/default-share-image.jpg';
        $description = strip_tags($news->message) ?: 'Read the latest news on Loksathi';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => $news->name ?: 'Loksathi News',
            'description' => $description,
            'image' => $imageUrl,
            'url' => $request->fullUrl(),
            'type' => 'article',
            'site_name' => 'Loksathi News'
        ];
    }
    
    
    private function getJobListingMetaTags(Request $request)
    {
        $job_listings_id = $request->get('job_listings_id');
        $jobs = JobListing::find($job_listings_id);

        if (!$jobs) {
            return $this->getDefaultMetaTags();
        }

        $imageUrl = $jobs->image ? 'https://loksathinews.in/' . $jobs->image : 'https://loksathinews.in/default-share-image.jpg';
        $description = strip_tags($jobs->description) ?: 'Read the latest news on Loksathi';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => $jobs->notification_title ?: 'Loksathi News',
            'description' => $description,
            'image' => $imageUrl,
            'url' => $request->fullUrl(),
            'type' => 'article',
            'site_name' => 'Loksathi News'
        ];
    }
    
    
    
   
    private function getExtraMetaTags(Request $request)
    {
        $job_listings_id = $request->get('extras_id');
        $jobs = Business::find($job_listings_id);

        if (!$jobs) {
            return $this->getDefaultMetaTags();
        }

        $imageUrl = $jobs->image ? 'https://loksathinews.in/' . $jobs->image : 'https://loksathinews.in/default-share-image.jpg';
        $description = strip_tags($jobs->description) ?: 'Read the latest news on Loksathi';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => $jobs->notification_title ?: 'Loksathi News',
            'description' => $description,
            'image' => $imageUrl,
            'url' => $request->fullUrl(),
            'type' => 'article',
            'site_name' => 'Loksathi News'
        ];
    }
   
    
    

    private function getGroupMessageMetaTags(Request $request)
    {
        $groupId = $request->get('group_id');
        $messageId = $request->get('message_id');
        $groupMessage = GroupMessage::find($messageId);

        if (!$groupMessage) {
            return $this->getDefaultMetaTags();
        }

        $group = Group::find($groupId);
        $groupName = $group ? $group->name : 'Group';
        $imageUrl = $groupMessage->file ? 'https://loksathinews.in/' . $groupMessage->file : 'https://loksathinews.in/default-share-image.jpg';
        $description = strip_tags($groupMessage->name) ?: 'Shared by Loksathi APP';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => $groupMessage->notification_title ?: $groupName . ' Message',
            'description' => $description,
            'image' => $imageUrl,
            'url' => $request->fullUrl(),
            'type' => 'website',
            'site_name' => 'Loksathi News'
        ];
    }

    private function getQuizMessageMetaTags(Request $request)
    {
        $groupId = $request->get('group_id');
        $messageId = $request->get('message_id');
        
        // For quiz messages, we'll use similar logic to group messages
        return $this->getGroupMessageMetaTags($request);
    }

    private function getStatusMetaTags(Request $request)
    {
        $statusId = $request->get('status_id');
        $status = Status::find($statusId);

        if (!$status) {
            return $this->getDefaultMetaTags();
        }

        $imageUrl = $status->file ? 'https://loksathinews.in/' . $status->file : 'https://loksathinews.in/default-share-image.jpg';
        $description = strip_tags($status->name) ?: 'Check out this status on Loksathi';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => $status->notification_title ?: 'Loksathi Status',
            'description' => $description,
            'image' => $imageUrl,
            'url' => $request->fullUrl(),
            'type' => 'website',
            'site_name' => 'Loksathi News'
        ];
    }

    private function getPodcastMetaTags(Request $request)
    {
        $podcastId = $request->get('podcast_id');
        $podcast = Podcast::find($podcastId);

        if (!$podcast) {
            $metaTags = $this->getDefaultMetaTags();
            $metaTags['title'] = 'Loksathi Podcast';
            $metaTags['description'] = 'Listen to podcasts on Loksathi';
            $metaTags['type'] = 'music.song';
            return $metaTags;
        }

        $imageUrl = $podcast->image ? 'https://loksathinews.in/' . $podcast->image : 'https://loksathinews.in/default-share-image.jpg';
        $description = strip_tags($podcast->description ?? '') ?: 'Listen to this podcast on Loksathi';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => $podcast->name ?: 'Loksathi Podcast',
            'description' => $description,
            'image' => $imageUrl,
            'url' => $request->fullUrl(),
            'type' => 'music.song',
            'site_name' => 'Loksathi News'
        ];
    }

    private function getBusinessMetaTags(Request $request)
    {
        $metaTags = $this->getDefaultMetaTags();
        $metaTags['title'] = 'Business Listing - Loksathi';
        $metaTags['description'] = 'Discover local businesses on Loksathi';
        
        return $metaTags;
    }

    private function getBloodMessageMetaTags(Request $request)
    {
        $metaTags = $this->getDefaultMetaTags();
        $metaTags['title'] = 'Blood Donation Request - Loksathi';
        $metaTags['description'] = 'Help save lives through blood donation';
        
        return $metaTags;
    }

    private function getBuySellMessageMetaTags(Request $request)
    {
        $metaTags = $this->getDefaultMetaTags();
        $metaTags['title'] = 'Buy/Sell - Loksathi';
        $metaTags['description'] = 'Buy and sell items in your local community';
        
        return $metaTags;
    }

    private function getDiscussMessageMetaTags(Request $request)
    {
        $metaTags = $this->getDefaultMetaTags();
        $metaTags['title'] = 'Community Discussion - Loksathi';
        $metaTags['description'] = 'Join the community discussion on Loksathi';
        
        return $metaTags;
    }

    private function getCommentMetaTags(Request $request)
    {
        $commentId = $request->get('comment_id');
        $comment = Comment::find($commentId);

        if (!$comment) {
            return $this->getDefaultMetaTags();
        }

        $description = strip_tags($comment->comment) ?: 'View comment on Loksathi';
        $description = strlen($description) > 160 ? substr($description, 0, 157) . '...' : $description;

        return [
            'title' => 'Comment - Loksathi',
            'description' => $description,
            'image' => 'https://loksathinews.in/default-share-image.jpg',
            'url' => $request->fullUrl(),
            'type' => 'website',
            'site_name' => 'Loksathi News'
        ];
    }

    private function getLiveVideoMetaTags(Request $request)
    {
        return [
            'title' => 'Live Video - Loksathi',
            'description' => 'Watch live video on Loksathi News',
            'image' => 'https://loksathinews.in/default-share-image.jpg',
            'url' => $request->fullUrl(),
            'type' => 'video.other',
            'site_name' => 'Loksathi News'
        ];
    }

    private function getDefaultMetaTags()
    {
        return [
            'title' => 'Loksathi News',
            'description' => 'Stay updated with local news and community messages',
            'image' => 'https://loksathinews.in/default-share-image.jpg',
            'url' => 'https://loksathinews.in',
            'type' => 'website',
            'site_name' => 'Loksathi News'
        ];
    }
}