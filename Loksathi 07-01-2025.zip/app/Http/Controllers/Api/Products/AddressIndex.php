<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AddressIndex extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        // user
        $user = auth()->user();
        $addresses = $user->addresses;
        return $this->success('Addresses has fetched successfully', $addresses);

    }
}
