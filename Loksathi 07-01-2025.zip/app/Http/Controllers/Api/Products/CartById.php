<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Cart;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CartById extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // user
        $user = auth()->user();

        // get cart item
        $cartItem = Cart::query()
            ->with('product')
            ->where('id', $id)
            ->where('user_id', $user->id)
            ->first();

        if (!$cartItem) {
            return $this->failed(__('messages.cart_add_product_not_found'));
        }

        return $this->success(__('messages.cart_updated_success'), $cartItem);

    }
}
