<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\PodcastCategory;
use App\Models\ProductCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use function __;

class ProductsByCategory extends BaseApiController
{
    //
    public function __invoke(Request $request, $categoryId): JsonResponse
    {

        // product category
        $productCategory = ProductCategory::query()
            ->where('is_published', true)
            ->with('products')
            ->find($categoryId);

        return $this->success(__('messages.product_by_category_success'), $productCategory);

    }
}
