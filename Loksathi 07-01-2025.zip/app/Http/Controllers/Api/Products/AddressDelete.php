<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Address;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AddressDelete extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();
        $address = Address::find($id);

        if (!$address || $address->user_id != $user->id) {
            return $this->failed(__('messages.address_add_success'));
        }

        // delete
        $address->delete();

        return $this->success(__('messages.address_deleted_success'), null);

    }
}
