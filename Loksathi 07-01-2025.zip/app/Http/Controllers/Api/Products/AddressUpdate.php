<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Products\StoreAddressRequest;
use App\Models\Address;
use Illuminate\Http\JsonResponse;

class AddressUpdate extends BaseApiController
{
    //
    public function __invoke(StoreAddressRequest $request, $id): JsonResponse
    {

        $user = auth()->user();
        $address = Address::find($id);

        if (!$address || $address->user_id != $user->id) {
            return $this->failed(__('messages.address_add_success'));
        }

        $address->user_id = $user->id;
        $address->name = $request->get('name', $address->name);
        $address->type = $request->get('type', $address->type);
        $address->mobile_number = $request->get('mobile_number', $address->mobile_number);
        $address->line_one = $request->get('line_one', $address->line_one);
        $address->line_two = $request->get('line_two', $address->line_two);
        $address->line_three = $request->get('line_three', $address->line_three);
        $address->pincode = $request->get('pincode', $address->pincode);
        $address->state = $request->get('state', $address->state);
        $address->city = $request->get('city', $address->city);
        $address->save();

        // return
        return $this->success(__('messages.address_updated_success'), $address);

    }
}
