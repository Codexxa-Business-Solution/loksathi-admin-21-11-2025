<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Cart;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CartGet extends BaseApiController
{
    //
    public function __invoke(Request $request, $id, $variantId): JsonResponse
    {

        // user
        $user = auth()->user();

        // get cart item
        $cartItem = Cart::query()
            ->with('product')
            ->where('product_id', $id)
            ->where('variant_id', $variantId)
            ->where('user_id', $user->id)
            ->first();

        if (!$cartItem) {
            return $this->failed(__('messages.cart_add_product_not_found'));
        }

        if (!($cartItem->quantity > 0)) {
            return $this->failed(__('messages.cart_add_product_not_found'));
        }

        return $this->success(__('messages.cart_updated_success'), $cartItem);

    }
}
