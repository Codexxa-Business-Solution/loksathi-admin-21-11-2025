<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\FeaturedProduct;
use App\Models\ProductCategory;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        try {

            // featured products
            $featuredProducts = FeaturedProduct::query()
                ->get();

            // product categories
            $productCategories = ProductCategory::query()
                ->where('is_published', true)
                ->get();

            // list categories to show on podcast home page
            $categories = array(0, 1, 2, 3, 4, 5, 6);
            $productByCategories = array();
            foreach ($categories as $category) {
                $productCategory = ProductCategory::query()
                    ->where('is_published', true)
                    ->with('products')
                    ->find($category);

                if ($productCategory)
                    $productByCategories[] = $productCategory;
            }

            $response = [
                'featuredProducts' => $featuredProducts,
                'productCategories' => $productCategories,
                'productByCategories' => $productByCategories,
            ];

            return $this->success(__('messages.products_index_success'), $response);

        } catch (Exception $exception) {

            return $this->failed(__('messages.products_index_failed'), $exception->getMessage());

        }

    }
}
