<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Products\StoreAddressRequest;
use App\Models\Address;
use Illuminate\Http\JsonResponse;

class AddressStore extends BaseApiController
{
    //
    public function __invoke(StoreAddressRequest $request): JsonResponse
    {

        // user
        $user = auth()->user();

        // address
        $address = new Address();
        $address->user_id = $user->id;
        $address->name = $request->get('name');
        $address->type = $request->get('type', 'other');
        $address->mobile_number = $request->get('mobile_number');
        $address->line_one = $request->get('line_one');
        $address->line_two = $request->get('line_two');
        $address->line_three = $request->get('line_three');
        $address->pincode = $request->get('pincode');
        $address->state = $request->get('state');
        $address->city = $request->get('city');
        $address->save();

        // return
        return $this->success(__('messages.address_add_success'), $address);

    }
}
