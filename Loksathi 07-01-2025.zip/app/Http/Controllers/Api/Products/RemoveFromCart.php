<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Cart;
use Illuminate\Http\Request;

class RemoveFromCart extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): \Illuminate\Http\JsonResponse
    {
        // user
        $user = auth()->user();

        // get cart item
        $cartItem = Cart::query()
            ->where('id', $id)
            ->where('user_id', $user->id)
            ->first();

        if (!$cartItem) {
            return $this->failed(__('messages.cart_add_product_not_found'));
        }

        $cartItem->delete();

        return $this->success(__('messages.cart_updated_success'), null);
    }
}
