<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Products\AddToCartRequest;
use App\Models\Cart;
use App\Models\Product;
use Illuminate\Http\JsonResponse;

class AddToCart extends BaseApiController
{
    //
    public function __invoke(AddToCartRequest $request): JsonResponse
    {

        $user = auth()->user();
        $productId = $request->get('product_id');
        $variantId = $request->get('variant_id');

        $product = Product::find($productId);

        // check product exists
        if (!$product) {
            return $this->failed(__('messages.cart_add_product_not_found'));
        }

        //check variant exists
        $variant = null;
        foreach ($product->variants as $tempVariant) {
            if ($tempVariant['sku'] == $variantId) {
                $variant = $tempVariant;
            }
        }

        if (!$variant) {
            return $this->failed(__('messages.cart_add_variant_not_found'));
        }

        $cartItem = Cart::query()
            ->with('product')
            ->where('user_id', $user->id)
            ->where('product_id', $productId)
            ->where('variant_id', $variantId)
            ->first();

        if (!$cartItem) {
            $cartItem = new Cart();
            $cartItem->user_id = $user->id;
            $cartItem->product_id = $productId;
            $cartItem->variant_id = $variantId;
            $cartItem->variant = $variant;
        }

        $cartItem->quantity = $request->get('quantity');
        $cartItem->save();

        return $this->success(__('messages.cart_add_success'), $cartItem);

    }
}
