<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Cart;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CartIndex extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        $user = auth()->user();

        $cartItems = Cart::query()
            ->where('user_id', $user->id)
            ->with('product')
            ->get();

        return $this->success(__('messages.cart_index_success'), $cartItems);

    }
}
