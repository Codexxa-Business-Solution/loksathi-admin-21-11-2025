<?php

namespace App\Http\Controllers\Api\Products;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductGet extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $product = Product::query()
            ->find($id);

        // not found
        if (!$product) {
            return $this->failed(__('messages.products_get_success'));
        }

        return $this->success(__('messages.products_get_success'), $product);

    }
}
