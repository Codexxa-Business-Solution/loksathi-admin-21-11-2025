<?php

namespace App\Http\Controllers\Api\Group;

use App\Enums\AppConstants;
use App\Enums\GroupMessageType;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Group\SubmitMessageRequest;
use App\Models\Group;
use App\Models\GroupMessage;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\File;

class Submit extends BaseApiController
{
    //
    public function __invoke(SubmitMessageRequest $request): JsonResponse
    {

        $user = auth()->user();

        $group = Group::find($request->get('group_id'));
        if (!$group)
            return $this->failed(__('messages.submit_message_failed'));

        $todayMessage = GroupMessage::whereDate('scheduled_at', Carbon::now())
            ->where('group_id', '=', $group->id)
            ->where('user_id', '=', $user->id)
            ->first();

        if (!$todayMessage) {

            $groupMessage = new GroupMessage();
            $groupMessage->user_id = $user->id;
            $groupMessage->group_id = $request->get('group_id');
            $groupMessage->type = GroupMessageType::TYPE_IMAGE;
            $groupMessage->name = $request->get('title');
            $groupMessage->message = $request->get('message');
            $groupMessage->owner_name = $request->get('name');
            $groupMessage->owner_phone = $request->get('phone');
            $groupMessage->message = $request->get('message');
            $groupMessage->is_published = true;
            $groupMessage->scheduled_at = Carbon::now();
            $groupMessage->save();

            // images
            $images = $request->get('images');
            if ($images) {
                $decodedImages = json_decode($images);
                $bunnyImages = [];
                foreach ($decodedImages as $image) {
                    $decBase64Image = base64_decode($image->value);
                    /*$bunnyCdnStorage = new BunnyCdnStorage();
                    $name = $bunnyCdnStorage->uploadApi($image->name, $decBase64Image, AppConstants::BUYSELL_DIR_NAME);
                    $bunnyImages[] = $name;*/
                    
                    $name = md5(microtime()) . '.' . $image->name;
                    File::put(AppConstants::MESSAGE_DIR_NAME . $name, $decBase64Image);
                    
                    // $name = $bunnyCdnStorage->uploadApi($image->name, $decBase64Image, AppConstants::PROFILE_DIR_NAME);
                    $bunnyImages[] = AppConstants::MESSAGE_DIR_NAME . $name;
                }
                $groupMessage->images = json_encode($bunnyImages);
                $groupMessage->save();
            }

            return $this->success(__('messages.submit_message_success'), $groupMessage);
        } else {
            return $this->failed(__('messages.submit_message_limit'));
        }

    }
}
