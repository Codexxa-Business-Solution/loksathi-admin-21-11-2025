<?php

namespace App\Http\Controllers\Api\Group;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Group;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Show extends BaseApiController
{
    // group init invoke
    public function __invoke(Request $request, $id): JsonResponse
    {
        // message id
        $group = Group::query()->find($id);
        return $this->success("Group fetched successfully.", $group);
    }
}
