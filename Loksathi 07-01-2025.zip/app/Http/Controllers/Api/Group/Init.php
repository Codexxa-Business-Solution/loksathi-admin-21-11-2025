<?php

namespace App\Http\Controllers\Api\Group;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\GroupMessage;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Init extends BaseApiController
{
    // group init invoke
    public function __invoke(Request $request, $id): JsonResponse
    {

        // message id
        $messageId = $request->get('message_id');

        // query
        $messagesQuery = GroupMessage::query();

        // check filter
        if ($messageId)
            $messagesQuery->where('id', $messageId);

        // query
        $messages = $messagesQuery->with('user')
            ->where('group_id', $id)
            ->where('is_published', true)
            ->where('scheduled_at', '<', Carbon::now())
            ->orderBy('scheduled_at', 'desc')
            ->simplePaginate(30);

        return $this->success(__('messages.group_init_success'), $messages);

    }
}
