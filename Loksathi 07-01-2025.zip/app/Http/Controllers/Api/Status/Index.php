<?php

namespace App\Http\Controllers\Api\Status;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Status;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // status groups
        $statuses = Status::query()
            ->where('status_group_id', $id)
            ->with('group')
            ->where('scheduled_at', '<', Carbon::now())
            ->orderBy('scheduled_at', 'desc')
            ->orderBy('id', 'asc')
            ->simplePaginate(30);

        $dateStatuses = collect($statuses->items())->groupBy(function ($item) {
            return Carbon::parse($item->scheduled_at)->format('Y-m-d');
        });
        
        $view = DB::table('status_views')
                ->select('statuses.id')
                ->join('statuses', 'statuses.id', '=', 'status_id')
                ->where('status_group_id', $id)
                ->where('status_views.user_id', auth()->user()->id)
                ->get()
                ->pluck('id')
                ->toArray();

        $dateStatusesFinal = array();
        foreach ($dateStatuses as $index => $temps) {

            $dummyStatuses = array();

            foreach (collect($temps)->sortBy('scheduled_at') as $temp) {
                $temp->read = in_array($temp->id, $view);
                $dummyStatuses[] = $temp;
            }

            //
            $dateStatusesFinal[] = array(
                'date' => $index,
                'statuses' => $dummyStatuses,
            );
        }

        $responseStatus = array(
            "current_page" => $statuses->currentPage(),
            "from" => $statuses->firstItem(),
            "next_page_url" => $statuses->nextPageUrl(),
            "path" => $statuses->path(),
            "per_page" => $statuses->perPage(),
            "prev_page_url" => $statuses->previousPageUrl(),
            "to" => $statuses->lastItem(),
            "data" => $dateStatusesFinal
        );

        // return response
        return $this->success(__('messages.start_success'), $responseStatus);

    }

}
