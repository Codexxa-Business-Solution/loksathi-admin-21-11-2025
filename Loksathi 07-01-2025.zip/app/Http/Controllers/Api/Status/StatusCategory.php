<?php

namespace App\Http\Controllers\Api\Status;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Status;
use App\Models\StatusGroup;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class StatusCategory extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {
        // status groups
        $language = $this->getLanguage($request);
        $statusGroups = StatusGroup::query()
            ->where('language_id', $language->id)
            ->orderBy('index', 'asc')
            ->get();

        // return response
        return $this->success(__('messages.start_success'), $statusGroups);
    }
}
