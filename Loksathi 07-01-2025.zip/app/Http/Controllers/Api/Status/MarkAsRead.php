<?php

namespace App\Http\Controllers\Api\Status;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Status;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MarkAsRead extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {
        $user = auth()->user();
        $status = Status::query()->find($id);

        if (!$status)
            return $this->failed(__('Status not found.'));

        $status->markAsRead($user);

        return $this->success(__('Status marked as read'), null);
    }
}
