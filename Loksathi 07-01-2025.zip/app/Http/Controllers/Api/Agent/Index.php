<?php

namespace App\Http\Controllers\Api\Agent;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Agent;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    public function __invoke(Request $request): JsonResponse
    {
        $agent = Agent::where('agent_code', $request->get('agent_code'))->select('id', 'agent_code')->get();

        if ($agent->isEmpty()) {
            return $this->success(__('Agent Not Found'), []);
        }
    
        return $this->success(__('Agents Code Verified : '), $agent);
    }

}
