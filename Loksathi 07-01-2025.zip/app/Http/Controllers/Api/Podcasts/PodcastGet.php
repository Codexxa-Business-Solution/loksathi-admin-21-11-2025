<?php

namespace App\Http\Controllers\Api\Podcasts;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Podcast;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PodcastGet extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {
        $product = Podcast::query()
            ->with(array(
                'parts' => function ($query) {
                    $query->where('scheduled_at', '<', Carbon::now());
                }
            ))
            ->find($id);

        // not found
        if (!$product) {
            return $this->failed(__('messages.podcasts_get_failed'));
        }

        return $this->success(__('messages.podcasts_get_success'), $product);
    }
}
