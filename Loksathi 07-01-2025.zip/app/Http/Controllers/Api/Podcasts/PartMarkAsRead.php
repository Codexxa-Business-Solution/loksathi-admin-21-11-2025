<?php

namespace App\Http\Controllers\Api\Podcasts;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\PodcastParts;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PartMarkAsRead extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {
        $user = auth()->user();
        $podcastPart = PodcastParts::query()
            ->find($id);

        if (!$podcastPart)
            return $this->failed(__('Podcast part not found.'));

        $podcastPart->markAsRead($user);

        return $this->success(__('Podcast part marked as read'), null);
    }
}
