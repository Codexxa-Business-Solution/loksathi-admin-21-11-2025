<?php

namespace App\Http\Controllers\Api\Podcasts;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Podcast;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MarkAsRead extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {
        $user = auth()->user();
        $podcast = Podcast::query()
            ->find($id);

        if (!$podcast)
            return $this->failed(__('Podcast not found.'));

        $podcast->markAsRead($user);

        return $this->success(__('Podcast marked as read'), null);
    }
}
