<?php

namespace App\Http\Controllers\Api\Podcasts;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\FeaturedPodcast;
use App\Models\Podcast;
use App\Models\PodcastCategory;
use App\Models\PodcastParts;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        try {
            $language = $this->getLanguage($request);
            // featured podcast groups
            $featuredCategoryPodcast = FeaturedPodcast::query()
                ->orderByDesc('created_at')
                ->get();

            // podcast categories not featured
            $podcastCategories = PodcastCategory::query()
                ->where('language_id', $language->id)
                ->where('is_published', true)
                ->orderByDesc('created_at')
                ->get();

            // daily podcasts - "bodkatha"
            $dailyPodcastParts = PodcastParts::query()
                ->where('podcast_id', 1)
                ->where('scheduled_at', '<', Carbon::now())
                ->orderByDesc('scheduled_at')
                ->limit(20)
                ->get();

            $dailyPodcasts = Podcast::query()
                ->with('category')
                ->first();
            if($dailyPodcasts != null)
                $dailyPodcasts->parts = $dailyPodcastParts;

            // list categories to show on podcast home page
            $categories = PodcastCategory::where('language_id', $language->id)
                ->select('id')
                ->get()
                ->pluck('id');
            $podcastByCategories = array();
            foreach ($categories as $category) {
                $podcastCategory = PodcastCategory::query()
                    ->with(array(
                        'podcasts' => function ($query) {
                            $query->where('is_published', true);
                        },
                        'podcasts.parts' => function ($query) {
                            $query->where('scheduled_at', '<', Carbon::now());
                        }
                    ))
                    ->find($category);
                if ($podcastCategory)
                    $podcastByCategories[] = $podcastCategory;
            }

            // get single podcast
            $singleFeaturedPodcast = Podcast::query()
                ->where('id', 4)
                ->with(array(
                    'parts' => function ($query) {
                        $query->where('scheduled_at', '<', Carbon::now());
                    }
                ))
                ->first();

            $response = [
                'featuredCategoryPodcast' => $featuredCategoryPodcast,
                'podcastCategories' => $podcastCategories,
                'dailyPodcasts' => $dailyPodcasts,
                'singleFeaturedPodcast' => $singleFeaturedPodcast,
                'podcastByCategories' => $podcastByCategories,
            ];

            return $this->success(__('messages.podcasts_index_success'), $response);
        } catch (Exception $exception) {

            return $this->failed(__('messages.podcasts_index_failed'), $exception->getMessage());
        }
    }
}
