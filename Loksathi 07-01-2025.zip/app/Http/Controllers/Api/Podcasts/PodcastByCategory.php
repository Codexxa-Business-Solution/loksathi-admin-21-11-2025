<?php

namespace App\Http\Controllers\Api\Podcasts;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\PodcastCategory;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PodcastByCategory extends BaseApiController
{
    //
    public function __invoke(Request $request, $categoryId): JsonResponse
    {

        // podcast category
        $podcastCategory = PodcastCategory::query()
            ->where('is_published', true)
            ->with(array(
                'podcasts' => function ($query) {
                    $query->where('is_published', true)
                        ->where('scheduled_at', '<', Carbon::now());
                },
                'podcasts.parts' => function ($query) {
                    $query->where('scheduled_at', '<', Carbon::now());
                }
            ))
            ->find($categoryId);

        return $this->success(__('messages.podcast_by_category_success'), $podcastCategory);

    }
}
