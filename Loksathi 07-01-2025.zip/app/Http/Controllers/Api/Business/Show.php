<?php

namespace App\Http\Controllers\Api\Business;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Business;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Show extends BaseApiController
{
    public function __invoke(Request $request, $id): JsonResponse
    {

        $language = $this->getLanguage($request);
        $languageCode = $language->short_name;

        $user = auth()->user();

        $business = Business::with('user', 'category', 'state', 'district', 'taluka')
            ->whereJsonContains('businesses.language_id', $language->id)
            ->find($id);
    
        if (!$business) {
            return $this->failed(__('messages.business_not_found'));
        }
    
        if ($business->user_id != $user->id) {
            $business->view_count = $business->view_count + 1;
            $business->save();
        }
    
        $business->view_count = $this->intWithStyle($business->view_count);
    
        $name = json_decode($business->name, true);
        $description = json_decode($business->description, true);
        
        $business_owner_name = json_decode($business->business_owner_name, true);
        $business_address = json_decode($business->business_address, true);
        
    
        $business->name = $name[$languageCode] ?? ($name['en'] ?? '');
        $business->description = $description[$languageCode] ?? ($description['en'] ?? '');
        
        $business->business_owner_name = $business_owner_name[$languageCode] ?? ($business_owner_name['en'] ?? '');
        $business->business_address = $business_address[$languageCode] ?? ($business_address['en'] ?? '');

        return $this->success(__('messages.business_index_success'), $business);

    }

    private function intWithStyle($n)
    {
        if ($n < 1000) return $n . "";
        $suffix = ['', 'k', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
        $power = floor(log($n, 1000));
        return round($n / (1000 ** $power), 1, PHP_ROUND_HALF_EVEN) . $suffix[$power];
    }

}
