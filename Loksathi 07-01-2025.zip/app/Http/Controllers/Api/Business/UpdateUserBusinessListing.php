<?php

namespace App\Http\Controllers\Api\Business;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Business\StoreBusinessRequest;
use App\Models\Business;
use Illuminate\Http\Request;

use Illuminate\Http\JsonResponse;

class UpdateUserBusinessListing extends BaseApiController
{
    public function __invoke(Request $request, $id): JsonResponse
    {
        $business = Business::find($id);

        if (!$business) {
            return $this->error(__('Business not found'), [], 404);
        }

        $existingname = json_decode($business->name, true) ?? [];
        $existingDescription = json_decode($business->description, true) ?? [];

        $name = [
            'en' => $request->get('name', $existingname['en'] ?? ''),
        ];

        $description = [
            'en' => $request->get('description', $existingDescription['en'] ?? ''),
        ];

        $business->name = json_encode($name, JSON_UNESCAPED_UNICODE);
        $business->description = json_encode($description, JSON_UNESCAPED_UNICODE);
        $business->owner_name = $request->get('owner_name', $business->owner_name);
        $business->email = $request->get('email', $business->email);
        $business->category = $request->get('category', $business->category);
        $business->category_id = $request->get('category_id', $business->category_id);
        $business->whatsapp_number = $request->get('whatsapp_number', $business->whatsapp_number);
        $business->contact_number = $request->get('contact_number', $business->contact_number);
        $business->address = preg_replace('/\s+/', ' ', trim($request->get('address', $business->address)));
        $business->latitude = $request->get('latitude', $business->latitude);
        $business->longitude = $request->get('longitude', $business->longitude);
        $business->opening_time = $request->get('opening_time', $business->opening_time);
        $business->closing_time = $request->get('closing_time', $business->closing_time);
        $business->closing_day = $request->get('closing_day', $business->closing_day);
        $business->is_delivery = $request->get('is_delivery', $business->is_delivery);
       

        $images = $request->file('images');
        if ($images) {
            $imageNames = [];
            foreach ($images as $image) {
                if ($image->isValid()) {
                    $name = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('images/businesses'), $name);
                    $imageNames[] = 'images/businesses/' . $name;
                }
            }
            $business->images = json_encode($imageNames);
        }

        $business->save();
        
        $business->load('category');

        return $this->success('Business updated successfully!', $business);
    }
}
