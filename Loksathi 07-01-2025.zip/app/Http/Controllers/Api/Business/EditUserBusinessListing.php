<?php

namespace App\Http\Controllers\Api\Business;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Business;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class EditUserBusinessListing extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {
        $suggestion = Business::findOrFail($id);

        return response()->json([
            'message' => __('Success'),
            'data' => $suggestion
        ]);

    }
}
