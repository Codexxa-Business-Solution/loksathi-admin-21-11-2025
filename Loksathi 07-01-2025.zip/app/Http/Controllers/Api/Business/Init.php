<?php

namespace App\Http\Controllers\Api\Business;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Business;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Init extends BaseApiController
{
    /**
     * Maximum radius in kilometers to search for businesses
     */
    const MAX_RADIUS_KM = 100;

    /**
     * Handle the business listing request
     */
    public function __invoke(Request $request): JsonResponse
    {

            $language = $this->getLanguage($request);
            $languageCode = $language->short_name;

            $state_id = $request->get('state_id');
            $district_id = $request->get('district_id');
            $taluka_id = $request->get('taluka_id');
            $category = $request->get('category_id');
            $isAzSort = $request->get('is_az_sort', false);
            $query = $request->get('query');
            
            $latitude = $request->get('latitude');
            $longitude = $request->get('longitude');
            $radius = $request->get('radius', self::MAX_RADIUS_KM); 
            
            $radius = min($radius, self::MAX_RADIUS_KM);
            
            $messageQuery = Business::query()
                ->where('is_display', true)
                ->whereJsonContains('language_id', $language->id)
                ->where('status', 'accepted');
            
            if ($category) {
                $messageQuery->where('category_id', $category);
            }
            
            if ($state_id && $district_id && $taluka_id) {
                $messageQuery->where('state_id', $state_id)
                    ->where('district_id', $district_id)
                    ->where('taluka_id', $taluka_id);
            }
            
            if ($latitude && $longitude) {
                $haversine = "(
                    6371 * acos(
                        cos(radians(?)) * 
                        cos(radians(latitude)) * 
                        cos(radians(longitude) - radians(?)) + 
                        sin(radians(?)) * 
                        sin(radians(latitude))
                    )
                )";
            
                $messageQuery->whereRaw("latitude IS NOT NULL AND longitude IS NOT NULL")
                    ->selectRaw("*, {$haversine} AS distance", [$latitude, $longitude, $latitude]);
            }
            
            if ($latitude && $longitude) {
                $messageQuery->orderByRaw("CASE 
                    WHEN state_id = ? THEN 1
                    WHEN district_id = ? THEN 2
                    WHEN taluka_id = ? THEN 3
                    ELSE 4 
                END", [$state_id, $district_id, $taluka_id])
            
                ->orderByRaw("distance ASC");
            }
            
            if ($isAzSort) {
                $messageQuery->orderBy('name');
            }
            
            if ($query) {
                $messageQuery->where('name', 'LIKE', "%$query%");
            }
            
            $messages = $messageQuery->with('user', 'category', 'state', 'district', 'taluka')
                ->simplePaginate(30);
            
        $messages->getCollection()->transform(function ($job) use ($languageCode) {
                $name = json_decode($job->name, true);
                $description = json_decode($job->description, true);
                
                $business_owner_name = json_decode($job->business_owner_name, true);
                $business_address = json_decode($job->business_address, true);
                
                $job->name = $name[$languageCode] ?? ($name['en'] ?? '');
                $job->description = $description[$languageCode] ?? ($description['en'] ?? '');
                
                $job->business_owner_name = $business_owner_name[$languageCode] ?? ($business_owner_name['en'] ?? '');
                $job->business_address = $business_address[$languageCode] ?? ($business_address['en'] ?? '');

            return $job;
        });   
                
        return $this->success(__('messages.business_index_success'), $messages);

    }
}
