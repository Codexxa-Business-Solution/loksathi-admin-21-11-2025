<?php

namespace App\Http\Controllers\Api\Business;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Business;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeleteBusiness extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();
        $business = Business::find($id);

        // check business
        if (!$business)
            return $this->failed(__('Business not found.'), $business);

        // check user
        if ($user->id != $business->user_id)
            return $this->failed(__('Business not found.'), $business);

        // delete business
        $business->delete();

        return $this->success(__('Business deleted successfully.'), $business);


    }

}
