<?php

namespace App\Http\Controllers\Api\Business;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Business;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MyBusinesses extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {
        $user = auth()->user();
        $language = $this->getLanguage($request);
        $languageCode = $language->short_name;
    
        $messages = Business::query()
            ->where('user_id', $user->id)
            
            ->with('user', 'category', 'state', 'district', 'taluka')
            ->whereJsonContains('language_id', $language->id)
            ->simplePaginate(30);
    
        $messages->transform(function ($message) use ($languageCode) {
            $name = json_decode($message->name, true);
            $description = json_decode($message->description, true);
            
            $business_owner_name = json_decode($message->business_owner_name, true);
            $business_address = json_decode($message->business_address, true);
    
            $message->name = $name[$languageCode] ?? ($name['en'] ?? '');
            $message->description = $description[$languageCode] ?? ($description['en'] ?? '');
            
            $message->business_owner_name = $business_owner_name[$languageCode] ?? ($business_owner_name['en'] ?? '');
            $message->business_address = $business_address[$languageCode] ?? ($business_address['en'] ?? '');
    
            return $message;
        });
    
        return $this->success(__('messages.business_index_success'), $messages);
    }

}
