<?php

namespace App\Http\Controllers\Api\Business;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Business\StoreBusinessRequest;
use App\Models\Business;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\JsonResponse;

class Submit extends BaseApiController
{

    public function __invoke(StoreBusinessRequest $request): JsonResponse
    {
        $user = auth()->user();
        
        $language = $this->getLanguage($request); 
        $languageCode = $language->short_name;

        $businessId = $request->get('business_id');
        $business = Business::find($businessId);

        if (!$business) 
        {
            $business = new Business();
            // $business->is_paid = true;
            $business->expired_at = now()->addDays(365);
        }
        
        $username = $request->get('name');
        $userDescription = $request->get('description');
        
        $name = [
            'en' => $languageCode === 'en' ? $username : null,
            'hi' => $languageCode === 'hi' ? $username : null,
            'mr' => $languageCode === 'mr' ? $username : null,
        ];
        
        $description = [
            'en' => $languageCode === 'en' ? $userDescription : null,
            'hi' => $languageCode === 'hi' ? $userDescription : null,
            'mr' => $languageCode === 'mr' ? $userDescription : null,
        ];
        
        $languageIds = [$language->id];
        
        $business->language_id = json_encode($languageIds);
        $business->name = json_encode($name, JSON_UNESCAPED_UNICODE);
        $business->description = json_encode($description, JSON_UNESCAPED_UNICODE);
        $business->user_id = $user->id;
        $business->type = $request->get('type');
        $business->owner_name = $request->get('owner_name');
        $business->email = $request->get('email');
        $business->category = $request->get('category');
      	$business->category_id = $request->get('category_id');
        $business->whatsapp_number = $request->get('whatsapp_number');
        $business->contact_number = $request->get('contact_number');
        $business->address = preg_replace('/\s+/', ' ', trim($request->get('address')));
        $business->latitude = $request->get('latitude');
        $business->longitude = $request->get('longitude');
        $business->opening_time = $request->get('opening_time');
        $business->closing_time = $request->get('closing_time');
        $business->closing_day = $request->get('closing_day');
        $business->is_delivery = $request->get('is_delivery');
        $business->state_id = $request->get('state_id');
        $business->district_id = $request->get('district_id');
        $business->taluka_id = $request->get('taluka_id');
        $business->is_delivery = $request->get('is_delivery');
        
        $business->status = 'pending';

        $images = $request->file('images');
        
        if ($images) {
            $imageNames = [];
            foreach ($images as $image) {
                if ($image->isValid()) {
                    $name = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
                    $image->move(public_path('images/businesses'), $name);
                    $imageNames[] = 'images/businesses/' . $name;
                }
            }
            $business->images = json_encode($imageNames);
        }
        
        $business->save();
        $business->load('category');
        return $this->success('Business submitted successfully! Your request is under review.', $business);
    }
}