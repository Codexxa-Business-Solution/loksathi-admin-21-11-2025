<?php

namespace App\Http\Controllers\Api\Home;

use App\Enums\GroupType;
use App\Http\Controllers\Api\BaseApiController;
use App\Models\BannerAd;
use App\Models\Bot;
use App\Models\FeatureMessage;
use App\Models\Group;
use App\Models\GroupMessage;
use App\Models\Status;
use App\Models\StatusGroup;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Index extends BaseApiController
{

    //
    public function __invoke(Request $request): JsonResponse
    {

        $language = $this->getLanguage($request);

        try {

            // status groups
            $statusGroupId = Status::query()
                ->where('scheduled_at', '>', Carbon::now()->subHours(24))
                ->where('scheduled_at', '<', Carbon::now())
                ->pluck('status_group_id');

            //
            $statusGroups = StatusGroup::query()
                ->where('language_id', $language->id)
                ->with('statuses', function ($query) {
                    $query->where('scheduled_at', '>', Carbon::now()->subHours(24))
                        ->where('scheduled_at', '<', Carbon::now());
                })
                ->findMany($statusGroupId);

            $view = DB::table('status_views')
                ->select('statuses.id')
                ->join('statuses', 'statuses.id', '=', 'status_id')
                ->whereIn('status_group_id', $statusGroupId)
                ->where('status_views.user_id', auth()->user()->id)
                ->get()
                ->pluck('id')
                ->toArray();


            foreach ($statusGroups as $statusGroup) {
                
                $statusGroup->image = $statusGroup->statuses->first()->file;
                
                foreach ($statusGroup->statuses as $st)
                {
                    $st->read = in_array($st->id, $view);
                }
                    
                    
            }
            
            // featured messages
            $groupTypeGroupIds = FeatureMessage::query()
                ->orderBy('index')
                ->pluck('group_message_id');
            $featuredMessages = GroupMessage::query()
                ->with('group')
                ->whereIn('id', $groupTypeGroupIds)
                ->where('is_published', true)
                ->where('scheduled_at', '<', Carbon::now())
                ->get();

            // featured groups
            $featuredGroups = Group::query()
                ->where('language_id', $language->id)
                ->where('is_featured', true)
                ->where('is_published', true)
                ->orderBy('index', 'asc')
                ->get()
                ->makeHidden(['messages', 'quiz_messages', 'blood_messages', 'buy_messages', 'discuss_messages']);

            // setup first message for each group
            $this->addSubTitles($featuredGroups);

            // bots
            $bots = Bot::query()
                ->orderBy('index', 'asc')
                ->get();

            // non-featured groups
            $nonFeaturedGroups = Group::query()
                ->where('language_id', $language->id)
                ->where('is_featured', false)
                ->where('is_published', true)
                ->orderBy('index', 'asc')
                ->get()
                ->makeHidden(['messages', 'quiz_messages', 'blood_messages', 'buy_messages', 'discuss_messages']);

            // setup first message for each group
            $this->addSubTitles($nonFeaturedGroups);

            // 24 hour banners
            $banners = BannerAd::query()
                ->get();


            // response
            $response = [
                'featuredMessages' => $featuredMessages,
                'statusGroups' => $statusGroups,
                'featuredGroups' => $featuredGroups,
                'bots' => $bots,
                'nonFeaturedGroups' => $nonFeaturedGroups,
                'banners' => $banners,
                'latestNews' => [],
                'view' => $view
            ];

            return $this->success(__('messages.home_index_success'), $response);
        } catch (Exception $exception) {

            return $this->failed(__('messages.home_index_failed'), $exception->getLine() . ' -> ' . $exception->getMessage());
        }
    }

    // get sub title
    public function addSubTitles($groups)
    {
        $groups->each(function ($group) {
            switch ($group->type) {
                case GroupType::TYPE_GROUP:
                case GroupType::TYPE_POEM:
                case GroupType::TYPE_LADIES:
                case GroupType::TYPE_ARTICLE:
                    try {
                        $groupMessage = $group->messages()
                            ->where('is_published', true)
                            ->where('scheduled_at', '<', Carbon::now())
                            ->orderBy('scheduled_at', 'desc')
                            ->first();
                        $group->sub_title = $groupMessage->name;
                        $group->display_time = Carbon::parse($groupMessage->scheduled_at)->diffForHumans();
                    } catch (\Exception $exception) {
                        $group->sub_title = 'No Messages';
                        $group->display_time = '';
                    }
                    break;
                case GroupType::TYPE_QUIZ:
                    try {
                        $quizMessage = $group->quiz_messages()
                            ->where('is_published', true)
                            ->where('scheduled_at', '<', Carbon::now())
                            ->orderBy('scheduled_at', 'desc')
                            ->first();
                        $group->sub_title = $quizMessage->name;
                        $group->display_time = Carbon::parse($quizMessage->created_at)->diffForHumans();
                    } catch (\Exception $exception) {
                        $group->sub_title = 'No Messages';
                        $group->display_time = '';
                    }
                    break;
                case GroupType::TYPE_BLOOD_GROUP:
                    try {
                        $bloodMessage = $group->blood_messages()->latest()->first();
                        $group->sub_title = $bloodMessage->description;
                        $group->display_time = Carbon::parse($bloodMessage->created_at)->diffForHumans();
                    } catch (\Exception $exception) {
                        $group->sub_title = 'No Messages';
                        $group->display_time = '';
                    }
                    break;
                case GroupType::TYPE_DISCUSS:
                    try {
                        $discussMessage = $group->discuss_messages()->latest()->first();
                        $group->sub_title = $discussMessage->description;
                        $group->display_time = Carbon::parse($discussMessage->created_at)->diffForHumans();
                    } catch (\Exception $exception) {
                        $group->sub_title = 'No Messages';
                        $group->display_time = '';
                    }
                    break;
                case GroupType::TYPE_BUY_SELL:
                    try {
                        $buyMessage = $group->buy_messages()->latest()->first();
                        $group->sub_title = $buyMessage->description;
                        $group->display_time = Carbon::parse($buyMessage->created_at)->diffForHumans();
                    } catch (\Exception $exception) {
                        $group->sub_title = 'No Messages';
                        $group->display_time = '';
                    }
                    break;
            }
        });
    }
}
