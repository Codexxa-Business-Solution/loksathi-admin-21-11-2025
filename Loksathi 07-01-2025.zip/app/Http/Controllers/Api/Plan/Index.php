<?php

namespace App\Http\Controllers\Api\Plan;

use App\Http\Controllers\Api\BaseApiController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Models\Subscription;

class Index extends BaseApiController
{
    /**
     * Get all plans
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function __invoke(Request $request): JsonResponse
    {
        // $plans = [
        //     [
        //         'id' => 1,
        //         'name' => 'Basic Plan',
        //         'amount' => 99,
        //         'catchLine' => 'Perfect for starters',
        //         'duration' => '30 Days',
        //         'features' => [
        //             'Access to basic features',
        //             '30 days validity',
        //             'Email support'
        //         ]
        //     ],
        //     [
        //         'id' => 2,
        //         'name' => 'Standard Plan',
        //         'amount' => 299,
        //         'catchLine' => 'Most popular choice',
        //         'duration' => '180 Days',
        //         'features' => [
        //             'Access to all basic features',
        //             'Priority customer support',
        //             'Advanced analytics',
        //             '180 days validity'
        //         ]
        //     ],
        //     [
        //         'id' => 3,
        //         'name' => 'Premium Plan',
        //         'amount' => 699,
        //         'catchLine' => 'For power users',
        //         'duration' => '365 Days',
        //         'features' => [
        //             'Access to all features',
        //             'Premium customer support',
        //             'Advanced analytics and reporting',
        //             'Custom integrations',
        //             '365 days validity'
        //         ]
        //     ]
        // ];
        
        $plans = Subscription::where('status',1)->get();

        return $this->success('Plans retrieved successfully', [
            'title' => 'Premium Plans',
            'description' => 'Choose a plan that works best for you',
            'plans' => $plans
        ]);
    }
}
