<?php

namespace App\Http\Controllers\Api\Banner;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Controllers\Controller;
use App\Models\BannerAd;
use Illuminate\Http\Request;

class MarkAsRead extends BaseApiController
{
    //
    public function __invoke(Request $request, $id)
    {
        $user = auth()->user();
        $bannerAd = BannerAd::query()->find($id);

        if (!$bannerAd)
            return $this->failed(__('Banner ad not found.'));

        $bannerAd->markAsRead($user);

        return $this->success(__('Banner ad marked as read'), null);
    }
}
