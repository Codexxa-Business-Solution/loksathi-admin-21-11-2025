<?php

namespace App\Http\Controllers\Api\Location;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\District;
use App\Models\State;
use App\Models\Taluka;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {

        $stateId = $request->input('state_id');
        $districtId = $request->input('district_id');

        $response = array();

        // return states
        if (!$stateId) {
            $response['states'] = State::orderBy('name_mr')
                ->get();
            return $this->success('States retrieved successfully.', (object)$response);
        }

        // return states
        if (!$districtId) {
            $response['districts'] = District::query()
                ->where('state_id', $stateId)
                ->orderBy('name_mr')
                ->get();
            return $this->success('Districts retrieved successfully.', (object)$response);
        }

        // return taluka
        $response['talukas'] = Taluka::query()
            ->where('district_id', $districtId)
            ->orderBy('name_mr')
            ->get();
        return $this->success('Talukas retrieved successfully.', (object)$response);

    }
}
