<?php

namespace App\Http\Controllers\Api\Wallet;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\WalletTransaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TransactionDetails extends BaseApiController
{
    /**
     * Get specific wallet transaction details
     */
    public function __invoke(Request $request, $transactionId): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $transaction = $user->walletTransactions()
                ->where('id', $transactionId)
                ->first();
            
            if (!$transaction) {
                return $this->failed('Transaction not found.');
            }
            
            $data = [
                'transaction' => [
                    'id' => $transaction->id,
                    'type' => $transaction->type,
                    'amount' => $transaction->amount,
                    'formatted_amount' => $transaction->formatted_amount,
                    'balance_before' => $transaction->balance_before,
                    'balance_after' => $transaction->balance_after,
                    'transaction_type' => $transaction->transaction_type,
                    'reference_id' => $transaction->reference_id,
                    'description' => $transaction->description,
                    'status' => $transaction->status,
                    'metadata' => $transaction->metadata,
                    'created_at' => $transaction->created_at->format('Y-m-d H:i:s'),
                    'formatted_date' => $transaction->formatted_date,
                    'updated_at' => $transaction->updated_at->format('Y-m-d H:i:s'),
                ]
            ];

            return $this->success('Transaction details retrieved successfully.', $data);

        } catch (\Exception $exception) {
            return $this->failed('Something went wrong! Please try again later.', $exception->getMessage());
        }
    }
}