<?php

namespace App\Http\Controllers\Api\Wallet;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\WalletTransaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AddMoney extends BaseApiController
{
    /**
     * Add money to user's wallet
     */
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'amount' => 'required|numeric|min:1|max:50000',
                'transaction_type' => 'required|string|in:payment,bonus,refund,transfer',
                'reference_id' => 'nullable|string|max:255',
                'description' => 'nullable|string|max:500',
                'metadata' => 'nullable|array',
            ]);

            if ($validator->fails()) {
                return $this->failed('Validation failed.', $validator->errors());
            }

            $user = auth()->user();
            $amount = $request->get('amount');
            $transactionType = $request->get('transaction_type');
            $referenceId = $request->get('reference_id');
            $description = $request->get('description', 'Money added to wallet');
            $metadata = $request->get('metadata', []);

            DB::beginTransaction();

            try {
                // Add money to wallet
                $transaction = $user->addToWallet(
                    $amount,
                    $transactionType,
                    $referenceId,
                    $description,
                    $metadata
                );

                DB::commit();

                $data = [
                    'transaction' => [
                        'id' => $transaction->id,
                        'type' => $transaction->type,
                        'amount' => $transaction->amount,
                        'formatted_amount' => $transaction->formatted_amount,
                        'balance_before' => $transaction->balance_before,
                        'balance_after' => $transaction->balance_after,
                        'transaction_type' => $transaction->transaction_type,
                        'reference_id' => $transaction->reference_id,
                        'description' => $transaction->description,
                        'status' => $transaction->status,
                        'created_at' => $transaction->created_at->format('Y-m-d H:i:s'),
                    ],
                    'wallet_balance' => $user->fresh()->wallet_balance,
                    'formatted_balance' => $user->fresh()->formatted_wallet_balance,
                ];

                return $this->success('Money added to wallet successfully.', $data);

            } catch (\Exception $e) {
                DB::rollBack();
                throw $e;
            }

        } catch (\Exception $exception) {
            return $this->failed('Something went wrong! Please try again later.', $exception->getMessage());
        }
    }
}