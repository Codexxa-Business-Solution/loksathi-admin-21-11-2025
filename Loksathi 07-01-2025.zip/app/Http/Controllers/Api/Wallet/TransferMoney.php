<?php

namespace App\Http\Controllers\Api\Wallet;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\User;
use App\Services\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TransferMoney extends BaseApiController
{
    protected $walletService;

    public function __construct(WalletService $walletService)
    {
        $this->walletService = $walletService;
    }

    /**
     * Transfer money between users
     */
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'to_user_id' => 'required|integer|exists:users,id',
                'amount' => 'required|numeric|min:1|max:50000',
                'description' => 'nullable|string|max:500',
                'metadata' => 'nullable|array',
            ]);

            if ($validator->fails()) {
                return $this->failed('Validation failed.', $validator->errors());
            }

            $fromUser = auth()->user();
            $toUserId = $request->get('to_user_id');
            $amount = $request->get('amount');
            $description = $request->get('description');
            $metadata = $request->get('metadata', []);

            // Check if trying to transfer to self
            if ($fromUser->id == $toUserId) {
                return $this->failed('Cannot transfer money to yourself.');
            }

            // Get the recipient user
            $toUser = User::find($toUserId);
            if (!$toUser) {
                return $this->failed('Recipient user not found.');
            }

            // Validate amount
            if (!$this->walletService->validateAmount($amount)) {
                return $this->failed('Invalid amount. Amount should be between ₹1 and ₹50,000.');
            }

            // Check if sender has sufficient balance
            if (!$fromUser->hasSufficientBalance($amount)) {
                return $this->failed('Insufficient wallet balance. Current balance: ₹' . number_format($fromUser->wallet_balance, 2));
            }

            // Transfer money
            $transferResult = $this->walletService->transferMoney(
                $fromUser,
                $toUser,
                $amount,
                $description,
                $metadata
            );

            $data = [
                'transfer_id' => $transferResult['transfer_id'],
                'from_user' => [
                    'id' => $fromUser->id,
                    'name' => $fromUser->name,
                    'wallet_balance' => $transferResult['from_user_balance'],
                    'formatted_balance' => '₹' . number_format($transferResult['from_user_balance'], 2),
                ],
                'to_user' => [
                    'id' => $toUser->id,
                    'name' => $toUser->name,
                    'wallet_balance' => $transferResult['to_user_balance'],
                    'formatted_balance' => '₹' . number_format($transferResult['to_user_balance'], 2),
                ],
                'amount' => $amount,
                'formatted_amount' => '₹' . number_format($amount, 2),
                'description' => $description,
                'debit_transaction_id' => $transferResult['debit_transaction']->id,
                'credit_transaction_id' => $transferResult['credit_transaction']->id,
            ];

            return $this->success('Money transferred successfully.', $data);

        } catch (\Exception $exception) {
            return $this->failed('Something went wrong! Please try again later.', $exception->getMessage());
        }
    }
}