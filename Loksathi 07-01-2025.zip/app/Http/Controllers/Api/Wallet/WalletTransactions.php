<?php

namespace App\Http\Controllers\Api\Wallet;

use App\Http\Controllers\Api\BaseApiController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WalletTransactions extends BaseApiController
{
    /**
     * Get user's wallet transactions
     */
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();

            $perPage = $request->get('per_page', 20);
            $type = $request->get('type'); // 'credit', 'debit', or null for all
            $transactionType = $request->get('transaction_type'); // specific transaction type filter

            $query = $user->walletTransactions()
                ->orderBy('created_at', 'desc');

            // Filter by type if provided
            if ($type && in_array($type, ['credit', 'debit'])) {
                $query->where('type', $type);
            }

            // Filter by transaction type if provided
            if ($transactionType) {
                $query->where('transaction_type', $transactionType);
            }

            $transactions = $query->paginate($perPage);

            // Transform the data
            $transformedTransactions = $transactions->getCollection()->map(function ($transaction) {
                return [
                    'id' => $transaction->id,
                    'type' => $transaction->type,
                    'amount' => $transaction->amount,
                    'formatted_amount' => $transaction->formatted_amount,
                    'balance_before' => $transaction->balance_before,
                    'balance_after' => $transaction->balance_after,
                    'transaction_type' => $transaction->transaction_type,
                    'reference_id' => $transaction->reference_id,
                    'description' => $transaction->description,
                    'status' => $transaction->status,
                    'created_at' => $transaction->created_at->format('Y-m-d H:i:s'),
                    'formatted_date' => $transaction->formatted_date,
                    'metadata' => $transaction->metadata,
                ];
            });

            $data = [
                'transactions' => $transformedTransactions,
                'pagination' => [
                    'current_page' => $transactions->currentPage(),
                    'last_page' => $transactions->lastPage(),
                    'per_page' => $transactions->perPage(),
                    'total' => $transactions->total(),
                    'has_more_pages' => $transactions->hasMorePages(),
                ],
                'summary' => [
                    'current_balance' => $user->wallet_balance,
                    'formatted_balance' => $user->formatted_wallet_balance,
                    'total_transactions' => $user->walletTransactions()->count(),
                    'total_credits' => $user->walletTransactions()->credits()->sum('amount'),
                    'total_debits' => $user->walletTransactions()->debits()->sum('amount'),
                ]
            ];

            return $this->success('Wallet transactions retrieved successfully.', $data);

        } catch (\Exception $exception) {
            return $this->failed('Something went wrong! Please try again later.', $exception->getMessage());
        }
    }
}
