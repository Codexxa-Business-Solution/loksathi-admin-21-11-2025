<?php

namespace App\Http\Controllers\Api\Wallet;

use App\Http\Controllers\Api\BaseApiController;
use App\Services\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WalletSummary extends BaseApiController
{
    protected $walletService;

    public function __construct(WalletService $walletService)
    {
        $this->walletService = $walletService;
    }

    /**
     * Get user's wallet summary
     */
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $summary = $this->walletService->getWalletSummary($user);
            
            $data = [
                'wallet_summary' => $summary,
                'transaction_types' => $this->walletService->getTransactionTypes(),
                'user_info' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'phone' => $user->phone,
                ]
            ];

            return $this->success('Wallet summary retrieved successfully.', $data);

        } catch (\Exception $exception) {
            return $this->failed('Something went wrong! Please try again later.', $exception->getMessage());
        }
    }
}