<?php

namespace App\Http\Controllers\Api\Wallet;

use App\Http\Controllers\Api\BaseApiController;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class WalletBalance extends BaseApiController
{
    /**
     * Get user's wallet balance
     */
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $user = auth()->user();
            
            $data = [
                'wallet_balance' => $user->wallet_balance,
                'formatted_balance' => $user->formatted_wallet_balance,
                'user_id' => $user->id,
                'last_updated' => $user->updated_at->format('Y-m-d H:i:s'),
            ];

            return $this->success('Wallet balance retrieved successfully.', $data);

        } catch (\Exception $exception) {
            return $this->failed('Something went wrong! Please try again later.', $exception->getMessage());
        }
    }
}