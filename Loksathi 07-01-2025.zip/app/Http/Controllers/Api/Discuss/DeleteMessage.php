<?php

namespace App\Http\Controllers\Api\Discuss;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\DiscussMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeleteMessage extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();

        $groupMessage = DiscussMessage::find($id);

        if ($groupMessage->user_id != $user->id) {
            return $this->error('You are not authorized to delete this message.');
        }

        // delete
        $groupMessage->delete();

        return $this->success('Deleted successfully.', null);

    }
}
