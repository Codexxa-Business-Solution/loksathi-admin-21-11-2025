<?php

namespace App\Http\Controllers\Api\Discuss;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Resources\DiscussMessageCollection;
use App\Models\DiscussMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Init extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // message id
        $messageId = $request->get('message_id');

        $messageQuery = DiscussMessage::query()
            ->with('group', function ($query) {
                $query->select(['id', 'name']);
            })
            ->with('user', function ($query) {
                $query->select(['id', 'name', 'image', 'phone']);
            })
            ->where('discuss_group_id', $id)
            ->where('is_published', true);

        // check filter
        if ($messageId)
            $messageQuery->where('id', $messageId);

        $messages = $messageQuery->orderBy('created_at', 'desc')
            ->simplePaginate(30);

        return $this->success(__('messages.group_init_success'), new DiscussMessageCollection($messages));

    }
}
