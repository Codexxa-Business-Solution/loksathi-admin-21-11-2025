<?php

namespace App\Http\Controllers\Api\Discuss;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Group\DiscussMessageRequest;
use App\Models\DiscussMessage;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;

class Submit extends BaseApiController
{
    //
    public function __invoke(DiscussMessageRequest $request): JsonResponse
    {

        $user = auth()->user();

        $todayMessage = DiscussMessage::whereDate('created_at', Carbon::now())
            ->where('user_id', '=', $user->id)
            ->first();

        if (!$todayMessage) {

            $discussMessage = new DiscussMessage();
            $discussMessage->user_id = $user->id;
            $discussMessage->discuss_group_id = $request->get('group_id');
            $discussMessage->description = $request->get('description');
            $discussMessage->is_published = true;
            $discussMessage->save();

            // images
            $images = $request->get('images');
            if ($images) {
                $decodedImages = json_decode($images);
                $bunnyImages = [];
                foreach ($decodedImages as $image) {
                    $decBase64Image = base64_decode($image->value);
                    $bunnyCdnStorage = new BunnyCdnStorage();
                    $name = $bunnyCdnStorage->uploadApi($image->name, $decBase64Image, AppConstants::DISCUSS_DIR_NAME);
                    $bunnyImages[] = $name;
                }
                $discussMessage->images = json_encode($bunnyImages);
                $discussMessage->save();
            }

            return $this->success('Discuss request submitted successfully', $discussMessage);

        } else {

            return $this->failed(__('messages.submit_message_limit'));
        }

    }

}
