<?php

namespace App\Http\Controllers\Api;

use App\Enums\AppAction;
use App\Http\Controllers\Controller;
use App\Models\Language;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class BaseApiController extends Controller
{

    // success response
    public function success($message, $data, $action = AppAction::ACTION_NONE, $code = Response::HTTP_OK): JsonResponse
    {
        return response()->json(
            [
                'status' => 'success',
                'message' => $message,
                'data' => $data,
                'action' => $action,
                'error' => null,
            ], $code);
    }

    // failed response
    public function failed($message, $error = null, $code = Response::HTTP_OK, $data = null): JsonResponse
    {
        return response()->json(
            [
                'status' => 'failed',
                'message' => $message,
                'data' => $data,
                'error' => $error
            ], $code);
    }

    // failed response
    public function pending($error, $data = null, $message = null, $code = Response::HTTP_OK): JsonResponse
    {
        return response()->json(
            [
                'status' => 'pending',
                'message' => $message,
                'data' => $data,
                'error' => $error
            ], $code);
    }

    // get language from request
    public function getLanguage($request)
    {
        return Language::where('short_name', $request->header('X-Loksathi-Language', 'mr'))->first();
    }

}
