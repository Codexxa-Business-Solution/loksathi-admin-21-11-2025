<?php

namespace App\Http\Controllers\Api\CalenderEvent;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\CalendarEvent;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        // year
        $year = $request->get('year');

        // events
        $events = CalendarEvent::select('*', DB::raw("DATE_FORMAT(dated_at, '%Y-%m-%d') as formatted_date"))
            ->get()
            ->groupBy('formatted_date');

        //
        $yearEvents = [];
        foreach ($events as $key => $event) {
            $yearEvents[substr_replace($key, $year, 0, 4)] = $event;
        }

        //
        return $this->success(__('Success'), $yearEvents);
    }
}
