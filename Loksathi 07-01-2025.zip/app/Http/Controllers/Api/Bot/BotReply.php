<?php

namespace App\Http\Controllers\Api\Bot;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Bot;
use App\Models\BotMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BotReply extends BaseApiController
{

    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // bot
        $bot = Bot::find($id);
        $input = $request->get('input');

        // not found
        if (!$bot)
            return $this->failed(__('errors.not_found_exception'));

        $botMessage = new BotMessage();
        $botMessage->name = $bot->name;
        $botMessage->message = $bot->start_message;

        $replay = [];
        $replay['input'] = $input;
        $replay['replay'] = array($botMessage);

        if (!$input) {
            $replay['code'] = '35';
            return $this->failed(__('messages.bot_reply_success'), $replay);
        }

        // split message
        $inputArray = explode(" ", $input);
        if (!$inputArray) {
            $replay['code'] = '42';
            return $this->failed(__('messages.bot_reply_success'), $replay);
        }

        // check key exists
        if (!array_key_exists(0, $inputArray)) {
            $replay['code'] = '48';
            return $this->failed(__('messages.bot_reply_success'), $replay);
        }

        $botMessages = $bot->messages()
            ->where('key', $inputArray[0])
            ->get();

        if (count($botMessages) == 0) {
            $replay['code'] = '63';
            return $this->success(__('messages.bot_reply_success'), $replay);
        }

        if (count($botMessages) == 1) {
            $replay['replay'] = $botMessages;
            return $this->success(__('messages.bot_reply_success'), $replay);
        }

        // check sub key exists
        if (!array_key_exists(1, $inputArray)) {

            $message = "";
            foreach ($botMessages as $botMessage)
                $message .= $botMessage->key . " " . $botMessage->sub_key . "</br>";

            // todo check for first empty sub key

            $subInfoBotMessage = new BotMessage();
            $subInfoBotMessage->name = "Other sub keys are: </br>";
            $subInfoBotMessage->message = $message;
            $botMessages[] = $subInfoBotMessage;

            $replay['replay'] = $botMessages;

            return $this->success(__('messages.bot_reply_success'), $replay);

        }

        // parse input and replay message
        $botMessage = $bot->messages()
            ->where('key', $inputArray[0])
            ->where('sub_key', $inputArray[1])
            ->first();

        if (!$botMessage) {
            $replay['code'] = '81';
            return $this->success(__('messages.bot_reply_success'), $replay);
        }

        $replay['replay'] = array($botMessage);
        return $this->success(__('messages.bot_reply_success'), $replay);

    }

}
