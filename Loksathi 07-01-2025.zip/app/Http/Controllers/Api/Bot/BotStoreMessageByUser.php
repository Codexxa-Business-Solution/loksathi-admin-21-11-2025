<?php

namespace App\Http\Controllers\Api\Bot;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BotStoreMessageByUser extends Controller
{
    //
    public function __invoke(Request $request)
    {
        //
    }
}
