<?php

namespace App\Http\Controllers\Api\Bot;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Bot;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{

    //
    public function __invoke(Request $request): JsonResponse
    {

        $language = $this->getLanguage($request);

        try {

            // bots
            $bots = Bot::query()
                ->orderBy('index')
                ->get();

            // response
            $response = [
                'bots' => $bots,
            ];

            return $this->success(__('messages.home_index_success'), $response);

        } catch (Exception $exception) {

            return $this->failed(__('messages.home_index_failed'), $exception->getLine() . ' -> ' . $exception->getMessage());

        }

    }

}
