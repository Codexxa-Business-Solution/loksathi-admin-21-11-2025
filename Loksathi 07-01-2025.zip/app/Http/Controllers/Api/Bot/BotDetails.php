<?php

namespace App\Http\Controllers\Api\Bot;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Bot;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BotDetails extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $bot = Bot::query()
            ->with('messages', function ($query) {
                $query->orderBy('index');
            })
            ->find($id);

        if (!$bot) {
            $this->failed(__('messages.bot_details_failed'));
        }

        // bot messages
        $botDetails = array();
        foreach ($bot->messages as $index => $tempMessage) {

            $message = "";
            $anuchedSubName = "";

            if ($bot->language->id == 1) {
                $anuchedName = "प्रकरण";
                $kalamName = "कलम";
            } else if ($bot->language->id == 2) {
                $anuchedName = "अध्याय";
                $kalamName = "धारा";
            } else {
                $anuchedName = "Chapter";
                $kalamName = "Section";
            }

            if (in_array($bot->id, [11, 12, 13])) {
                if ($bot->language->id == 1) {
                    $anuchedName = "भाग";
                    $anuchedSubName = "प्रकरण";
                    $kalamName = "अनुच्छेद";
                } else if ($bot->language->id == 2) {
                    $anuchedName = "भाग";
                    $anuchedSubName = "प्रकरण";
                    $kalamName = "धारा";
                } else {
                    $anuchedName = "Part";
                    $anuchedSubName = "Chapter";
                    $kalamName = "Section";
                }
            }

            if (!empty($tempMessage->main_key)) {
                $message = $message . $anuchedName . ' ' . ($tempMessage->main_key) . ') <br>' . ($tempMessage->main_key_title) . ' <br>';
            }

            if (!empty($tempMessage->main_sub_key)) {
                $message = $message . $anuchedSubName . ' ' . ($tempMessage->main_sub_key) . ') <br>' . ($tempMessage->main_sub_key_title) . ' <br>';
            }

            if (!empty($tempMessage->sub_key)) {
                $message .= '<b>' . $message . '</b> ' . $kalamName . ' ' . $tempMessage->key . '-' . $tempMessage->sub_key . ') <br> ' . $tempMessage->name;
                if (!is_null($tempMessage->title_prefix)) {
                    $message .= '<b>' . $message . '</b> ' . $kalamName . ' ' . $tempMessage->key . '-' . $tempMessage->sub_key . ') <br> ' . $tempMessage->title_prefix . ' ' . $tempMessage->name;
                }
            } else {
                $message .= '<b>' . $message . '</b> ' . $kalamName . ' ' . $tempMessage->key . ') <br> ' . $tempMessage->name;
                if (!is_null($tempMessage->title_prefix)) {
                    $message .= '<b>' . $message . '</b> ' . $kalamName . ' ' . $tempMessage->key . ') <br> ' . $tempMessage->title_prefix . ' ' . $tempMessage->name;
                }
            }

            $slideInfo = $tempMessage->slide_info;
            if (is_null($tempMessage->slide_info)) {
                $slideInfo = $tempMessage->message;
            }
            $botDetails[$index] = array(
                'title' => $message,
                'info' => $slideInfo,
            );

        }

        return $this->success(__('messages.bot_details_success'), $botDetails);

    }

}
