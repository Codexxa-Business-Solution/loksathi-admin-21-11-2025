<?php

namespace App\Http\Controllers\Api\Bot;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Bot;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BotInit extends BaseApiController
{

    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // bot
        $bot = Bot::find($id);

        // not found
        if (!$bot) {
            return $this->failed(__('errors.not_found_exception'));
        }

        // get start message
        // todo get user bot messages if any

        return $this->success(__('messages.bot_init_success'), $bot);

    }

}
