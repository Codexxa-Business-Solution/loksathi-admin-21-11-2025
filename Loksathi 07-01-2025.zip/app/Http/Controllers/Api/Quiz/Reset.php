<?php

namespace App\Http\Controllers\Api\Quiz;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\QuizAnswer;
use App\Models\QuizMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Reset extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();

        // quiz message
        $quizMessage = QuizMessage::query()->find($id);

        if (!$quizMessage) {
            return $this->failed(__('messages.quiz_reset_failed'));
        }

        // quiz answer
        QuizAnswer::query()
            ->where('user_id', $user->id)
            ->where('quiz_message_id', $id)
            ->delete();

        return $this->success(__('messages.quiz_reset_success'), $quizMessage);

    }

    // get or null
    private function getSafeValue($array, $key)
    {

        if (array_key_exists($key, $array)) {
            return $array[$key];
        }

        return null;

    }

}
