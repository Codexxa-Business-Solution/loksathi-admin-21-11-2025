<?php

namespace App\Http\Controllers\Api\Quiz;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\QuizAnswer;
use App\Models\QuizMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Submit extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();

        // quiz message
        $submittedAnswers = $request->get('answers', array());
        $quizMessage = QuizMessage::query()->find($id);

        if (!$quizMessage) {
            return $this->failed(__('messages.quiz_submit_failed'));
        }

        // quiz answer
        $quizAnswer = QuizAnswer::query()
            ->where('user_id', $user->id)
            ->where('quiz_message_id', $id)
            ->first();

        if (!$quizAnswer) {
            $quizAnswer = new QuizAnswer();
            $quizAnswer->user_id = $user->id;
            $quizAnswer->quiz_message_id = $id;
            $quizAnswer->save();
        }

        $calculation = 0;
        $calculations = array();
        foreach ($quizMessage->questions as $index => $question) {
            if ($question['answer'] == $this->getSafeValue($submittedAnswers, $index)) {
                $calculation = $calculation + 1;
                $calculations[$index] = true;
            } else {
                $calculations[$index] = false;
            }
        }

        $quizAnswer->score = $calculation;
        $quizAnswer->answers = json_decode(json_encode($submittedAnswers), true);
        $quizAnswer->calculations = $calculations;
        $quizAnswer->save();

        $quizMessage->answers = [$quizAnswer];

        return $this->success(__('messages.quiz_submit_success'), $quizMessage);


    }

    // get or null
    private function getSafeValue($array, $key)
    {

        if (array_key_exists($key, $array)) {
            return $array[$key];
        }

        return null;

    }

}
