<?php

namespace App\Http\Controllers\Api\Quiz;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\QuizMessage;
use Carbon\Carbon;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class Init extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        DB::enableQueryLog();



        $quizCategoryId = $request->input('quizCategoryId');

        $message = null;

        $user = auth()->user();
        $messageQuery = QuizMessage::query()
            ->where('scheduled_at', '<', Carbon::now())
            ->where('quiz_group_id', $id)
            ->where('is_published', true);

        if ($request->has('message_id')) {
            $messageQuery->where('id', '!=', $request->message_id);
            $message = QuizMessage::with([
                'answers' => function ($query) use ($user) {
                    $query->where('user_id', $user->id);
                },
                'category'
            ])->where('id', $request->message_id)->first();
        }

        // category
        if ($quizCategoryId != -1) {
            $messageQuery->where('quiz_category_id', $quizCategoryId);
        }

        $messages = $messageQuery->with([
            'answers' => function ($query) use ($user) {
                $query->where('user_id', $user->id);
            },
            'category'
        ])
            ->orderBy('scheduled_at', 'desc')
            ->simplePaginate(30);

        if ($message != null) {
            $messages->prepend($message);
        }
        $queries = DB::getQueryLog();
        Log::info('gdfg' . print_r($queries, true));

        return $this->success(__('messages.group_init_success'), $messages);
    }
}
