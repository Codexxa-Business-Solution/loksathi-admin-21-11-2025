<?php

namespace App\Http\Controllers\Api\Blood;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\BloodGroupMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Init extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // message id
        $messageId = $request->get('message_id');

        $messageQuery = BloodGroupMessage::query()
            ->where('blood_group_id', $id)
            ->where('is_published', true);

        // check filter
        if ($messageId)
            $messageQuery->where('id', $messageId);

        $messages = $messageQuery->with('group', 'user', 'state', 'district', 'taluka')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);

        return $this->success(__('messages.group_init_success'), $messages);

    }
}
