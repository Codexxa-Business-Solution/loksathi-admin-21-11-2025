<?php

namespace App\Http\Controllers\Api\Blood;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Group\BloodMessageRequest;
use App\Models\BloodGroupMessage;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;

class Submit extends BaseApiController
{
    //
    public function __invoke(BloodMessageRequest $request): JsonResponse
    {

        $user = auth()->user();

        $todayMessage = BloodGroupMessage::whereDate('created_at', Carbon::now())
            ->where('user_id', '=', $user->id)
            ->first();

        if (!$todayMessage) {

            $bloodGroupMessage = new BloodGroupMessage();
            $bloodGroupMessage->blood_group_id = $request->get('group_id');
            $bloodGroupMessage->patient_name = $request->get('patient_name');
            $bloodGroupMessage->user_id = $user->id;
            $bloodGroupMessage->blood_group = $request->get('blood_group');
            $bloodGroupMessage->description = $request->get('description');
            $bloodGroupMessage->contact_number = $request->get('contact_number');
            $bloodGroupMessage->address = $request->get('address');
            $bloodGroupMessage->latitude = $request->get('latitude');
            $bloodGroupMessage->longitude = $request->get('longitude');
            $bloodGroupMessage->is_published = true;
            $bloodGroupMessage->state_id = $request->get('state_id');
            $bloodGroupMessage->district_id = $request->get('district_id');
            $bloodGroupMessage->taluka_id = $request->get('taluka_id');
            $bloodGroupMessage->status = 'pending';
            $bloodGroupMessage->save();

            // send user request submitted
            // send other users request received

            return $this->success(__('messages.blood_submit_success'), $bloodGroupMessage);

        } else {

            return $this->failed(__('messages.submit_message_limit'));

        }

    }

}
