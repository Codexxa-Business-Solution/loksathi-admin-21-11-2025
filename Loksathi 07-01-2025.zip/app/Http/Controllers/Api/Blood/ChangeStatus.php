<?php

namespace App\Http\Controllers\Api\Blood;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\BloodGroupMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ChangeStatus extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();

        $bloodMessage = BloodGroupMessage::where('id', $id)
            ->where('user_id', $user->id)
            ->first();

        if (!$bloodMessage) {
            return $this->failed(__('messages.blood_status_failed'));
        }

        $bloodMessage->status = 'completed';
        $bloodMessage->save();

        return $this->success(__('messages.blood_status_success'), $bloodMessage);

    }
}
