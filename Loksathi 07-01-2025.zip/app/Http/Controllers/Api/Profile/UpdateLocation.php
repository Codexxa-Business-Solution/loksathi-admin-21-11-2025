<?php

namespace App\Http\Controllers\Api\Profile;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Profile\UpdateLocationRequest;

class UpdateLocation extends BaseApiController
{
    //
    public function __invoke(UpdateLocationRequest $request)
    {

        // ids
        $stateId = $request->input('state_id');
        $districtId = $request->input('district_id');
        $talukaId = $request->input('taluka_id');
        $latitude = $request->input('latitude');
        $longitude = $request->input('longitude');
        $address = $request->input('address');

        // user
        $user = auth()->user();

        // update info
        $user->updateInfo([
            'state_id' => $stateId,
            'district_id' => $districtId,
            'taluka_id' => $talukaId,
            'latitude' => $latitude,
            'longitude' => $longitude,
            'address' => $address,
        ]);

        // return response
        return $this->success('Location updated successfully.', $user);

    }
}
