<?php

namespace App\Http\Controllers\Api\Profile;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Profile\UpdateProfileRequest;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\File;

class UpdateProfile extends BaseApiController
{
    //
    public function __invoke(UpdateProfileRequest $request): JsonResponse
    {

        $user = auth()->user();

        $name = $request->get('name');
        $email = $request->get('email');
        $phone = $request->get('phone');
        $blood_group = $request->get('blood_group');
        $gender = $request->get('gender', $user->gender);

        // user
        $user->name = $name;
        $user->email = $email;
        $user->phone = $phone;
        $user->blood_group = $blood_group;
        $user->gender = $gender;
        $user->save();

        // images
        $bunnyImage = '';
        $images = $request->get('images');
        if ($images) {
            $decodedImages = json_decode($images);
            
            foreach ($decodedImages as $index => $image) {
                if ($index == 0) {
                    $decBase64Image = base64_decode($image->value);
                    // $bunnyCdnStorage = new BunnyCdnStorage();
                    $name = md5(microtime()) . '.' . $image->name;
                    File::put(AppConstants::PROFILE_DIR_NAME . $name, $decBase64Image);
                    
                    // $name = $bunnyCdnStorage->uploadApi($image->name, $decBase64Image, AppConstants::PROFILE_DIR_NAME);
                    $bunnyImage = AppConstants::PROFILE_DIR_NAME . $name;
                }
            }

            if($user->image != null) {
                File::delete($user->image);
            }

            $user->image = $bunnyImage;

            $user->save();
        }

        // return response
        return $this->success('Profile updated successfully.' . $bunnyImage, $user);
    }
}
