<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\CustomAdResource;
use App\Models\CustomAd;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CustomAdController extends BaseApiController
{
    const MAX_RADIUS_KM = 50;
    
    /**
     * Get custom ads by position (only active/non-expired ads)
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getAdsByPosition(Request $request): JsonResponse
    {
        try {
            // Validate request
            $request->validate([
                'position' => 'required|string|in:' . implode(',', array_keys(CustomAd::$positionOptions))
            ]);

            $position = $request->get('position');

            // Get active ads for the specified position, ordered by display_order
            $ads = CustomAd::active()
                ->where(function ($query) use ($position) {
                    // Check both old position field and new positions array
                    $query->where('position', $position)
                        ->orWhereJsonContains('positions', $position);
                })
                ->orderBy('display_order', 'asc')
                ->orderBy('created_at', 'desc')
                ->get();

            // Transform the data for API response
            $transformedAds = CustomAdResource::collection($ads);

            return $this->success('Ads retrieved successfully', $transformedAds);

        } catch (\Exception $e) {
            return $this->failed('Failed to retrieve ads', $e->getMessage());
        }
    }

    /**
     * Get all active custom ads
     *
     * @return JsonResponse
     */

    public function getAllActiveAds(Request $request): JsonResponse
    {
        $latitude = $request->get('latitude');
        $longitude = $request->get('longitude');
        $radius = min($request->get('radius', self::MAX_RADIUS_KM), self::MAX_RADIUS_KM);
    
        try {
            $query = CustomAd::active();
                
    
            if ($latitude && $longitude) {
                $haversine = "(
                    6371 * acos(
                        cos(radians(?)) * 
                        cos(radians(latitude)) * 
                        cos(radians(longitude) - radians(?)) + 
                        sin(radians(?)) * 
                        sin(radians(latitude))
                    )
                )";
    
                 $query->whereRaw("latitude IS NOT NULL AND longitude IS NOT NULL")
                ->selectRaw("*, {$haversine} AS distance", [$latitude, $longitude, $latitude])
                 ->havingRaw("distance <= ?", [$radius])
                ->orderBy('distance');
            }
    
            $ads = $query->get();
    
            $transformedAds = CustomAdResource::collection($ads);
    
            return $this->success('All active ads retrieved successfully', $transformedAds);
    
        } catch (\Exception $e) {
            return $this->failed('An error occurred while retrieving ads');
        }
    }


    /**
     * Get available positions
     *
     * @return JsonResponse
     */
    public function getPositions(): JsonResponse
    {
        try {
            $positions = collect(CustomAd::$positionOptions)->map(function ($name, $key) {
                return [
                    'key' => $key,
                    'name' => $name,
                ];
            })->values();

            return response()->json([
                'success' => true,
                'message' => 'Positions retrieved successfully',
                'data' => $positions,
                'meta' => [
                    'total_positions' => $positions->count(),
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving positions',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error',
                'data' => []
            ], 500);
        }
    }

    /**
     * Get ads grouped by position
     *
     * @return JsonResponse
     */
    public function getAdsGroupedByPosition(): JsonResponse
    {
        try {
            $ads = CustomAd::active()
                ->orderBy('display_order', 'asc')
                ->orderBy('created_at', 'desc')
                ->get();

            $groupedAds = [];

            foreach (CustomAd::$positionOptions as $positionKey => $positionName) {
                $positionAds = $ads->filter(function ($ad) use ($positionKey) {
                    $positions = $ad->getDisplayPositions();
                    return in_array($positionKey, $positions);
                });

                $transformedPositionAds = CustomAdResource::collection($positionAds);

                $groupedAds[$positionKey] = [
                    'position_name' => $positionName,
                    'ads' => $transformedPositionAds,
                    'count' => $positionAds->count(),
                ];
            }

            return response()->json([
                'success' => true,
                'message' => 'Ads grouped by position retrieved successfully',
                'data' => $groupedAds,
                'meta' => [
                    'total_positions' => count($groupedAds),
                    'total_ads' => $ads->count(),
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving grouped ads',
                'error' => config('app.debug') ? $e->getMessage() : 'Internal server error',
                'data' => []
            ], 500);
        }
    }
}
