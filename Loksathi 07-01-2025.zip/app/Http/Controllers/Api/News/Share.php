<?php

namespace App\Http\Controllers\Api\News;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\News;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Share extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        try {

            $isWhatsapp = $request->get('isWhatsapp', false);

            $news = News::find($id);

            // news not found
            if (!$news) {
                return $this->failed('News not found', 404);
            }

            // increase share count
            if ($isWhatsapp) {
                $news->whatsapp_share_count = $news->whatsapp_share_count + 1;
            } else {
                $news->share_count = $news->share_count + 1;
            }
            $news->save();

            $news->images = json_decode($news->images);

            return $this->success(__('messages.home_index_success'), $news);

        } catch (Exception $exception) {

            return $this->failed(__('messages.news_index_failed'), $exception->getMessage());

        }

    }
}
