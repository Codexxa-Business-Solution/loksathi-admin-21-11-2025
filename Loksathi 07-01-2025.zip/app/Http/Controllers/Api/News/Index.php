<?php

namespace App\Http\Controllers\Api\News;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\News;
use App\Models\NewsComment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $language = $this->getLanguage($request);
            $newsId = $request->input('news_id');

            // Previous code
            // $newQuery = News::withCount(['comments', 'likes', 'user_like'])
            //     ->select('news.*') // Select only the necessary columns
            //     ->join('news_categories', 'news_category_id', '=', 'news_categories.id')
            //     ->where('news_categories.language_id', $language->id)
            //     ->where('scheduled_at', '<', Carbon::now())
            //     ->where('news.is_published', true)
            //     ->orderBy('scheduled_at', 'desc')
            //     ->limit(100);


            // Updated By Gaurav
            // $newQuery = News::select('news.name','news.message','news.share_count','news.whatsapp_share_count','news.likes_count','news.comments_count','news.image')
            //     ->selectRaw('(SELECT COUNT(*) FROM news_likes WHERE news_likes.user_id = ? AND news_likes.news_id = news.id) AS user_like_count', [auth()->user()->id])
            //     ->join('news_categories', 'news.news_category_id', '=', 'news_categories.id')
            //     ->where('news_categories.language_id', $language->id)
            //     ->where('news.scheduled_at', '<', Carbon::now())
            //     ->where('news.is_published', true)
            //     ->orderBy('news.scheduled_at', 'desc')
            //     ->limit(100);

            $newQuery = News::select(
                'news.id',
                'news.name',
                'news.message',
                'news.share_count',
                'news.whatsapp_share_count',
                'news.likes_count',
                'news.comments_count',
                'news.image',
                'news.images',
                'news.type',
                'news.link',
                'news.scheduled_at',
                DB::raw('(COUNT(news_likes.id)) AS user_like_count')
            )
                ->join('news_categories', 'news.news_category_id', '=', 'news_categories.id')
                ->leftJoin('news_likes', function ($join) {
                    $join->on('news_likes.news_id', '=', 'news.id')
                        ->where('news_likes.user_id', '=', auth()->user()->id);
                })
                ->where('news_categories.language_id', $language->id)
                ->where('news.scheduled_at', '<', now())
                ->where('news.is_published', true)
                ->groupBy(
                    'news.id',
                    'news.name',
                    'news.message',
                    'news.share_count',
                    'news.whatsapp_share_count',
                    'news.likes_count',
                    'news.comments_count',
                    'news.image',
                    'news.images',
                    'news.type',
                    'news.link',
                    'news.scheduled_at'
                )
                ->orderByDesc('news.scheduled_at')
                ->limit(100);


            // Exclude the current news ID if provided
            if ($newsId) {
                $newQuery->where('news.id', '!=', $newsId);
            }

            // Execute the query
            $news = $newQuery->get();

            // Check for the top news and load counts if it exists
            if ($topNews = News::withCount(['comments', 'likes', 'user_like'])->find($newsId)) {
                $news->prepend($topNews);
            }

            $tempNews = array();
            foreach ($news as $tempNew) {
                $tempNew->images = json_decode($tempNew->images);
                $tempNews[] = $tempNew;
            }

            $news = $tempNews;

            return $this->success(__('messages.home_index_success'), ['news' => $news]);
        } catch (Exception $exception) {
            return $this->failed(__('messages.news_index_failed'), $exception->getMessage());
        }
    }


    public function like(Request $request)
    {
        $likeCount = DB::table('news_likes')
            ->where('user_id', $request->user()->id)
            ->where('news_id', $request->news)
            ->count();

        if ($likeCount) {
            DB::table('news_likes')
                ->where('user_id', $request->user()->id)
                ->where('news_id', $request->news)
                ->delete();
        } else {
            DB::table('news_likes')
                ->insert([
                    'user_id' => $request->user()->id,
                    'news_id' => $request->news,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
        }

        $likeCounts = DB::table('news_likes')
            ->where('news_id', $request->news)
            ->count();

        $news = News::find($request->news);
        $news->likes_count = $likeCounts;
        $news->images = json_decode($news->images);
        $news->save();
        $news->loadCount('comments', 'likes', 'user_like');
        return $this->success(__('messages.home_index_success'), $news);
    }

    public function comments($news_id)
    {
        $comments = DB::table('news_comments')
            ->join('users', 'news_comments.user_id', '=', 'users.id')
            ->select(['news_comments.id', 'news_comments.created_at', 'comment', 'users.name', 'users.id as user', 'users.image', 'is_edited'])
            ->where('news_id', $news_id)
            ->where('is_inactive', '0')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);


        return $this->success(__('messages.home_index_success'), $comments);
    }

    public function comment(Request $request)
    {
        $response = NewsComment::create([
            'user_id' => auth()->user()->id,
            'news_id' => $request->news_id,
            'comment' => $request->comment
        ]);

        $commentsCounts = DB::table('news_comments')
            ->where('news_id', $request->news_id)
            ->count();

        $news = News::find($request->news_id);
        $news->comments_count = $commentsCounts;
        $news->save();
        $news->loadCount('comments', 'likes', 'user_like');

        return $this->success(__('messages.home_index_success'), $news);
    }

    public function editComment(Request $request, NewsComment $comment)
    {
        $response = $comment->update([
            'comment' => $request->comment,
            'is_edited' => 1,
        ]);

        $news = News::find($comment->news_id);
        $news->loadCount('comments', 'likes', 'user_like');

        return $this->success(__('messages.home_index_success'), $news);
    }

    public function deleteComment(Request $request, NewsComment $comment)
    {
        $news = News::find($comment->news_id);
        $comment->delete();
        $commentsCounts = DB::table('news_comments')
            ->where('news_id', $comment->news_id)
            ->count();
        $news->comments_count = $commentsCounts;
        $news->save();
        $news->loadCount('comments', 'likes', 'user_like');

        return $this->success(__('messages.home_index_success'), $news);
    }

    public function commentReport(Request $request)
    {
        $report = DB::table('news_comment_reports')->where([
            'user_id' => $request->user()->id,
            'comment_id' => $request->comment_id
        ])->first();

        if ($report == null) {
            DB::table('news_comment_reports')->insert([
                'user_id' => $request->user()->id,
                'comment_id' => $request->comment_id,
                'reason' => $request->reason,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } else {
            DB::table('news_comment_reports')->where([
                'user_id' => $request->user()->id,
                'comment_id' => $request->comment_id
            ])->update(['reason' => $request->reason]);
        }


        return $this->success(__('messages.home_index_success'), null);
    }
}
