<?php

namespace App\Http\Controllers\Api\News;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\News;
use App\Models\NewsLike;
use App\Models\NewsComment;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AllCount extends BaseApiController
{
    public function __invoke(Request $request): JsonResponse
    {
        try {
            $language = $this->getLanguage($request);
            $newsId = $request->input('news_id');
    
            $newQuery = News::withCount(['comments', 'likes', 'user_like'])
                ->select('news.*') // Select only the necessary columns
                ->join('news_categories', 'news_category_id', '=', 'news_categories.id')
                ->where('news_categories.language_id', $language->id)
                ->where('scheduled_at', '<', Carbon::now())
                ->where('news.is_published', true)
                ->orderBy('scheduled_at', 'desc')
                ->limit(100);
    
            // Exclude the current news ID if provided
            if ($newsId) {
                $newQuery->where('news.id', '!=', $newsId);
            }
    
            $newsData = NewsLike::where('news_id',$newsId)->count();
    
            // Execute the query
            $news = $newQuery->get();
    
            // Check for the top news and load counts if it exists
            if ($topNews = News::withCount(['comments', 'likes', 'user_like'])->find($newsId)) {
                $news->prepend($topNews);
            }
    
            return $this->success(__('messages.home_index_success'), ['news' => $news]);
        } catch (Exception $exception) {
            return $this->failed(__('messages.news_index_failed'), $exception->getMessage());
        }
    }

}
