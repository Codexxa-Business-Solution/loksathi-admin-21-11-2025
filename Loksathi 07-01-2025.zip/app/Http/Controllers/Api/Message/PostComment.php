<?php

namespace App\Http\Controllers\Api\Message;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Message\PostCommentRequest;
use App\Models\BloodGroupMessage;
use App\Models\BuySellMessage;
use App\Models\DiscussMessage;
use App\Models\GroupComment;
use App\Models\GroupMessage;
use App\Services\PushService;
use Illuminate\Http\JsonResponse;

class PostComment extends BaseApiController
{
    //
    public function __invoke(PostCommentRequest $request): JsonResponse
    {

        $user = auth()->user();

        $groupMessageId = $request->get('group_message_id');
        $comment = $request->get('comment');
        $groupType = $request->get('group_type');

        $groupComment = new GroupComment();
        $groupComment->user_id = $user->id;
        $groupComment->group_message_id = $groupMessageId;
        $groupComment->comment = $comment;
        $groupComment->group_type = $groupType;
        $groupComment->save();

        // add comment count in respective messages
        switch ($groupType) {
            case "group_message":
                $groupMessage = GroupMessage::find($groupMessageId);
                if ($groupMessage) {
                    $groupMessage->comment_count = $groupMessage->comment_count + 1;
                    $groupMessage->save();
                }
                break;
            case "buy_sell_message":
                $buySellMessage = BuySellMessage::find($groupMessageId);
                if ($buySellMessage) {
                    $buySellMessage->comment_count = $buySellMessage->comment_count + 1;
                    $buySellMessage->save();
                }
                break;
            case "discuss_message":
                $discussMessage = DiscussMessage::find($groupMessageId);
                if ($discussMessage) {
                    $discussMessage->comment_count = $discussMessage->comment_count + 1;
                    $discussMessage->save();
                }
                break;
            case "blood_message":
                $bloodGroupMessage = BloodGroupMessage::find($groupMessageId);
                if ($bloodGroupMessage) {
                    $bloodGroupMessage->comment_count = $bloodGroupMessage->comment_count + 1;
                    $bloodGroupMessage->save();
                }
                break;
        }


        // send comment notification to user
        if ($user->id != $groupComment->user_id)
            PushService::sendCommentNotification($user, $groupComment);

        // send notification to specific user
        return $this->success(__('Comment has been added successfully.'), $groupComment);

    }
}
