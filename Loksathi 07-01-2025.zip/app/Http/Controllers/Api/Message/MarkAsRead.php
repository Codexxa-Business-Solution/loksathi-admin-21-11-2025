<?php

namespace App\Http\Controllers\Api\Message;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Group;
use App\Models\GroupMessageReadCount;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MarkAsRead extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {
        $user = auth()->user();
        $groupId = $request->get('group_id');
        $group = Group::find($groupId);

        if (!$group)
            return $this->failed("Group not found.");

        // query
        $groupMessageReadCount = GroupMessageReadCount::where('group_id', $groupId)
            ->where('user_id', $user->id)
            ->first();

        // check is exists
        if (!$groupMessageReadCount) {
            $groupMessageReadCount = new GroupMessageReadCount();
            $groupMessageReadCount->user_id = $user->id;
            $groupMessageReadCount->group_id = $groupId;
            $groupMessageReadCount->save();
        }

        $groupMessageReadCount->read_count = $group->group_message_count;
        $groupMessageReadCount->save();

        return $this->success(__('Group marked as read'), null);
    }
}
