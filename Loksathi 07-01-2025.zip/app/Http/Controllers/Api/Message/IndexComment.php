<?php

namespace App\Http\Controllers\Api\Message;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\GroupComment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class IndexComment extends BaseApiController
{
    //
    public function __invoke(Request $request, $id, $groupType): JsonResponse
    {

        $messages = GroupComment::query()
            ->with('user')
            ->where('group_message_id', $id)
            ->where('group_type', $groupType)
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);

        return $this->success(__('Group comment initialized successfully.'), $messages);

    }

}
