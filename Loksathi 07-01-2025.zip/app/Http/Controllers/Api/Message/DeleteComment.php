<?php

namespace App\Http\Controllers\Api\Message;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\GroupComment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeleteComment extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();

        $groupComment = GroupComment::find($id);

        if (!$groupComment)
            return $this->failed(__('Comment not found.'), $groupComment);

        if ($groupComment->user_id != $user->id)
            return $this->failed(__('Comment not found.'), $groupComment);

        $groupComment->delete();

        // send notification to specific user
        return $this->success(__('Comment has been deleted successfully.'), null);

    }
}
