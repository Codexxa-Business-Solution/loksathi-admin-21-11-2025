<?php

namespace App\Http\Controllers\Api\Start;

use App\Enums\AppAction;
use App\Http\Controllers\Api\BaseApiController;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        $versionName = $request->get('versionName');
        $versionCode = $request->get('versionCode');

        // start response
        $startResponse = [
            'appPackageName' => ''
        ];

        // check version
        // if ($versionCode < 9) {
        //     return $this->success(__('messages.start_version_update'), $startResponse, AppAction::ACTION_UPDATE);
        // }
        
        
        $minVersionCode = env('APP_VERSION_CODE', 26);
        if ($versionCode < $minVersionCode) {
            return $this->success(__('messages.start_version_update'), $startResponse, AppAction::ACTION_UPDATE);
        }

        // add user if available
        $user = null;
        if ($request->hasHeader('Authorization')) {
            if ($request->header('Authorization'))
                $user = User::query()
                    ->where('api_token', \Str::replace("Bearer ", "", $request->header('Authorization')))
                    ->first();
        }

        if ($user) {
            if ($request->get('device_type') == "android") {
                $user->device_type = $request->get('device_type');
                $user->android_push_id = $request->get('push_token');
            }
        }

        $startResponse['user'] = $user;

        // return response
        return $this->success(__('messages.start_success'), $startResponse);

    }
}
