<?php

namespace App\Http\Controllers\Api\Search;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\GroupMessage;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{

    //
    public function __invoke(Request $request): JsonResponse
    {

        $language = $this->getLanguage($request);
        $query = $request->get('query');

        try {

            $messages = GroupMessage::query()
                ->with('group', 'user')
                ->where('is_published', true)
                ->where('scheduled_at', '<', Carbon::now())
                ->where('message', 'LIKE', "%$query%")
                ->orderBy('scheduled_at', 'desc')
                ->get();

            $response = array();
            $response['messages'] = $messages;

            return $this->success(__('Search fetched successfully.'), $response);

        } catch (Exception $exception) {
            return $this->failed(__('Search cannot fetched successfully.'), $exception->getLine() . ' -> ' . $exception->getMessage());
        }

    }

}
