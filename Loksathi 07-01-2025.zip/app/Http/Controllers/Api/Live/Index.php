<?php

namespace App\Http\Controllers\Api\Live;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\LiveVideo;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        $liveVideo = LiveVideo::first();

        if ($liveVideo) {
            return $this->success('Live video found', $liveVideo);
        } else {
            return $this->failed('There is no live streaming currently.');
        }

    }
}
