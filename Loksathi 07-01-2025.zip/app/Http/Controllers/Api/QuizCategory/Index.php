<?php

namespace App\Http\Controllers\Api\QuizCategory;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\QuizCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {
        return $this->success(__('messages.group_init_success'), QuizCategory::all());
    }
}
