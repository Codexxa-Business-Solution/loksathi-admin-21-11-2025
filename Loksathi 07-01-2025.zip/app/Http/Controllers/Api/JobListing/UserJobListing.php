<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobListing;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserJobListing extends BaseApiController
{
    /**
     * Handle the job listing request
     */
    public function __invoke(Request $request): JsonResponse
    {
        $user = auth()->user();
        
        $language = $this->getLanguage($request); 
        $languageCode = $language->short_name;
        
        $query = JobListing::query()
            ->with(['jobCategory', 'tags'])
            ->whereJsonContains('language_id', $language->id)
            ->where('user_id', $user->id);

        if ($request->has('category_id') && $request->category_id) {
            $query->where('job_category_id', $request->category_id);
        }
    
        if ($request->has('search') && $request->search) {
            $searchTerm = '%' . $request->search . '%';
            $query->where(function($q) use ($searchTerm) {
                $q->where('title', 'like', $searchTerm)
                  ->orWhere('description', 'like', $searchTerm)
                  ->orWhere('location', 'like', $searchTerm);
            });
        }
        
        $perPage = $request->input('per_page', 30);
        
        $jobListings = $query->simplePaginate($perPage);
        
         $jobListings->getCollection()->transform(function ($job) use ($languageCode) {
            $title = json_decode($job->title, true);
            $description = json_decode($job->description, true);
            
            $job_contact_person = json_decode($job->job_contact_person, true);
            $job_address = json_decode($job->job_address, true);

            $job->title = $title[$languageCode] ?? ($title['en'] ?? '');
            $job->description = $description[$languageCode] ?? ($description['en'] ?? '');
            
            $job->job_contact_person = $job_contact_person[$languageCode] ?? ($job_contact_person['en'] ?? '');
            $job->job_address = $job_address[$languageCode] ?? ($job_address['en'] ?? '');

            return $job;
        });
    
        return $this->success(__('Success'), $jobListings);
    }

}
