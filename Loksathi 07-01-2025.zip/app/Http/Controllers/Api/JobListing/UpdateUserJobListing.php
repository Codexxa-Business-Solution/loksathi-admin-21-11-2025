<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobListing;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UpdateUserJobListing extends BaseApiController
{
    public function __invoke(Request $request, $id): JsonResponse
    {
        $jobListing = JobListing::find($id);
        if (!$jobListing) {
            return $this->error(__('Job listing not found'), [], 404);
        }

        $existingTitle = json_decode($jobListing->title, true) ?? [];
        $existingDescription = json_decode($jobListing->description, true) ?? [];

        $title = [
            'en' => $request->get('title', $existingTitle['en'] ?? ''),
        ];

        $description = [
            'en' => $request->get('description', $existingDescription['en'] ?? ''),
        ];

        $jobListing->title = json_encode($title, JSON_UNESCAPED_UNICODE);
        $jobListing->description = json_encode($description, JSON_UNESCAPED_UNICODE);
        $jobListing->location = $request->get('location', $jobListing->location);
        $jobListing->latitude = $request->get('latitude', $jobListing->latitude);
        $jobListing->longitude = $request->get('longitude', $jobListing->longitude);
        $jobListing->salary = $request->get('salary', $jobListing->salary);
        $jobListing->experience = $request->get('experience', $jobListing->experience);
        $jobListing->job_type = $request->get('job_type', $jobListing->job_type);
        $jobListing->position = $request->get('position', $jobListing->position);
        $jobListing->contact_number = $request->get('contact_number', $jobListing->contact_number);
        $jobListing->contact_name = $request->get('contact_name', $jobListing->contact_name);
        $jobListing->job_category_id = $request->get('job_category_id', $jobListing->job_category_id);
        $jobListing->expiry_date = $request->get('expiry_date', $jobListing->expiry_date);
        $jobListing->is_published = $request->has('is_published') ? $request->boolean('is_published') : $jobListing->is_published;
        $jobListing->is_premium = $request->has('is_premium') ? $request->boolean('is_premium') : $jobListing->is_premium;

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::JOB_LISTINGS_DIR_NAME, $name);
            $jobListing->image = AppConstants::JOB_LISTINGS_DIR_NAME . $name;
        }

        $jobListing->save();

        if ($request->has('tags')) {
            $jobListing->tags()->sync($request->get('tags'));
        }

        return $this->success(__('Job Listing Updated Successfully'), $jobListing);
    }
}
