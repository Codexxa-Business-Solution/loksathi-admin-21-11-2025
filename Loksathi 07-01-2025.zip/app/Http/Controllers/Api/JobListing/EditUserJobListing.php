<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Controller;
use App\Models\JobListing;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class EditUserJobListing extends Controller
{
    public function __invoke(Request $request, $id): JsonResponse
    {
        $suggestion = JobListing::findOrFail($id);
        return response()->json([
            'message' => __('Success'),
            'data' => $suggestion
        ]);
    }
}
