<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobListing;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ListingsByCategory extends BaseApiController
{
    public function __invoke(Request $request, $categoryId): JsonResponse
    {
        $query = JobListing::query()
            ->with(['jobCategory', 'tags'])
            ->where('job_category_id', $categoryId)
            ->where('is_published', true)
            ->where('expiry_date', '>=', Carbon::now()->format('Y-m-d'));
            
        // Search by title or description if search parameter is provided
        if ($request->has('search') && $request->search) {
            $searchTerm = '%' . $request->search . '%';
            $query->where(function($q) use ($searchTerm) {
                $q->where('title', 'like', $searchTerm)
                  ->orWhere('description', 'like', $searchTerm)
                  ->orWhere('location', 'like', $searchTerm);
            });
        }
        
        // Get per_page parameter or default to 30
        $perPage = $request->input('per_page', 30);
        
        $jobListings = $query->orderBy('created_at', 'desc')
            ->simplePaginate($perPage);

        return $this->success(__('Success'), $jobListings);
    }
}