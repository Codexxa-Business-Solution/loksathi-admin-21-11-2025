<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobListing;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class JobDetail extends BaseApiController
{
    public function __invoke(Request $request, $id): JsonResponse
    {
        $language = $this->getLanguage($request);
        $languageCode = $language->short_name;

        $job = JobListing::with(['jobCategory', 'tags'])
            ->where('is_published', true)
            ->whereJsonContains('language_id', $language->id)
            ->findOrFail($id);

        $title = json_decode($job->title, true);
        $description = json_decode($job->description, true);
        $job_contact_person = json_decode($job->job_contact_person, true);
        $job_address = json_decode($job->job_address, true);

        $job->title = $title[$languageCode] ?? ($title['en'] ?? '');
        $job->description = $description[$languageCode] ?? ($description['en'] ?? '');
        $job->job_contact_person = $job_contact_person[$languageCode] ?? ($job_contact_person['en'] ?? '');
        $job->job_address = $job_address[$languageCode] ?? ($job_address['en'] ?? '');

        return $this->success(__('Success'), $job);
    }
}





