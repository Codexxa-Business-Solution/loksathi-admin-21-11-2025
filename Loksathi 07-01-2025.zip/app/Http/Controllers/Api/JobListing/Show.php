<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobListing;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Show extends BaseApiController
{
    public function __invoke(Request $request, $id): JsonResponse
    {
        $jobListing = JobListing::with(['jobCategory', 'tags'])
            ->where('is_published', true)
            ->findOrFail($id);

        return $this->success(__('Success'), $jobListing);
    }
}





