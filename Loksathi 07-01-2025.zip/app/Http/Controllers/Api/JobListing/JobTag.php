<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Tag;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JobTag extends BaseApiController
{
   
    public function __invoke(Request $request): JsonResponse
    {
         $tags = Tag::orderBy('name')->get();

        return $this->success(__('Success'), $tags);
    }
}
