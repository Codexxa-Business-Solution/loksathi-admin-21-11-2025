<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobListing;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    const MAX_RADIUS_KM = 100;

    public function __invoke(Request $request): JsonResponse
    {
        $language = $this->getLanguage($request); 
        $languageCode = $language->short_name;

        $query = JobListing::query()
            ->with(['jobCategory', 'tags'])
            ->where('is_published', true)
            ->whereJsonContains('language_id', $language->id)
            ->where('expiry_date', '>=', Carbon::now()->format('Y-m-d'));

        if ($request->filled('category_id')) {
            $query->where('job_category_id', $request->category_id);
        }

        if ($request->filled('search')) {
            $searchTerm = '%' . $request->search . '%';
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'like', $searchTerm)
                  ->orWhere('description', 'like', $searchTerm)
                  ->orWhere('location', 'like', $searchTerm);
            });
        }

        $latitude = $request->get('latitude');
        $longitude = $request->get('longitude');
        $radius = min($request->get('radius', self::MAX_RADIUS_KM), self::MAX_RADIUS_KM);

        if ($latitude && $longitude) {
            $haversine = "(
                6371 * acos(
                    cos(radians(?)) * 
                    cos(radians(latitude)) * 
                    cos(radians(longitude) - radians(?)) + 
                    sin(radians(?)) * 
                    sin(radians(latitude))
                )
            )";

            $query->whereRaw("latitude IS NOT NULL AND longitude IS NOT NULL")
                ->selectRaw("*, {$haversine} AS distance", [$latitude, $longitude, $latitude])
                ->orderBy('distance');
        }

        $perPage = $request->input('per_page', 30);
        $jobListings = $query->simplePaginate($perPage);

        $jobListings->getCollection()->transform(function ($job) use ($languageCode) {
            $title = json_decode($job->title, true);
            $description = json_decode($job->description, true);
            
            $job_contact_person = json_decode($job->job_contact_person, true);
            $job_address = json_decode($job->job_address, true);

            $job->title = $title[$languageCode] ?? ($title['en'] ?? '');
            $job->description = $description[$languageCode] ?? ($description['en'] ?? '');

            $job->job_contact_person = $job_contact_person[$languageCode] ?? ($job_contact_person['en'] ?? '');
            $job->job_address = $job_address[$languageCode] ?? ($job_address['en'] ?? '');



            return $job;
        });

        return $this->success(__('Success'), $jobListings);
    }
}
