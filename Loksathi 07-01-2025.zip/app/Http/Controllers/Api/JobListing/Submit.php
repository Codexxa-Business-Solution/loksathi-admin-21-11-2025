<?php

namespace App\Http\Controllers\Api\JobListing;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Business\StoreBusinessRequest;
use App\Models\Business;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreJobListingRequest;
use App\Models\JobListing;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;


class Submit extends BaseApiController
{
    public function __invoke(Request $request): JsonResponse
    {
        $user = auth()->user();
        
        $language = $this->getLanguage($request); 
        $languageCode = $language->short_name;
        
        $jobListing = new JobListing();
        $jobListing->user_id = $user->id;
        
        $userTitle = $request->get('title');
        $userDescription = $request->get('description');
        
        $title = [
            'en' => $languageCode === 'en' ? $userTitle : null,
            'hi' => $languageCode === 'hi' ? $userTitle : null,
            'mr' => $languageCode === 'mr' ? $userTitle : null,
        ];
        
        $description = [
            'en' => $languageCode === 'en' ? $userDescription : null,
            'hi' => $languageCode === 'hi' ? $userDescription : null,
            'mr' => $languageCode === 'mr' ? $userDescription : null,
        ];
        
        $languageIds = [$language->id];
        
        $jobListing->language_id = json_encode($languageIds);
        $jobListing->title = json_encode($title, JSON_UNESCAPED_UNICODE);
        $jobListing->description = json_encode($description, JSON_UNESCAPED_UNICODE);

    
        $jobListing->location = $request->get('location');
        $jobListing->latitude = $request->get('latitude');
        $jobListing->longitude = $request->get('longitude');
        $jobListing->salary = $request->get('salary');
        $jobListing->experience = $request->get('experience');
        $jobListing->job_type = $request->get('job_type');
        $jobListing->position = $request->get('position');
        $jobListing->contact_number = $request->get('contact_number');
        $jobListing->contact_name = $request->get('contact_name');
        $jobListing->job_category_id = $request->get('job_category_id');
        $jobListing->expiry_date = $request->get('expiry_date');
        $jobListing->is_published = $request->has('is_published');
        $jobListing->is_premium = $request->has('is_premium');
    
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::JOB_LISTINGS_DIR_NAME, $name);
            $jobListing->image = AppConstants::JOB_LISTINGS_DIR_NAME . $name;
        }
    
        $jobListing->save();
    
        if ($request->has('tags')) {
            $jobListing->tags()->sync($request->get('tags'));
        }
    
        return $this->success('Job Request Submitted Successfully', $jobListing);
    }


}
