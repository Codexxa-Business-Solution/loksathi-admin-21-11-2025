<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Auth\RegisterRequest;
use Illuminate\Http\JsonResponse;

class Register extends BaseApiController
{
    //
    public function __invoke(RegisterRequest $request): JsonResponse
    {

        try {

            $blood_group = $request->get('blood_group');
            $stateId = $request->get('state_id');
            $districtId = $request->get('district_id');
            $talukaId = $request->get('taluka_id');

            // find user
            $user = auth()->user();

            // if user not exist
            if (!$user) {
                // send error response
                return $this->failed('(SMD:RC01) - You are not authorized for this request.');
            }

            // update details
            $user->name = $request->get('name');
            $user->email = $request->get('email');

            // update addition info
            // update info
            $user->updateInfo([
                'state_id' => $stateId,
                'district_id' => $districtId,
                'taluka_id' => $talukaId,
            ]);
            $user->blood_group = $blood_group;

            if ($request->get('device_type') == "android") {
                $user->device_type = $request->get('device_type');
                $user->android_push_id = $request->get('push_token');
            }

            $user->is_registered = true;

            // Generate referral code if not exists
            if (!$user->referral_code) {
                $user->generateReferralCode();
            }

            $user->save();

            // Check if request has referral code and process referral reward
            if ($request->has('referral_code')) {

                $referralCode = $request->get('referral_code');

                // Find the user with this referral code
                $referrer = \App\Models\User::where('referral_code', $referralCode)->first();
                
                //
                if ($referrer) {
                    
                    $user->referred_by = $referrer->id;
                    $user->save();
                    
                    $referrer->addToWallet(10, 'referral_reward');
                }
            }

            // send success response
            return $this->success('User registration completed.', $user);

        } catch (\Exception $exception) {

            // send error response
            return $this->failed('(SMD:RC02) - Sorry for inconvenience. Some error occurred while sending otp. Please try after some time.');

        }

    }
}
