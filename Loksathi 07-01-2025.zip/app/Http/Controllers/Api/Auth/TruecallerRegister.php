<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Auth\RegisterRequest;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;

class TruecallerRegister extends BaseApiController
{
    //
    public function __invoke(RegisterRequest $request): JsonResponse
    {

        try {

            if (is_null($request->get('phone'))) {
                return $this->failed('(SMD:RC01) - Sorry for inconvenience. Some error occurred while registering. Please try after some time.');
            }

            // find user
            $user = User::where('phone', $request->get('phone'))
                ->first();

            // if user not exist
            if (!$user) {
                $user = new User();
                $user->phone = $request->get('phone');
            }

            // update details
            $user->name = $request->get('name');
            $user->email = $request->get('email');
            $user->otp_limit = 0;
            $user->otp_reset_time = null;
            $user->is_registered = true;
            $user->api_token = Str::random(60);
            $user->phone_verified_at = now();

            if ($request->get('device_type') == "android") {
                $user->android_push_id = $request->get('push_token');
            }

            $user->save();

            // update addition info
            $user->updateInfo([
                'district' => $request->get('district')
            ]);

            // send success response
            return $this->success('User registration completed.', $user);

        } catch (\Exception $exception) {

            // send error response
            return $this->failed('(SMD:RC02) - Sorry for inconvenience. Some error occurred while registering. Please try after some time.', $exception->getMessage());

        }

    }
}
