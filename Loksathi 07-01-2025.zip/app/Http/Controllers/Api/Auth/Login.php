<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Auth\LoginRequest;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;

class Login extends BaseApiController
{
    public function __invoke(LoginRequest $request): JsonResponse
    {
        try 
        {
            $user = User::where('phone', $request->get('phone'))
                ->first();

            if (!$user || ($user->otp !== $request->get('otp'))) {
                return $this->failed('OTP does\'t match. Please make sure you entered correct otp.');
            }

            $user->otp_limit = 0;
            $user->otp_reset_time = null;
            $user->api_token = Str::random(60);
            $user->phone_verified_at = now();

            if ($request->get('device_type') == "android") {
                $user->device_type = $request->get('device_type');
                $user->android_push_token = $request->get('push_token');
            }

            if (!$user->referral_code) {
                $user->generateReferralCode();
            }

            $user->save();

            return $this->success('Phone number verified successfully.', $user);

        } catch (\Exception $exception) {

            return $this->failed('(SMD:LC01) - Sorry for inconvenience. Some error occurred while checking otp. Please try after some time.', $exception->getMessage());

        }

    }
}
