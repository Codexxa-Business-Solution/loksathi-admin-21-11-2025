<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Auth\SendOtpRequest;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use App\Services\OtpService;


class SendOtp extends BaseApiController
{
    //
    public function __invoke(SendOtpRequest $request): JsonResponse
    {
        try 
        {
            $user = User::where('phone', $request->get('phone'))
                ->first();

            if (!$user) {
                $user = new User();
                $user->phone = $request->get('phone');
            }

            if ($user->otp_limit == 5) {
                if (Carbon::parse($user->otp_reset_time) < Carbon::now()) {
                    return $this->failed('OTP limit has been reached to your phone number please try after 15 min.');
                } else {
                    $user->otp_limit = 0;
                }
            }
            
            $current_otp = random_int(100000, 999999);
            $user->otp = $current_otp;
            $user->save();

            $response = OtpService::sendOtp($request->get('phone'), $current_otp);
            
            return $this->success('One time password (OTP) has been sent to your mobile number successfully.', $response);
        } catch (\Exception $exception) {

            return $this->failed('(SMD:SOC01) - Sorry for inconvenience. Some error occurred while sending otp. Please try after some time. ' . $exception->getMessage());
        }
    }
}
