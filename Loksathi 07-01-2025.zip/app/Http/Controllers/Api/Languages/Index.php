<?php

namespace App\Http\Controllers\Api\Languages;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Language;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        try {

            $languages = Language::all();

            return $this->success(__('messages.languages_index_success'), $languages);

        } catch (Exception $exception) {

            return $this->failed(__('messages.languages_index_failed'), $exception->getMessage());

        }

    }
}
