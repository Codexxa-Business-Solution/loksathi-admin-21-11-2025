<?php

namespace App\Http\Controllers\Api\Suggestion;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Suggestion;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    /**
     * Handle the suggestions request
     */
    public function __invoke(Request $request): JsonResponse
    {
        $query = Suggestion::query()
            ->orderBy('index', 'asc')
            ->orderBy('created_at', 'desc');
            
        // Get per_page parameter or default to 30
        $perPage = $request->input('per_page', 30);
        
        $suggestions = $query->simplePaginate($perPage);

        return $this->success(__('Success'), $suggestions);
    }
}
