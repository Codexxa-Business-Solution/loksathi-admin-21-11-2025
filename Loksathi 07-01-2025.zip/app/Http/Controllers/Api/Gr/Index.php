<?php

namespace App\Http\Controllers\Api\Gr;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\Gr;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request): JsonResponse
    {

        $language = $this->getLanguage($request);

        $grs = Gr::query()
            ->where('language_id', $language->id)
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);

        return $this->success(__('Success'), $grs);
    }
}
