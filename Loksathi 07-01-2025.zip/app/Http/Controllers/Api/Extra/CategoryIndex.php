<?php

namespace App\Http\Controllers\Api\Extra;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\ExtraCategory;
use Illuminate\Http\Request;

class CategoryIndex extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {
        $query = ExtraCategory::query()
            // ->where('is_published', true)
            ->orderBy('name', 'asc');

        // Filter by type if provided
        if ($request->has('type') && in_array($request->get('type'), ['business', 'service', 'social'])) {
            $query->where('type', $request->get('type'));
        }

        $categories = $query->get();

        // return response
        return $this->success(__('messages.start_success'), $categories);
    }
}
