<?php

namespace App\Http\Controllers\Api\BuySell;

use App\Enums\AppConstants;
use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Group\BuySellMessageRequest;
use App\Models\BuySellMessage;
use App\Services\BunnyCdnStorage;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;

class Submit extends BaseApiController
{
    //
    public function __invoke(BuySellMessageRequest $request): JsonResponse
    {

        $user = auth()->user();

        $todayMessage = BuySellMessage::whereDate('created_at', Carbon::now())
            ->where('user_id', '=', $user->id)
            ->first();

        if (!$todayMessage) {

            $buySellMessage = new BuySellMessage();
            $buySellMessage->user_id = $user->id;
            $buySellMessage->buysell_group_id = $request->get('group_id');
            $buySellMessage->type = $request->get('type');
            $buySellMessage->category = $request->get('category');
            $buySellMessage->description = $request->get('description');
            $buySellMessage->whatsapp_number = $request->get('whatsapp_number');
            $buySellMessage->address = $request->get('address');
            $buySellMessage->latitude = $request->get('latitude');
            $buySellMessage->longitude = $request->get('longitude');
            $buySellMessage->is_published = true;
            $buySellMessage->save();

            // images
            $images = $request->get('images');
            if ($images) {
                $decodedImages = json_decode($images);
                $bunnyImages = [];
                foreach ($decodedImages as $image) {
                    $decBase64Image = base64_decode($image->value);
                    $bunnyCdnStorage = new BunnyCdnStorage();
                    $name = $bunnyCdnStorage->uploadApi($image->name, $decBase64Image, AppConstants::BUYSELL_DIR_NAME);
                    $bunnyImages[] = $name;
                }
                $buySellMessage->images = json_encode($bunnyImages);
                $buySellMessage->save();
            }

            // send user buysell saved notification
            // send other users buysell saved notification

            return $this->success(__('messages.buysell_submit_success'), $buySellMessage);

        } else {

            return $this->failed(__('messages.submit_message_limit'));
        }

    }

}
