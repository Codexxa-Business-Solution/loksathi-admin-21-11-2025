<?php

namespace App\Http\Controllers\Api\BuySell;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\BuySellMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeleteMessage extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        $user = auth()->user();

        $groupMessage = BuySellMessage::find($id);

        if ($groupMessage->user_id != $user->id) {
            return $this->error('You are not authorized to delete this message.');
        }

        // delete
        $groupMessage->delete();

        return $this->success('Deleted successfully.', null);

    }
}
