<?php

namespace App\Http\Controllers\Api\JobCategory;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\JobCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class Index extends BaseApiController
{
    public function __invoke(Request $request): JsonResponse
    {
        $jobCategories = JobCategory::query()
            ->orderBy('name', 'asc')
            ->get();

        return $this->success(__('Success'), $jobCategories);
    }
}