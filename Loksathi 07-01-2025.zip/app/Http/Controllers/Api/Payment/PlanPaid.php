<?php

namespace App\Http\Controllers\Api\Payment;

use App\Enums\PaymentStatus;
use App\Http\Controllers\Api\BaseApiController;
use App\Models\PlanPurchase;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Razorpay\Api\Api;


class PlanPaid extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {


        try {

            // merchant id
            
            
            $merchantId = "rzp_live_RJ3Pje570C6kuj";
            $merchantKey = "KmppXUhK2VYoEngFC478yZKL";
        
        
            // $merchantId = "rzp_test_AbVYyLLlmWprC3";
            // $merchantKey = "1eCyBAe5n6t7VS4eXKXObTlC";

            $api = new Api($merchantId, $merchantKey);

            $razorpay_signature = $request->get('razorpay_signature');
            $razorpay_payment_id = $request->get('razorpay_payment_id');
            $razorpay_order_id = $request->get('razorpay_order_id');

            //
            $user = auth()->user();

            // fetch
            $order = $api->order->fetch($razorpay_order_id);
            $payment = $api->payment->fetch($razorpay_payment_id);

            if ($razorpay_signature != hash_hmac('sha256', $razorpay_order_id . "|" . $razorpay_payment_id, $merchantKey)) {
                return $this->failed('RC00 : Payment failed! Please try again.');
            }

            if (!$order) {
                return $this->failed('RC01 : Payment failed! Please try again.');
            }

            if (!$payment) {
                return $this->failed('RC02 : Payment failed! Please try again.');
            }

            if ($order->status !== 'paid') {
                return $this->failed('RC03 : Payment failed! Please try again.');
            }
      
            $planPurchase = PlanPurchase::where('order_id', $order->receipt)
                ->first();
            if (!$planPurchase)
                return $this->failed('RC04 : Payment failed! Please try again.');

            $planPurchase->razorpay_signature = $razorpay_signature;
            $planPurchase->razorpay_payment_id = $razorpay_payment_id;
            $planPurchase->status = PaymentStatus::STATUS_PAID;
            $planPurchase->expired_at = Carbon::today()->addDays($planPurchase->plan_days);

            $planPurchase->save();

            $user->is_premium = true;
            $user->plan_expired_at = Carbon::today()->addDays($planPurchase->plan_days);
            $user->save();
            
            return $this->success("Plan paid successfully.", $user);

        } catch (\Exception $exception) {
            return $this->failed("Something went wrong! Please try again later.", $exception->getMessage());
        }

    }

}
