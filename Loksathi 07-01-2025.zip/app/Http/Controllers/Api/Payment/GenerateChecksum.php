<?php

namespace App\Http\Controllers\Api\Payment;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\BusinesPurchase;
use App\Models\Business;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Razorpay\Api\Api;


class GenerateChecksum extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        try {

            //
            $user = auth()->user();

            // merchant id
            // $merchantId = "rzp_test_AbVYyLLlmWprC3";
            // $merchantKey = "1eCyBAe5n6t7VS4eXKXObTlC";
            
            
                $merchantId = "rzp_live_RJ3Pje570C6kuj";
                $merchantKey = "KmppXUhK2VYoEngFC478yZKL";

            // testing
//            $merchantId = "rzp_test_33eqRPxPVBHI86";
//            $merchantKey = "pHdilgwPkXBQnZ21pv6rnJNB";

            // business
            $business = Business::find($id);
            if (!$business)
                return $this->failed('Business not found.');

            // check already paid
            if ($business->is_paid && $business->expired_at > now())
                return $this->failed('Business is already live.');

            $businessPurchase = new BusinesPurchase();
            $businessPurchase->order_id = "SMB" . strtoupper(uniqid());
            $businessPurchase->business_id = $business->id;
            $businessPurchase->save();

            $api = new Api($merchantId, $merchantKey);
            $order = $api->order->create([
                'receipt' => $businessPurchase->order_id,
                'amount' => 4900,
                'currency' => 'INR',
                'payment_capture' => 1,
                'notes' => [
                    'business_id' => $business->id,
                    'business_purchase_id' => $businessPurchase->id,
                ],
            ]);

            // order data
            $orderData = array(
                'id' => $order->id,
                'amount' => $order->amount,
                'receipt' => $order->receipt,
                'currency' => $order->currency,
                'active_key' => $merchantId,
            );

            return $this->success("Checksum generated successfully.", $orderData);

        } catch (\Exception $exception) {
            return $this->failed("Something went wrong! Please try again later.", $exception->getMessage());
        }

    }
}
