<?php

namespace App\Http\Controllers\Api\Payment;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\PlanPurchase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Razorpay\Api\Api;


class GeneratePlanChecksum extends BaseApiController
{
    public function __invoke(Request $request): JsonResponse
    {
        $user = auth()->user();
        


        // merchant id
        // $merchantId = "rzp_test_AbVYyLLlmWprC3";
        // $merchantKey = "1eCyBAe5n6t7VS4eXKXObTlC";
        
        $merchantId = "rzp_live_RJ3Pje570C6kuj";
        $merchantKey = "KmppXUhK2VYoEngFC478yZKL";

        // testing
//        $merchantId = "rzp_test_33eqRPxPVBHI86";
//        $merchantKey = "pHdilgwPkXBQnZ21pv6rnJNB";

        $planPrice = $request->get('planPrice');
        $planDay = $request->get('planDay');
        
        
        $planSubscriptionId = $request->get('planId');
        $planAgentId = $request->get('agentId');
        
        
        if ($user->is_active)
        {
            return $this->failed('You are already premium active member');
        }
        
        $planPurchase = new PlanPurchase();
        $planPurchase->order_id = "SM" . strtoupper(uniqid());
        $planPurchase->user_id = $user->id;
        $planPurchase->plan_price = $planPrice;
        $planPurchase->plan_days = $planDay;
        
        $planPurchase->subscription_id = $planSubscriptionId;
        $planPurchase->agent_id = $planAgentId;
        
        $planPurchase->save();
    

        $api = new Api($merchantId, $merchantKey);
        $order = $api->order->create(array(
            'receipt' => $planPurchase->order_id,
            'amount' => $planPurchase->plan_price * 100,
            'currency' => 'INR',
            'notes' => array('user' => $user->id)
        ));

        $orderData = array(
            'id' => $order->id,
            'amount' => $order->amount,
            'receipt' => $order->receipt,
            'currency' => $order->currency,
            'active_key' => $merchantId,
        );

        return $this->success("Checksum generated successfully.", $orderData);

    }

}
