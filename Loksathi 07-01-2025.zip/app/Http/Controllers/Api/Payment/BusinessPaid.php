<?php

namespace App\Http\Controllers\Api\Payment;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\BusinesPurchase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Razorpay\Api\Api;


class BusinessPaid extends BaseApiController
{
    //
    public function __invoke(Request $request, $id): JsonResponse
    {

        // merchant id
        
        
        $merchantId = "rzp_live_RJ3Pje570C6kuj";
        $merchantKey = "KmppXUhK2VYoEngFC478yZKL";
        
        // $merchantId = "rzp_test_AbVYyLLlmWprC3";
        // $merchantKey = "1eCyBAe5n6t7VS4eXKXObTlC";

        // testing
//        $merchantId = "rzp_test_33eqRPxPVBHI86";
//        $merchantKey = "pHdilgwPkXBQnZ21pv6rnJNB";

        $api = new Api($merchantId, $merchantKey);

        $razorpay_signature = $request->get('razorpay_signature');
        $razorpay_payment_id = $request->get('razorpay_payment_id');
        $razorpay_order_id = $request->get('razorpay_order_id');

        //
        $user = auth()->user();

        // fetch
        $order = $api->order->fetch($razorpay_order_id);
        $payment = $api->payment->fetch($razorpay_payment_id);

        if ($razorpay_signature != hash_hmac('sha256', $razorpay_order_id . "|" . $razorpay_payment_id, $merchantKey)) {
            return $this->failed('RC00 : Payment failed! Please try again.');
        }

        if (!$order) {
            return $this->failed('RC01 : Payment failed! Please try again.');
        }

        if (!$payment) {
            return $this->failed('RC02 : Payment failed! Please try again.');
        }

        if ($order->status !== 'paid') {
            return $this->failed('RC03 : Payment failed! Please try again.');
        }

        // business
        $businessPurchase = BusinesPurchase::with('business.category')
            ->where('order_id', $order->receipt)
            ->first();
        if (!$businessPurchase)
            return $this->failed('RC04 : Payment failed! Please try again.');

        //
        $businessPurchase->business->razorpay_signature = $razorpay_signature;
        $businessPurchase->business->razorpay_payment_id = $razorpay_payment_id;
        $businessPurchase->business->is_paid = true;
        $businessPurchase->business->save();

        return $this->success("Business paid successfully.", $businessPurchase->business);

    }
}
