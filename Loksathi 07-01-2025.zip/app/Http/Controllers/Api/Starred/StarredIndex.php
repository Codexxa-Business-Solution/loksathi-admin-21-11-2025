<?php

namespace App\Http\Controllers\Api\Starred;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\UserSave;
use Illuminate\Http\Request;

class StarredIndex extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {

        $user = auth()->user();

        //
        $messages = UserSave::query()
            ->with('groupMessage.group', 'quizMessage')
            ->where('user_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);

        return $this->success(__('Starred initialized successfully.'), $messages);

    }
}
