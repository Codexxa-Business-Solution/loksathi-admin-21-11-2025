<?php

namespace App\Http\Controllers\Api\Starred;

use App\Http\Controllers\Api\BaseApiController;
use App\Http\Requests\Api\Starred\StoreStarredRequest;
use App\Models\UserSave;
use Illuminate\Http\JsonResponse;

class StarredStore extends BaseApiController
{
    //
    public function __invoke(StoreStarredRequest $request): JsonResponse
    {

        $user = auth()->user();
        $saveType = $request->get('save_type');
        $saveId = $request->get('save_id');

        // check already starred
        $userSave = UserSave::query()
            ->where('user_id', $user->id)
            ->where('save_type', $saveType)
            ->where('save_id', $saveId)
            ->first();

        // save if not starred
        if (!$userSave) {
            $userSave = new UserSave();
            $userSave->user_id = $user->id;
            $userSave->save_type = $saveType;
            $userSave->save_id = $saveId;
            $userSave->save();
            $message = "Starred successfully.";

        } else {
            $userSave->delete();
            $message = "Unstarred successfully.";
        }

        return $this->success($message, $userSave);

    }
}
