<?php

namespace App\Http\Controllers\Testing;

use App\Http\Controllers\Api\BaseApiController;
use App\Models\News;
use App\Models\NewsCategory;
use App\Models\User;
use Illuminate\Http\Request;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {

        $news = News::latest()->first();

        $title = $news->notification_title;
        if (!$title) {
            $title = $news->name;
        }

        $firebaseFactory = (new Factory)->withServiceAccount(base_path('dignityapp-1cbe2-firebase-adminsdk-npyf1-0c03e2f34b.json'));
        $messaging = $firebaseFactory->createMessaging();

        $lang = NewsCategory::join('languages', 'languages.id', '=', 'news_categories.language_id')
            ->where('news_categories.id', $news->news_category_id)
            ->select('languages.short_name')
            ->first()
            ->short_name;

        $tokens = User::query()
            ->whereIn('phone', ['9823755551'])
            ->pluck('android_push_token')->filter();

        $title = $request->get('notification_title');
        $body = $request->get('message');
        $image = "https://dignityapp.in/" . $news->image;
        $dynamic = "https://loksathinews.in/router?s=news&news_id=" . $news->id;

        foreach (array_chunk($tokens->toArray(), 95) as $tokenGroup) {
            foreach ($tokenGroup as $token) {
                try {
                    $message = CloudMessage::fromArray([
                        'token' => $token,
                        'data' => [
                            "title" => $title,
                            "body" => str_replace("&nbsp;", " ", strip_tags($body)),
                            "image" => $image,
                            "dynamic" => $dynamic,
                            "lang" => $lang
                        ],
                        'android' => [
                            'priority' => 'high',
                        ],
                    ]);

                    $messaging->send($message);
                } catch (\Exception $e) {
                    \Log::error("Failed to send notification for token: {$token}, error: " . $e->getMessage());
                    continue;
                }
            }
        }

    }

}
