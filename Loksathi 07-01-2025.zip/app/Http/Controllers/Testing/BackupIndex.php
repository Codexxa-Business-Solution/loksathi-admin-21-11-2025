<?php

namespace App\Http\Controllers\Testing;

use App\Enums\GroupMessageType;
use App\Http\Controllers\Api\BaseApiController;
use App\Models\Bot;
use App\Models\BotMessage;
use App\Models\District;
use App\Models\State;
use App\Models\Taluka;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Romans\Filter\RomanToInt;

class BackupIndex extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {

        $user = User::first();
        $user->email = "admin@dignityapp.in";
        $user->password = bcrypt('Loksathi@2023');
        $user->save();

//        $quizMessage = QuizMessage::query()->get();

//        foreach ($quizMessage as $message) {
//            $message->scheduled_at = Carbon::parse($message->created_at);
//            $message->save();
//        }
//

//        // constitution hindi
//        $marathiBot = Bot::find(12);
//        foreach ($marathiBot->messages as $botMessage) {
//
//            if (Str::startsWith($botMessage->name, "भाग")) {
//
//                $bhagKey = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "भाग"), ":"));
//                $bhagTitle = Str::before(Str::after($botMessage->name, ":"), "अनुच्छेद");
//
//                $prakaranKey = null;
//                $prakaranTitle = null;
//
//                // check bhag title contains prakaran
//                if (Str::contains($botMessage->name, "अध्याय")) {
//                    $bhagTitle = Str::before(Str::after($botMessage->name, ":"), "अध्याय");
//                    $prakaranKey = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अध्याय"), ":"));
//
//                    $fromPrakaranToAnuched = Str::before(Str::after($botMessage->name, "अध्याय"), "अनुच्छेद");
//                    $prakaranTitle = Str::replace(" ", "", Str::after($fromPrakaranToAnuched, ":"));
//                }
//
//                $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//
//                $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                $name = Str::after($afterAnuchecd, ":");
//
//                $botMessage->name = Str::replace("\n", "", $name);
//                $botMessage->key = $key;
//                $botMessage->main_key = $bhagKey;
//                $botMessage->main_key_title = Str::replace("\n", "", $bhagTitle);
//                $botMessage->main_sub_key = $prakaranKey;
//                $botMessage->main_sub_key_title = Str::replace("\n", "", $prakaranTitle);
//
//                $botMessage->save();
//
//                continue;
//
//            }
//
//            if (Str::startsWith($botMessage->name, "अध्याय")) {
//
//                $prakaranKey = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अध्याय"), ":"));
//                $prakaranTitle = Str::before(Str::after($botMessage->name, ":"), "अनुच्छेद");
//
//                $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//
//                $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                $name = Str::after($afterAnuchecd, ":");
//
//                $botMessage->name = Str::replace("\n", "", $name);
//                $botMessage->key = $key;
//                $botMessage->main_sub_key = $prakaranKey;
//                $botMessage->main_sub_key_title = Str::replace("\n", "", $prakaranTitle);
//
//                $botMessage->save();
//
//                continue;
//
//            }
//
//            if (Str::startsWith($botMessage->name, "अनुच्छेद")) {
//
//                $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//                $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                $name = Str::after($afterAnuchecd, ":");
//
//                $botMessage->name = Str::replace("\n", "", $name);
//                $botMessage->key = $key;
//
//                $botMessage->save();
//
//            } else {
//
//                if (Str::contains($botMessage->name, "अनुच्छेद")) {
//
//                    $afterBefore = Str::before($botMessage->name, "अनुच्छेद");
//                    $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//                    $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                    $name = Str::after($afterAnuchecd, ":");
//
//                    $botMessage->name = Str::replace("\n", "", $name);
//                    $botMessage->title_prefix = Str::replace("\n", "", $afterBefore);
//                    $botMessage->key = $key;
//
//                    $botMessage->save();
//
//                }
//
//            }
//
//        }

        // constitution marathi
//        // clear bot messages
//        $marathiBot = Bot::find(11);
//        foreach ($marathiBot->messages as $botMessage) {
//            $botMessage->delete();
//        }
//
//        $consJson = json_decode(File::get('data/consmarathi1.json',), true);
//
//        foreach ($consJson as $index => $cons) {
//
//            $engBotMessage = new BotMessage();
//            $engBotMessage->bot_id = $marathiBot->id;
//            $engBotMessage->type = GroupMessageType::TYPE_MESSAGE;
//            $engBotMessage->name = $cons['HindiTitle'];
//            $engBotMessage->key = $index;
//            $engBotMessage->message = Str::replace("\n", "<br>", $cons['HindiDesc']);
//            $engBotMessage->save();
//        }
//
//        dd('done');

        // clear bot messages
//        $marathiBot = Bot::find(11);
//        foreach ($marathiBot->messages as $botMessage) {
//
//            if (Str::startsWith($botMessage->name, "भाग")) {
//
//                $bhagKey = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "भाग"), ":"));
//                $bhagTitle = Str::before(Str::after($botMessage->name, ":"), "अनुच्छेद");
//
//                $prakaranKey = null;
//                $prakaranTitle = null;
//
//                // check bhag title contains prakaran
//                if (Str::contains($botMessage->name, "प्रकरण")) {
//                    $bhagTitle = Str::before(Str::after($botMessage->name, ":"), "प्रकरण");
//                    $prakaranKey = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "प्रकरण"), ":"));
//
//                    $fromPrakaranToAnuched = Str::before(Str::after($botMessage->name, "प्रकरण"), "अनुच्छेद");
//                    $prakaranTitle = Str::replace(" ", "", Str::after($fromPrakaranToAnuched, ":"));
//                }
//
//                $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//
//                $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                $name = Str::after($afterAnuchecd, ":");
//
//                $botMessage->name = Str::replace("\n", "", $name);
//                $botMessage->key = $key;
//                $botMessage->main_key = $bhagKey;
//                $botMessage->main_key_title = Str::replace("\n", "", $bhagTitle);
//                $botMessage->main_sub_key = $prakaranKey;
//                $botMessage->main_sub_key_title = Str::replace("\n", "", $prakaranTitle);
//
//                $botMessage->save();
//
//                continue;
//
//            }
//
//            if (Str::startsWith($botMessage->name, "प्रकरण")) {
//
//                $prakaranKey = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "प्रकरण"), ":"));
//                $prakaranTitle = Str::before(Str::after($botMessage->name, ":"), "अनुच्छेद");
//
//                $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//
//                $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                $name = Str::after($afterAnuchecd, ":");
//
//                $botMessage->name = Str::replace("\n", "", $name);
//                $botMessage->key = $key;
//                $botMessage->main_sub_key = $prakaranKey;
//                $botMessage->main_sub_key_title = Str::replace("\n", "", $prakaranTitle);
//
//                $botMessage->save();
//
//                continue;
//
//            }
//
//            if (Str::startsWith($botMessage->name, "अनुच्छेद")) {
//
//                $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//                $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                $name = Str::after($afterAnuchecd, ":");
//
//                $botMessage->name = Str::replace("\n", "", $name);
//                $botMessage->key = $key;
//
//                $botMessage->save();
//
//            } else {
//
//                if (Str::contains($botMessage->name, "अनुच्छेद")) {
//
//                    $afterBefore = Str::before($botMessage->name, "अनुच्छेद");
//                    $afterAnuchecd = Str::after($botMessage->name, "अनुच्छेद");
//                    $key = Str::replace(" ", "", Str::before(Str::after($botMessage->name, "अनुच्छेद"), ":"));
//                    $name = Str::after($afterAnuchecd, ":");
//
//                    $botMessage->name = Str::replace("\n", "", $name);
//                    $botMessage->title_prefix = Str::replace("\n", "", $afterBefore);
//                    $botMessage->key = $key;
//
//                    $botMessage->save();
//
//                }
//
//            }
//
//        }

        dd('done');

//        $consJson = json_decode(File::get('data/consmarathi1.json',), true);
//
//        foreach ($consJson as $index => $cons) {
//
//            $engBotMessage = new BotMessage();
//            $engBotMessage->bot_id = $marathiBot->id;
//            $engBotMessage->type = GroupMessageType::TYPE_MESSAGE;
//            $engBotMessage->name = $cons['HindiTitle'];
//            $engBotMessage->key = $index;
//            $engBotMessage->message = Str::replace("\n", "<br>", $cons['HindiDesc']);
//
//            if (!Str::startsWith($engBotMessage->name, "भाग") && Str::startsWith($engBotMessage->name, "प्रकरण")) {
//                if (Str::contains($engBotMessage->name, "अनुच्छेद")) {
//                    $name = Str::after($engBotMessage->name, ":");
//                    $key = Str::replace(" ", "", Str::before(Str::after($engBotMessage->name, "अनुच्छेद"), ":"));
//                    $engBotMessage->name = $name;
//                    $engBotMessage->key = $key;
//                }
//            }
//
//            $engBotMessage->save();
//
//            $engBotMessage = new BotMessage();
//            $engBotMessage->bot_id = $engBot->id;
//            $engBotMessage->type = GroupMessageType::TYPE_MESSAGE;
//            $engBotMessage->name = $cons['EngTitle'];
//            $engBotMessage->key = $index;
//            $engBotMessage->message = Str::replace("\n", "<br>", $cons['EngDesc']);
//
//            if (!Str::startsWith($engBotMessage->name, "Part") && !Str::startsWith($engBotMessage->name, "Chapter")) {
//                if (Str::contains($engBotMessage->name, "Article")) {
//                    $name = Str::after($engBotMessage->name, ":");
//                    $key = Str::replace(" ", "", Str::before(Str::after($engBotMessage->name, "Article"), ":"));
//                    $engBotMessage->name = $name;
//                    $engBotMessage->key = $key;
//                }
//            }
//
//            $engBotMessage->save();
//        }

        // constitute
        // clear bot messages
//        $penalCodeBot = Bot::find(10);
//        foreach ($penalCodeBot->messages as $botMessage) {
//            $botMessage->delete();
//        }
//        $consBot = Bot::find(12);
//        foreach ($consBot->messages as $botMessage) {
//            $botMessage->delete();
//        }
//
//        $consJson = json_decode(File::get('data/hindi_consmarathi.json',), true);
//        $penalJson = json_decode(File::get('data/hindi_ipcmarathi1.json',), true);
//
//        foreach ($consJson as $index => $cons) {
//            $engBotMessage = new BotMessage();
//            $engBotMessage->bot_id = $consBot->id;
//            $engBotMessage->type = GroupMessageType::TYPE_MESSAGE;
//            $engBotMessage->name = $cons['HindiTitle'];
//            $engBotMessage->key = $index;
//            $engBotMessage->message = Str::replace("\n", "<br>", $cons['HindiDesc']);
//            $engBotMessage->save();
//        }
//
//        foreach ($penalJson as $index => $cons) {
//            $engBotMessage = new BotMessage();
//            $engBotMessage->bot_id = $penalCodeBot->id;
//            $engBotMessage->type = GroupMessageType::TYPE_MESSAGE;
//            $engBotMessage->name = $cons['HindiTitle'];
//            $engBotMessage->key = $index;
//            $engBotMessage->message = Str::replace("\n", "<br>", $cons['HindiDesc']);
//            $engBotMessage->save();
//        }

        dd("done");

    }

    // penal code bot eng and marathi
    private function getPinalCodeBot()
    {
        // clear bot messages
//        $bot = Bot::find(6);
//        foreach ($bot->messages as $botMessage) {
//            $botMessage->delete();
//        }
//        $bot = Bot::find(7);
//        foreach ($bot->messages as $botMessage) {
//            $botMessage->delete();
//        }

        $penalCodeJson = json_decode(File::get('data/ipcmarathi1.json',), true);

        $botMessages = array();
        $hindiBotMessages = array();

        foreach ($penalCodeJson as $penalCode) {

            $engBotMessage = new BotMessage();
            $engBotMessage->bot_id = 7;

            $hindiBotMessage = new BotMessage();
            $hindiBotMessage->bot_id = 6;

            // eng title chapter number / section number
            if (Str::startsWith($penalCode['EngTitle'], "Chapter")) {

                // english chapter and section number title parser
                $forChapterTitle = Str::after($penalCode['EngTitle'], ":");

                try {
                    $filter = new RomanToInt();
                    $engChapterNumber = $filter->filter(Str::replace(" ", "", Str::before(Str::after($penalCode['EngTitle'], "Chapter"), "(")));
                } catch (\Exception $exception) {
                }

                $engSectionNumber = Str::replace(" ", "", Str::before(Str::after($forChapterTitle, "Section"), ":"));
                $engChapterTitle = Str::replace("\n", "", Str::before($forChapterTitle, ":"));
                $engSectionTitle = $engChapterTitle;

                $key = preg_replace('/[^0-9]/', '', $engSectionNumber);
                $sub_key = preg_replace('/[^a-zA-Z]/', '', $engSectionNumber);

                // english bot message
                $engBotMessage->name = $engSectionTitle;
                $engBotMessage->key = $key;
                $engBotMessage->sub_key = $sub_key;
                $engBotMessage->main_key = $engChapterNumber;
                $engBotMessage->main_key_title = $engChapterTitle;

                // hindi chapter and section number title parser
                $forChapterTitle = Str::after($penalCode['HindiTitle'], ":");
                $hindiChapterNumber = Str::replace(" ", "", Str::before(Str::after($penalCode['HindiTitle'], "प्रकरण"), ":"));
                $hindiSectionNumber = Str::replace(" ", "", Str::before(Str::after($forChapterTitle, "कलम"), ":"));
                $hindiChapterTitle = Str::replace("\n", "", Str::before($forChapterTitle, ":"));
                $hindiSectionTitle = $hindiChapterTitle;

                // section
                $sections = explode("-", $hindiSectionNumber);

                // hindi bot message
                $hindiBotMessage->name = $hindiSectionTitle;
                $hindiBotMessage->key = $this->safeValue(0, $sections);
                $hindiBotMessage->sub_key = $this->safeValue(1, $sections);
                $hindiBotMessage->main_key = $hindiChapterNumber;
                $hindiBotMessage->main_key_title = $hindiChapterTitle;

                echo "Main Key: " . $hindiBotMessage->main_key . " | Key: " . $hindiBotMessage->key . " | Sub Key:  " . $hindiBotMessage->sub_key . "<br>";
                echo "Main Key: " . $engBotMessage->main_key . " | Key: " . $engBotMessage->key . " | Sub Key:  " . $engBotMessage->sub_key . "<br>";

            } else {

                // eng parser
                $engSectionTitle = Str::replace("\n", "", Str::after($penalCode['EngTitle'], ":"));
                $engSectionNumber = Str::replace(" ", "", Str::before(Str::after($penalCode['EngTitle'], "Section"), ":"));

                $key = preg_replace('/[^0-9]/', '', $engSectionNumber);
                $sub_key = preg_replace('/[^a-zA-Z]/', '', $engSectionNumber);

                // english bot message
                $engBotMessage->name = $engSectionTitle;
                $engBotMessage->key = $key;
                $engBotMessage->sub_key = $sub_key;

                // hindi parser
                $hindiSectionTitle = Str::replace("\n", "", Str::after($penalCode['HindiTitle'], ":"));
                $hindiSectionNumber = Str::replace(" ", "", Str::before(Str::after($penalCode['HindiTitle'], "कलम"), ":"));

                // section
                $sections = explode("-", $hindiSectionNumber);

                // hindi bot message
                $hindiBotMessage->name = $hindiSectionTitle;
                $hindiBotMessage->key = $this->safeValue(0, $sections);
                $hindiBotMessage->sub_key = $this->safeValue(1, $sections);

                echo "Main Key: | Key: " . $hindiBotMessage->key . " | Sub Key:  " . $hindiBotMessage->sub_key . "<br>";
                echo "Main Key: | Key: " . $engBotMessage->key . " | Sub Key:  " . $engBotMessage->sub_key . "<br>";

            }

            $engMessage = Str::replace("\n", "<br>", $penalCode['EngDesc']);
            $hindiMessage = Str::replace("\n", "<br>", $penalCode['HindiDesc']);

            $engBotMessage->type = GroupMessageType::TYPE_MESSAGE;
            $engBotMessage->message = $engMessage;

            $hindiBotMessage->type = GroupMessageType::TYPE_MESSAGE;
            $hindiBotMessage->message = $hindiMessage;

//            $hindiBotMessage->save();
//            $engBotMessage->save();
        }
    }

    // states
    private
    function getLocation()
    {

        // states
        $stateList = json_decode(File::get('data/state_list.json'), true);
        $talukaList = json_decode(File::get('data/taluka_list.json'), true);

        foreach ($stateList as $state) {

            $tempState = new State();
            $tempState->name_mr = $state['state_name'];
            $tempState->name_en = $state['state_name'];
            $tempState->state_id = $state['state_id'];
            $tempState->save();

            foreach ($talukaList as $taluka) {

                if ($state['state_id'] == $taluka['SID']) {

                    $tempDistrict = District::where('district_id', $taluka['CID'])
                        ->first();

                    if (!$tempDistrict) {
                        $tempDistrict = new District();
                        $tempDistrict->state_id = $tempState->id;
                        $tempDistrict->name_mr = $taluka['CN'];
                        $tempDistrict->name_en = $taluka['CN'];
                        $tempDistrict->district_id = $taluka['CID'];
                        $tempDistrict->save();
                    }

                    $tempTaluka = Taluka::where('name_mr', $taluka['TN'])
                        ->first();

                    if (!$tempTaluka) {
                        $tempTaluka = new Taluka();
                        $tempTaluka->district_id = $tempDistrict->id;
                        $tempTaluka->name_mr = $taluka['TN'];
                        $tempTaluka->name_en = $taluka['TN'];
                        $tempTaluka->taluka_id = $taluka['TID'];
                        $tempTaluka->pincode = $taluka['PC'];
                        $tempTaluka->save();
                    }

                }

            }

        }
    }

    //
    private
    function safeValue($key, $array)
    {
        if (array_key_exists($key, $array)) {
            return $array[$key];
        }
        return null;
    }

    // get message
    private
    function getMessageUrl($chatId): string
    {
        return "https://api.telegram.org/bot2037701157:AEPCB29ZCl9wLX4LhTyuczPwVRJ4GGB9Vg/sendMessage?chat_id=" . $chatId . "&text=<b>Poem Submit Request</b>\n\n<b>User:</b> Sample User (999999999)\n\n<b>Content:</b> Blah blah blah\n&parse_mode=html";
    }

}
