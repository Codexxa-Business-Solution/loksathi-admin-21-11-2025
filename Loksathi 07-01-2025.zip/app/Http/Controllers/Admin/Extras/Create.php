<?php

namespace App\Http\Controllers\Admin\Extras;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\State;
use App\Models\GroupCategory;
use App\Models\ExtraCategory;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $users = User::select('id', 'name', 'phone')->get();
        $states = State::select('id', 'name_en', 'name_mr')->get();
        
        $groupCategories = GroupCategory::all();
        
        $categories = ExtraCategory::where('is_published', true)
            ->select('id', 'name', 'type', 'description')
            ->get();
        
        return view('admin.extras.create', compact('users', 'states', 'categories','groupCategories'));
    }
}
