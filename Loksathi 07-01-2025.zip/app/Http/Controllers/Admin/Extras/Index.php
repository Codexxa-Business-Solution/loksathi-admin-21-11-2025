<?php

namespace App\Http\Controllers\Admin\Extras;

use App\Http\Controllers\Controller;
use App\Models\Business;
use App\Models\Group;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $businesses = Business::with('category', 'state', 'district', 'taluka', 'user')
            ->orderBy('id','desc')
            ->get();

        return view('admin.extras.index', compact('businesses'));
    }
}
