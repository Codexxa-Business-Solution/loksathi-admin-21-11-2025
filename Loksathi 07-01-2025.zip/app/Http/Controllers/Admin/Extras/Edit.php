<?php

namespace App\Http\Controllers\Admin\Extras;

use App\Http\Controllers\Controller;
use App\Models\Business;
use App\Models\User;
use App\Models\State;
use App\Models\District;
use App\Models\Taluka;
use App\Models\GroupCategory;
use App\Models\ExtraCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find business
        $business = Business::with(['user', 'state', 'district', 'taluka'])->find($id);

        // check business exists
        if (!$business) {
            abort(404);
        }

        $users = User::select('id', 'name', 'phone')->get();
        $states = State::select('id', 'name_en', 'name_mr')->get();
        $districts = collect();
        $talukas = collect();

        // Load districts and talukas based on business location
        if ($business->state_id) {
            $districts = District::where('state_id', $business->state_id)
                ->select('id', 'name_en', 'name_mr')->get();
        }
        
        if ($business->district_id) {
            $talukas = Taluka::where('district_id', $business->district_id)
                ->select('id', 'name_en', 'name_mr')->get();
        }

        // Load categories
        $categories = ExtraCategory::where('is_published', true)
            ->select('id', 'name', 'type', 'description')
            ->get();
            
        $groupCategories = GroupCategory::all();

        // Load categories for the current business type
        $businessCategories = collect();
        if ($business->type) {
            $businessCategories = ExtraCategory::where('type', $business->type)
                ->where('is_published', true)
                ->select('id', 'name', 'description')
                ->get();
        }

        // return view
        return view('admin.extras.edit', compact('business', 'users', 'states', 'districts', 'talukas', 'categories', 'businessCategories','groupCategories'));

    }
}
