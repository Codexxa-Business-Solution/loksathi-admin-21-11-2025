<?php

namespace App\Http\Controllers\Admin\Extras;

use App\Http\Controllers\Controller;
use App\Models\Business;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $business = Business::find($id);

        if (!$business)
            abort(404);

        // delete
        $business->delete();

        // flash and redirect
        Session::flash('success', 'Business has been deleted successfully.');

        return redirect()->route('admin.extras.index');
    }

}
