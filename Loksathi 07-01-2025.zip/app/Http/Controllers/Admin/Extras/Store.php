<?php

namespace App\Http\Controllers\Admin\Extras;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Models\Business;
use App\Models\User;

use App\Models\GroupCategory;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;

use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

class Store extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'name.en' => 'nullable|string|max:255',
            'name.hi' => 'nullable|string|max:255',
            'name.mr' => 'nullable|string|max:255',
            'description.en' => 'nullable|string',
            'description.hi' => 'nullable|string',
            'description.mr' => 'nullable|string',
            
            'business_address.en' => 'nullable|string',
            'business_address.hi' => 'nullable|string',
            'business_address.mr' => 'nullable|string',
            
            'business_owner_name.en' => 'nullable|string',
            'business_owner_name.hi' => 'nullable|string',
            'business_owner_name.mr' => 'nullable|string',        
            
            
            
            'email' => 'nullable|email|max:255',
            'address' => 'nullable|string',
            'contact_number' => 'nullable|string|max:20',
            'whatsapp_number' => 'nullable|string|max:20',
            'type' => 'nullable|in:business,service,social',
            'category_id' => 'nullable|exists:extra_categories,id',
            'status' => 'required|in:pending,accepted,rejected',
            'state_id' => 'nullable|exists:states,id',
            'district_id' => 'nullable|exists:districts,id',
            'taluka_id' => 'nullable|exists:talukas,id',
            'latitude' => 'nullable|string|max:255',
            'longitude' => 'nullable|string|max:255',
            'opening_time' => 'nullable|date_format:H:i',
            'closing_time' => 'nullable|date_format:H:i',
            'closing_day' => 'nullable|string|max:255',
            'is_delivery' => 'nullable',
            'is_paid' => 'nullable',
            'expired_at' => 'nullable|date',
            'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $business = new Business();
        $business->user_id = $request->get('user_id');
       
        $name = $request->get('name');
        $description = $request->get('description');
        
        $business_owner_name = $request->get('business_owner_name');
        $business_address = $request->get('business_address');
        
        $languageIds = [];
        
        if (!empty($name['en']) || !empty($description['en']) || !empty($business_owner_name['en']) || !empty($business_address['en'])) {
            $languageIds[] = 3; // English (ID 3)
        }
        if (!empty($name['hi']) || !empty($description['hi']) || !empty($business_owner_name['hi']) || !empty($business_address['hi'])) {
            $languageIds[] = 2; // Hindi (ID 2)
        }
        if (!empty($name['mr']) || !empty($description['mr']) || !empty($business_owner_name['mr']) || !empty($business_address['mr'])) {
            $languageIds[] = 1; // Marathi (ID 1)
        }
        
        $business->language_id = json_encode($languageIds);
        $business->name = json_encode($name, JSON_UNESCAPED_UNICODE);
        $business->description = json_encode($description, JSON_UNESCAPED_UNICODE);
        
        $business->business_owner_name = json_encode($business_owner_name, JSON_UNESCAPED_UNICODE);
        $business->business_address = json_encode($business_address, JSON_UNESCAPED_UNICODE);
        
        
        $business->email = $request->get('email');
        $business->address = $request->get('address');
        $business->contact_number = $request->get('contact_number');
        $business->whatsapp_number = $request->get('whatsapp_number');
        $business->type = $request->get('type');
        $business->category_id = $request->get('category_id');
        $business->status = $request->get('status', 'accepted');
        $business->state_id = $request->get('state_id');
        $business->district_id = $request->get('district_id');
        $business->taluka_id = $request->get('taluka_id');
        $business->latitude = $request->get('latitude');
        $business->longitude = $request->get('longitude');
        $business->opening_time = $request->get('opening_time');
        $business->closing_time = $request->get('closing_time');
        $business->closing_day = $request->get('closing_day');
        $business->is_delivery = $request->has('is_delivery');
        $business->is_paid = $request->has('is_paid');
        
        $business->notification_title = $request->has('notification_title');
        
        $rawHtml = $request->get('notification_title');

        // 1️⃣ Decode HTML entities (&nbsp;, etc.)
        $notificationTitle = html_entity_decode($rawHtml);
        
        // 2️⃣ Replace all <br> and </h3> tags with actual newlines
        $notificationTitle = preg_replace('/<\s*br\s*\/?>/i', "\n", $notificationTitle);
        $notificationTitle = preg_replace('/<\/h[1-6]>|<\/p>/i', "\n", $notificationTitle);
        
        // 3️⃣ Strip all other HTML tags
        $notificationTitle = strip_tags($notificationTitle);
        
        // 4️⃣ Clean up extra spaces and multiple line breaks
        $notificationTitle = preg_replace("/\n\s*\n+/", "\n", $notificationTitle);
        $notificationTitle = trim($notificationTitle);
        
        // 5️⃣ Build your notification message
        $titling = "New Shop -\n" . $notificationTitle;
        
        $business->is_display = 1;
        
        $business->expired_at = $request->get('expired_at') ? Carbon::parse($request->get('expired_at')) : Carbon::now()->addYear();

        if ($request->hasFile('images')) {
            $imageNames = [];
            foreach ($request->file('images') as $image) {
                $name = time() . '_' . uniqid() . '.' . $image->extension();
                $image->move(public_path('images/businesses'), $name);
                $imageNames[] = 'images/businesses/' . $name;
            }
            $business->images = json_encode($imageNames);
        }

        $business->save();
        
        
        try {
            $firebaseFactory = (new Factory)->withServiceAccount(base_path('dignityapp-1cbe2-firebase-adminsdk-npyf1-0c03e2f34b.json'));
            $messaging = $firebaseFactory->createMessaging();
        
            $languages = $business->language_id;
        
            if (is_string($languages)) {
                $languages = json_decode($languages, true); 
            }
        
            if (is_string($languages) && strpos($languages, ',') !== false) {
                $languages = explode(',', $languages);
            }
        
            $langs = \DB::table('languages')->whereIn('id', $languages)->pluck('short_name')->toArray();
        
            $tokens = User::whereNotNull('android_push_token')->pluck('android_push_token')->filter();
        
            $title = $request->get('notification_title'); 
            $body = $request->get('message'); 
            $image = "https://loksathinews.in/job_listings/notificationlogo.png";  
            $dynamic = "https://loksathinews.in/router?s=extras&extras_id=" . $business->id;

            foreach (array_chunk($tokens->toArray(), 95) as $tokenGroup) {
                foreach ($tokenGroup as $token) {
                    try {
                        foreach ($langs as $lang) {
                            $message = CloudMessage::fromArray([
                                'token' => $token,
                                'data' => [
                                    "title" => $titling,
                                    "body" => "",
                                    "image" => $image,
                                    "dynamic" => $dynamic,
                                    "lang" => $lang
                                ],
                                'android' => [
                                    'priority' => 'high',
                                ],
                            ]);
        
                            $messaging->send($message);
                        }
                    } catch (\Exception $e) {
                        \Log::error("Failed to send notification for token: {$token}, error: " . $e->getMessage());
                        continue;
                    }
                }
            }
        
        } catch (\Exception $e) {
            Session::flash('error', 'Failed to send notifications: ' . $e->getMessage());
        }
        
        
        Session::flash('success', 'Business has been added successfully.');

        return redirect()->route('admin.extras.index');
    }
    
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $title = $this->input('title', []);  // Get title field
            $description = $this->input('description', []);  // Get description field
    
            // Check if at least one language has a non-empty title and description
            $titleFilled = !empty($title['en']) || !empty($title['hi']) || !empty($title['mr']);
            $descriptionFilled = !empty($description['en']) || !empty($description['hi']) || !empty($description['mr']);
    
            if (!$titleFilled || !$descriptionFilled) {
                // Add a custom error if title or description is not filled in any language
                $validator->errors()->add('title', 'At least one language for title must be provided.');
                $validator->errors()->add('description', 'At least one language for description must be provided.');
            }
        });
    }
}
