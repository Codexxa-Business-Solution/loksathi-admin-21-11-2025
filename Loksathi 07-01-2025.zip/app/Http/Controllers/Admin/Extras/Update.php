<?php

namespace App\Http\Controllers\Admin\Extras;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Models\Business;

use App\Models\GroupCategory;

use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;

class Update extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {
        // Validate the request
        $request->validate([
            'user_id' => 'required|exists:users,id',
          
          
           'name.en' => 'nullable|string|max:255',
            'name.hi' => 'nullable|string|max:255',
            'name.mr' => 'nullable|string|max:255',
            'description.en' => 'nullable|string',
            'description.hi' => 'nullable|string',
            'description.mr' => 'nullable|string',
            
            
                        'business_address.en' => 'nullable|string',
            'business_address.hi' => 'nullable|string',
            'business_address.mr' => 'nullable|string',
            
            'business_owner_name.en' => 'nullable|string',
            'business_owner_name.hi' => 'nullable|string',
            'business_owner_name.mr' => 'nullable|string',     
            
          
            'email' => 'nullable|email|max:255',
            'address' => 'nullable|string',
            'contact_number' => 'nullable|string|max:20',
            'whatsapp_number' => 'nullable|string|max:20',
            
            'type' => 'nullable|in:business,service,social',
            'category_id' => 'nullable|exists:extra_categories,id',
            'status' => 'required|in:pending,accepted,rejected',
            'state_id' => 'nullable|exists:states,id',
            'district_id' => 'nullable|exists:districts,id',
            'taluka_id' => 'nullable|exists:talukas,id',
            'latitude' => 'nullable|string|max:255',
            'longitude' => 'nullable|string|max:255',
            'opening_time' => 'nullable|date_format:H:i',
            'closing_time' => 'nullable|date_format:H:i',
            'closing_day' => 'nullable|string|max:255',
            'is_delivery' => 'nullable',
            'is_paid' => 'nullable',
            'expired_at' => 'nullable|date',
            'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Find business
        $business = Business::find($id);
        
        if (!$business) {
            abort(404);
        }

        // Update business
        $business->user_id = $request->get('user_id', $business->user_id);
        
        $name = $request->get('name', $business->name);
        $description = $request->get('description', $business->description);
        
        $business_owner_name = $request->get('business_owner_name', $business->description);
        $business_address = $request->get('business_address', $business->description);
        
    
        $languageIds = [];
    
        if (!empty($name['en']) || !empty($description['en']) || !empty($business_owner_name['en']) || !empty($business_address['en'])) {
            $languageIds[] = 3; // English (ID 3)
        }
        if (!empty($name['hi']) || !empty($description['hi']) || !empty($business_owner_name['hi']) || !empty($business_address['hi'])) {
            $languageIds[] = 2; // Hindi (ID 2)
        }
        if (!empty($name['mr']) || !empty($description['mr']) || !empty($business_owner_name['mr']) || !empty($business_address['mr'])) {
            $languageIds[] = 1; // Marathi (ID 1)
        }
    
        $business->language_id = json_encode($languageIds); 
    
        $business->name = json_encode($name, JSON_UNESCAPED_UNICODE);
        $business->description = json_encode($description, JSON_UNESCAPED_UNICODE);  
        
        $business->business_owner_name = json_encode($business_owner_name, JSON_UNESCAPED_UNICODE);  
        $business->business_address = json_encode($business_address, JSON_UNESCAPED_UNICODE);  

        $business->email = $request->get('email', $business->email);
        $business->address = $request->get('address', $business->address);
        $business->contact_number = $request->get('contact_number', $business->contact_number);
        $business->whatsapp_number = $request->get('whatsapp_number', $business->whatsapp_number);
        $business->type = $request->get('type', $business->type);
        $business->category_id = $request->get('category_id', $business->category_id);
        $business->status = $request->get('status', $business->status);
        $business->state_id = $request->get('state_id', $business->state_id);
        $business->district_id = $request->get('district_id', $business->district_id);
        $business->taluka_id = $request->get('taluka_id', $business->taluka_id);
        $business->latitude = $request->get('latitude', $business->latitude);
        $business->longitude = $request->get('longitude', $business->longitude);
        $business->opening_time = $request->get('opening_time', $business->opening_time);
        $business->closing_time = $request->get('closing_time', $business->closing_time);
        $business->closing_day = $request->get('closing_day', $business->closing_day);
        $business->is_delivery = $request->has('is_delivery');
        $business->is_paid = $request->has('is_paid');
        $business->is_display = $request->has('is_display');
        

        if ($request->get('expired_at')) {
            $business->expired_at = Carbon::parse($request->get('expired_at'));
        }

        // Handle multiple images
        if ($request->hasFile('images')) {
            // Delete old images
            if ($business->images) {
                $oldImages = json_decode($business->images, true);
                if (is_array($oldImages)) {
                    foreach ($oldImages as $oldImage) {
                        $imagePath = public_path($oldImage);
                        if (file_exists($imagePath)) {
                            unlink($imagePath);
                        }
                    }
                }
            }
            
            // Upload new images
            $imageNames = [];
            foreach ($request->file('images') as $image) {
                $name = time() . '_' . uniqid() . '.' . $image->extension();
                $image->move(public_path('images/businesses'), $name);
                $imageNames[] = 'images/businesses/' . $name;
            }
            $business->images = json_encode($imageNames);
        }

        // Save business
        $business->save();

        // Flash message
        Session::flash('success', 'Business has been updated successfully.');

        return redirect()->route('admin.extras.index');
    }
}
