<?php

namespace App\Http\Controllers\Admin\Agents;

use App\Http\Controllers\Controller;
use App\Models\Agent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $gr = Agent::find($id);

        if (!$gr)
            abort(404);

        // delete
        $gr->delete();

        // flash and redirect
        Session::flash('success', 'Agents has been deleted successfully.');
        return redirect()->route('admin.agents.index');
    }
}
