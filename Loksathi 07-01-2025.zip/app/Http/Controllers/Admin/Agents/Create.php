<?php

namespace App\Http\Controllers\Admin\Agents;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        return view('admin.agents.create');
    }
}
