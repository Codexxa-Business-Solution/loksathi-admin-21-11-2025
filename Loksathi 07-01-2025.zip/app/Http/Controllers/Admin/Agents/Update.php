<?php

namespace App\Http\Controllers\Admin\Agents;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Agents\UpdateAgentRequest;
use App\Models\Agent;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{

    public function __invoke(UpdateAgentRequest $request, $id)
    {
        $gr = Agent::find($id);

        if (!$gr)
            abort(404);

        $gr->name = $request->get('name', $gr->name);
        $gr->email = $request->get('email', $gr->email);
        $gr->phone = $request->get('phone', $gr->phone);
        $gr->address = $request->get('address', $gr->address);
        $gr->gender = $request->get('gender', $gr->gender);
        $gr->save();

        Session::flash('success', 'Agent has been updated successfully.');

        return redirect()->route('admin.agents.index');
    }
}
