<?php

namespace App\Http\Controllers\Admin\Agents;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\Agent;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $grs = Agent::orderBy('created_at', 'desc')
            ->get();

        return view('admin.agents.index', compact('grs'));
    }
}
