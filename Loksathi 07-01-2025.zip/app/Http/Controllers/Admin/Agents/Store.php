<?php

namespace App\Http\Controllers\Admin\Agents;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Agents\StoreAgentRequest;
use App\Models\Agent;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    public function __invoke(StoreAgentRequest $request): RedirectResponse
    {
        $gr = new Agent();
        $gr->name = $request->get('name');
        $gr->email = $request->get('email');
        $gr->phone = $request->get('phone');
        $gr->gender = $request->get('gender');
        $gr->address = $request->get('address');
        $gr->save();
        $gr->agent_code = 'LK' . str_pad($gr->id, 5, '0', STR_PAD_LEFT);
        $gr->save();
        Session::flash('success', 'Agents has been added successfully.');

        return redirect()->route('admin.agents.index');

    }
}
