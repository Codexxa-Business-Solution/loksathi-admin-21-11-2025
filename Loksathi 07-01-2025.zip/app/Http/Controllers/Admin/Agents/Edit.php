<?php

namespace App\Http\Controllers\Admin\Agents;

use App\Http\Controllers\Controller;
use App\Models\Agent;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $gr = Agent::find($id);

        // check group exists
        if (!$gr) {
            abort(404);
        }

        // return view
        return view('admin.agents.edit', compact('gr'));

    }
}
