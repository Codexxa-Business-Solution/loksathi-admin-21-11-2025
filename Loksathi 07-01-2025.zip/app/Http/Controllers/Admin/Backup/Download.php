<?php

namespace App\Http\Controllers\Admin\Backup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Download extends Controller
{

    //
    public function __invoke(Request $request)
    {

    }

}
