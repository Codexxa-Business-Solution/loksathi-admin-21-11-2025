<?php

namespace App\Http\Controllers\Admin\Backup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Index extends Controller
{

    //
    public function __invoke(Request $request)
    {
        return view('admin.backup.index');
    }

}
