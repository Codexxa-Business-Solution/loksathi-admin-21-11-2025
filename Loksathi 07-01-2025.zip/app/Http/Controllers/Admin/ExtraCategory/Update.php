<?php

namespace App\Http\Controllers\Admin\ExtraCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ExtraCategory\UpdateExtraCategoryRequest;
use App\Models\ExtraCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateExtraCategoryRequest $request, $id): RedirectResponse
    {

        // store group category
        $groupCategory = ExtraCategory::find($id);
        $groupCategory->name = $request->get('name', $groupCategory->name);
        $groupCategory->description = $request->get('description', $groupCategory->description);
        $groupCategory->index = $request->get('index', $groupCategory->index);
        $groupCategory->language_id = $request->get('language', $groupCategory->language_id);
        $groupCategory->parent_id = $request->get('parent_id', $groupCategory->parent_id);
        $groupCategory->type = $request->get('type', $groupCategory->type);

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::EXTRA_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::EXTRA_DIR_NAME, $name);
            $groupCategory->image = AppConstants::EXTRA_DIR_NAME . $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'Extra category has been updated successfully.');

        return redirect()->route('admin.extra_categories.index');
    }
}
