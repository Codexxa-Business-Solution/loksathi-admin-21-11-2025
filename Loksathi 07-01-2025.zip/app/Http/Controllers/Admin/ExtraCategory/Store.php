<?php

namespace App\Http\Controllers\Admin\ExtraCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ExtraCategory\StoreExtraCategoryRequest;
use App\Models\ExtraCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreExtraCategoryRequest $request): RedirectResponse
    {

        // store group category
        $groupCategory = new ExtraCategory();
        $groupCategory->name = $request->get('name');
        $groupCategory->description = $request->get('description');
        $groupCategory->index = 0;
        $groupCategory->language_id = $request->get('language');
        $groupCategory->parent_id = $request->get('parent_id');
        $groupCategory->type = $request->get('type', 'business');

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::EXTRA_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::EXTRA_DIR_NAME, $name);

            $groupCategory->image = AppConstants::EXTRA_DIR_NAME . $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'Extra category has been added successfully.');

        return redirect()->route('admin.extra_categories.index');
    }
}
