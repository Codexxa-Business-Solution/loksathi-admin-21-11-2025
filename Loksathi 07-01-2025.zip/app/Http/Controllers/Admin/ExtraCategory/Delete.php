<?php

namespace App\Http\Controllers\Admin\ExtraCategory;

use App\Http\Controllers\Controller;
use App\Models\ExtraCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $group = ExtraCategory::find($id);

        if (!$group)
            abort(404);

        // delete
        $group->delete();

        // flash and redirect
        Session::flash('success', 'Extra category has been deleted successfully.');
        return redirect()->route('admin.extra_categories.create');
    }

}
