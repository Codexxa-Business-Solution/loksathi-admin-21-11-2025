<?php

namespace App\Http\Controllers\Admin\ExtraCategory;

use App\Http\Controllers\Controller;
use App\Models\ExtraCategory;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        // categories by type
        $categories = ExtraCategory::query()
            ->get();

        // response
        return view('admin.extras.categories.index', compact('categories'));

    }
}
