<?php

namespace App\Http\Controllers\Admin\ExtraCategory;

use App\Http\Controllers\Controller;
use App\Models\ExtraCategory;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $categories = ExtraCategory::whereNull('parent_id')->get();
        return view('admin.extras.categories.create', compact('categories'));
    }
}
