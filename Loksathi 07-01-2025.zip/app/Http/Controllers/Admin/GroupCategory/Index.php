<?php

namespace App\Http\Controllers\Admin\GroupCategory;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\GroupCategory;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $groupCategories = GroupCategory::all();
        return view('admin.groups.categories.index', compact('groupCategories'));
    }
}
