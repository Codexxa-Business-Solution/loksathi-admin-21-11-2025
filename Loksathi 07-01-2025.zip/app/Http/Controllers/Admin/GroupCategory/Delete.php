<?php

namespace App\Http\Controllers\Admin\GroupCategory;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $group = GroupCategory::find($id);

        if (!$group)
            abort(404);

        // delete
        try {
            $group->delete();
        } catch(QueryException $e) {
            Session::flash('error', 'Group category is in used cannot delete');
            return redirect()->route('admin.group_categories.index');
        }
        

        // flash and redirect
        Session::flash('success', 'Group category has been deleted successfully.');
        return redirect()->route('admin.group_categories.index');
    }

}
