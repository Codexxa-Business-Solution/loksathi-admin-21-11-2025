<?php

namespace App\Http\Controllers\Admin\GroupCategory;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $category = GroupCategory::find($id);

        // check group exists
        if (!$category) {
            abort(404);
        }

        // return view
        return view('admin.groups.categories.edit', compact('category'));

    }
}
