<?php

namespace App\Http\Controllers\Admin\GroupCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\GroupCategory\UpdateGroupCategoryRequest;
use App\Models\GroupCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateGroupCategoryRequest $request, $id): RedirectResponse
    {

        // store group category
        $groupCategory = GroupCategory::find($id);
        $groupCategory->name = $request->get('name', $groupCategory->name);
        $groupCategory->description = $request->get('description', $groupCategory->description);
        $groupCategory->index = $request->get('index', $groupCategory->index);
        $groupCategory->language_id = $request->get('language', $groupCategory->language_id);

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::GROUP_DIR_NAME, $groupCategory->image);
             */$file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::GROUP_DIR_NAME, $name);
            $groupCategory->image = AppConstants::GROUP_DIR_NAME . $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'Group category has been updated successfully.');

        return redirect()->route('admin.group_categories.index');

    }

}
