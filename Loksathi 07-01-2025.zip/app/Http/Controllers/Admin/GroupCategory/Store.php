<?php

namespace App\Http\Controllers\Admin\GroupCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\GroupCategory\StoreGroupCategoryRequest;
use App\Models\GroupCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreGroupCategoryRequest $request): RedirectResponse
    {

        // store group category
        $groupCategory = new GroupCategory();
        $groupCategory->name = $request->get('name');
        $groupCategory->description = $request->get('description');
        $groupCategory->index = $request->get('index');
        $groupCategory->language_id = $request->get('language');

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::GROUP_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::GROUP_DIR_NAME, $name);
            $groupCategory->image = AppConstants::GROUP_DIR_NAME. $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'Group category has been added successfully.');

        return redirect()->route('admin.group_categories.index');
    }
}
