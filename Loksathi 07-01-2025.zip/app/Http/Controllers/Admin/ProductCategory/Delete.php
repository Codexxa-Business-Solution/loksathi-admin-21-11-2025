<?php

namespace App\Http\Controllers\Admin\ProductCategory;

use App\Http\Controllers\Controller;
use App\Models\ProductCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $category = ProductCategory::find($id);

        if (!$category)
            abort(404);

        // delete
        $category->delete();

        // flash and redirect
        Session::flash('success', 'Product category has been deleted successfully.');
        return redirect()->route('admin.product_categories.index');
    }

}
