<?php

namespace App\Http\Controllers\Admin\ProductCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProductCategory\StoreProductCategoryRequest;
use App\Models\ProductCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreProductCategoryRequest $request): RedirectResponse
    {

        // store quiz category
        $productCategory = new ProductCategory();
        $productCategory->name = $request->get('name');
        $productCategory->description = $request->get('description');
        $productCategory->index = $request->get('index');
        $productCategory->language_id = $request->get('language');
        $productCategory->parent_id = $request->get('parent_id');

        if ($request->get('is_published') == "on") {
            $productCategory->is_published = true;
        } else {
            $productCategory->is_published = false;
        }

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::PRODUCT_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::PODCAST_DIR_NAME, $name);
            $productCategory->image = AppConstants::PODCAST_DIR_NAME . $name;
        }

        // store
        $productCategory->save();

        // flash message
        Session::flash('success', 'Product category has been added successfully.');

        return redirect()->route('admin.product_categories.index');

    }
}
