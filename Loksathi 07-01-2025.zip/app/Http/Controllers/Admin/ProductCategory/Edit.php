<?php

namespace App\Http\Controllers\Admin\ProductCategory;

use App\Http\Controllers\Controller;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $category = ProductCategory::find($id);
        $categories = ProductCategory::whereNull('parent_id')->get();

        // check group exists
        if (!$category) {
            abort(404);
        }

        // return view
        return view('admin.products.categories.edit', compact('category', 'categories'));

    }
}
