<?php

namespace App\Http\Controllers\Admin\ProductCategory;

use App\Http\Controllers\Controller;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $categories = ProductCategory::whereNull('parent_id')->get();
        return view('admin.products.categories.create', compact('categories'));
    }
}
