<?php

namespace App\Http\Controllers\Admin\QuizCategory;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\QuizCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $group = QuizCategory::find($id);

        $type = 'success';
        $message = 'Quiz category has been deleted successfully.';

        if (!$group)
            abort(404);

        // delete
        try {
            $group->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'Quiz category cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.quiz_categories.index');
    }
}
