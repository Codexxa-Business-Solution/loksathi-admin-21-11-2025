<?php

namespace App\Http\Controllers\Admin\QuizCategory;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        return view('admin.quizzes.categories.create');
    }
}
