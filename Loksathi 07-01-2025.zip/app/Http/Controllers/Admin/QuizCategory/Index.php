<?php

namespace App\Http\Controllers\Admin\QuizCategory;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\GroupCategory;
use App\Models\QuizCategory;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $categories = QuizCategory::all();
        return view('admin.quizzes.categories.index', compact('categories'));
    }
}
