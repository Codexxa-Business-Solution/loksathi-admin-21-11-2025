<?php

namespace App\Http\Controllers\Admin\QuizCategory;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\QuizCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $category = QuizCategory::find($id);

        // check group exists
        if (!$category) {
            abort(404);
        }

        // return view
        return view('admin.quizzes.categories.edit', compact('category'));

    }
}
