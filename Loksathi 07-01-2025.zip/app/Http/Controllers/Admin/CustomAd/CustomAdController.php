<?php

namespace App\Http\Controllers\Admin\CustomAd;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Models\CustomAd;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class CustomAdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $query = CustomAd::orderBy('display_order', 'asc')->orderBy('created_at', 'desc');
        
        // Filter by status if requested
        $status = $request->get('status');
        if ($status === 'active') {
            $query->active();
        } elseif ($status === 'expired') {
            $query->expired();
        }
        
        $customAds = $query->get();
        return view('admin.custom_ads.index', compact('customAds', 'status'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $positionOptions = CustomAd::$positionOptions;
        return view('admin.custom_ads.create', compact('positionOptions'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'position' => 'required|array|min:1',
            'location' => 'required',
            // 'position.*' => 'required|string|in:' . implode(',', array_keys(CustomAd::$positionOptions)),
            'display_order' => 'required|integer|min:0',
            'expiry_date' => 'nullable|date|after_or_equal:today',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $customAd = new CustomAd();
        $customAd->name = $request->get('name');
        $customAd->url = $request->get('url');
        $customAd->position = implode(',', $request->get('position'));
        $customAd->display_order = $request->get('display_order');
        $customAd->expiry_date = $request->get('expiry_date');
        $customAd->location = $request->get('location');
        $customAd->latitude = $request->get('latitude');
        $customAd->longitude = $request->get('longitude');

        // Store file
        $file = $request->file('image');
        $name = md5($file . microtime()) . '.' . $file->extension();
        $file->move(AppConstants::AD_DIR_NAME, $name);
        $customAd->image = AppConstants::AD_DIR_NAME . $name;

        // Save
        $customAd->save();

        // Flash message
        Session::flash('success', 'Custom ad has been added successfully.');

        return redirect()->route('admin.custom_ads.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $customAd = CustomAd::find($id);
        if (!$customAd) {
            abort(404);
        }
        $positionOptions = CustomAd::$positionOptions;
        return view('admin.custom_ads.edit', compact('customAd', 'positionOptions'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
             'location' => 'required',
            'positions' => 'required|array|min:1',
            'positions.*' => 'required|string|in:' . implode(',', array_keys(CustomAd::$positionOptions)),
            'display_order' => 'required|integer|min:0',
            'expiry_date' => 'nullable|date|after_or_equal:today',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $customAd = CustomAd::find($id);
        if (!$customAd) {
            abort(404);
        }

        $customAd->name = $request->get('name');
        $customAd->url = $request->get('url');
        $customAd->positions = $request->get('positions');
        $customAd->display_order = $request->get('display_order');
        $customAd->expiry_date = $request->get('expiry_date');
        $customAd->location = $request->get('location');
        $customAd->latitude = $request->get('latitude');
        $customAd->longitude = $request->get('longitude');
        
        
        // Store file if provided
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::AD_DIR_NAME, $name);
            $customAd->image = AppConstants::AD_DIR_NAME . $name;
        }

        // Save
        $customAd->save();

        // Flash message
        Session::flash('success', 'Custom ad has been updated successfully.');

        return redirect()->route('admin.custom_ads.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customAd = CustomAd::find($id);
        if (!$customAd) {
            abort(404);
        }

        // Delete
        $customAd->delete();

        // Flash message
        Session::flash('success', 'Custom ad has been deleted successfully.');

        return redirect()->route('admin.custom_ads.index');
    }
}