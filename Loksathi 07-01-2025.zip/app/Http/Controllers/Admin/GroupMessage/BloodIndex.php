<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\BloodGroupMessage;
use App\Models\Group;
use Illuminate\Http\Request;

class BloodIndex extends Controller
{
    //
    public function __invoke(Request $request)
    {

        //
        $search = $request->get('search');

        $title = "List of all blood messages";
        $groupMessageQuery = BloodGroupMessage::query()
            ->with('user', 'state', 'district', 'taluka', 'group');

        $filters = [];

        $group = Group::find(3);
        $filters[] = "Group: {$group->name}";
        $groupMessageQuery->where('blood_group_id', $group->id);

        // conditions
        if ($search) {
            $filters[] = "Condition: {$search}";
        }

        // search
        if ($search) {
            $groupMessageQuery->where(function ($query) use ($search) {
                $query->where('message', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%");
            });
        }

        $messages = $groupMessageQuery
            ->with('group')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(100);

        return view('admin.groups.messages.blood_index', compact('messages', 'title', 'filters'));

    }

}
