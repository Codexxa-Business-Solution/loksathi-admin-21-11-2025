<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\Group;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {

        // groups
        $type = $request->get('type');
        if ($type) {
            $groups = Group::where('type', $type)->get();
        } else {
            $groups = Group::all();
        }

        return view('admin.groups.messages.create', compact('groups'));
    }
}
