<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\DiscussMessage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class DiscussDelete extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $discussMessage = DiscussMessage::find($id);

        if (!$discussMessage)
            abort(404);

        // delete
        $discussMessage->delete();

        // flash and redirect
        Session::flash('success', 'Discuss message has been deleted successfully.');
        return redirect()->route('admin.messages.discuss.index');

    }
}
