<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\BloodGroupMessage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class BloodDelete extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $groupMessages = BloodGroupMessage::find($id);

        if (!$groupMessages)
            abort(404);

        // delete
        $groupMessages->delete();

        // flash and redirect
        Session::flash('success', 'Blood message has been deleted successfully.');
        return redirect()->route('admin.messages.blood.index');

    }
}
