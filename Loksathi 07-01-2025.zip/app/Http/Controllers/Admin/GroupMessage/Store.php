<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\GroupMessage\StoreGroupMessageRequest;
use App\Models\GroupMessage;
use App\Models\Group;
use App\Models\User;
use App\Services\BunnyCdnStorage;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

class Store extends Controller
{
    public function __invoke(StoreGroupMessageRequest $request): RedirectResponse
    {
        // Initialize group message
        $groupMessage = new GroupMessage();
        $groupMessage->group_id = $request->get('group_id');
        $groupMessage->type = $request->get('type');
        $groupMessage->name = $request->get('name');
        $groupMessage->message = $request->get('message');
        $groupMessage->notification_title = $request->get('notification_title');

        // Parse scheduled time
        $groupMessage->scheduled_at = Carbon::parse($request->get('scheduled_at', Carbon::now()));

        // Boolean fields
        $groupMessage->is_scheduled = $request->get('is_scheduled') == "on";
        $groupMessage->is_notified = $request->get('is_notified') == "on";
        $groupMessage->is_published = $request->get('is_published') == "on";
        $groupMessage->is_pinned = $request->get('is_pinned') == "on";

        // Handle file upload
        if ($request->has('file')) {
            $file = $request->file('file');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(public_path(AppConstants::MESSAGE_DIR_NAME), $name); // Make sure the directory is publicly accessible
            $groupMessage->file = AppConstants::MESSAGE_DIR_NAME . '/' . $name;
            $groupMessage->images = json_encode([AppConstants::MESSAGE_DIR_NAME . '/' . $name]);
        }

        // Store group message
        $groupMessage->save();

        if ($groupMessage->is_published && $groupMessage->is_notified) {
            // Firebase Cloud Messaging
            try {
                // Initialize Firebase Messaging
                $firebaseFactory = (new Factory)->withServiceAccount(base_path('dignityapp-1cbe2-firebase-adminsdk-npyf1-0c03e2f34b.json'));
                $messaging = $firebaseFactory->createMessaging();

                // Fetch group language
                $group = Group::find($groupMessage->group_id);
                if (!$group) {
                    throw new \Exception('Group not found');
                }

                $lang = $group->language->short_name ?? 'en'; // Default to 'en' if no language found

                // Fetch push tokens of users
                $tokens = User::whereNotNull('android_push_token')
                    ->pluck('android_push_token')
                    ->filter();

                // Prepare message details
                $title = $groupMessage->notification_title;
                $body = $groupMessage->name;
                $image = "https://dignityapp.in/" . $groupMessage->file;
                $dynamic = "https://loksathinews.in/router?s=group_message&group_id=" . $groupMessage->group_id . "&message_id=" . $groupMessage->id;

                // Send push notifications in batches (each batch with 95 tokens)
                foreach (array_chunk($tokens->toArray(), 95) as $tokenGroup) {
                    foreach ($tokenGroup as $token) {
                        try {
                            $message = CloudMessage::fromArray([
                                'token' => $token,
                                'data' => [
                                    "title" => $title,
                                    "body" => strip_tags($body), // Remove HTML tags for body
                                    "image" => $image,
                                    "dynamic" => $dynamic,
                                    "lang" => $lang
                                ],
                                'android' => [
                                    'priority' => 'high',
                                ],
                            ]);

                            // Send notification
                            $messaging->send($message);
                        } catch (\Exception $e) {
                            Log::error("Failed to send notification for token: {$token}, error: " . $e->getMessage());
                        }
                    }
                }

                // Flash success message to session

            } catch (\Exception $e) {
                // Handle errors in notification sending
                Session::flash('error', 'Failed to send notifications: ' . $e->getMessage());
            }
        }

        Session::flash('success', 'Group Message has been added successfully.');
        // Redirect to the group messages index page
        return redirect()->route('admin.messages.index');
    }
}
