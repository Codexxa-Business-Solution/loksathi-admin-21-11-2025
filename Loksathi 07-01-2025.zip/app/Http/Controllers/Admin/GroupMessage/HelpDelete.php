<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\BuySellMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class HelpDelete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $groupMessages = BuySellMessage::find($id);

        if (!$groupMessages)
            abort(404);

        // delete
        $groupMessages->delete();

        // flash and redirect
        Session::flash('success', 'Help message has been deleted successfully.');
        return redirect()->route('admin.messages.help.index');

    }
}
