<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\GroupMessage;
use Carbon\Carbon;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        //
        $groupId = $request->get('group_id');
        $groupType = $request->get('type');
        $condition = $request->get('condition');
        $date = $request->get('date');

        $title = "List of all messages";
        $groupMessageQuery = GroupMessage::query();

        $filters = [];

        // group query
        if ($groupId) {
            $group = Group::find($groupId);
            $filters[] = "Group: {$group->name}";
            $groupMessageQuery->where('group_id', $groupId);
        }

        // group type
        if ($groupType) {
            $filters[] = "Group Type: {$groupType}";
            $groupMessageQuery->where('type', $groupType);
        }

        // conditions
        if ($condition) {

            $filters[] = "Condition: {$condition}";

            // published
            if ($condition == 'published') {
                $groupMessageQuery->where('is_published', true);
            }

            // draft
            if ($condition == 'draft') {
                $groupMessageQuery->where('is_published', false);
            }

            // push active
            if ($condition == 'push_active') {
                $groupMessageQuery->where('is_notified', true);
            }

            // pinned
            if ($condition == 'pinned') {
                $groupMessageQuery->where('is_pinned', true);
            }

            // push active
            if ($condition == 'scheduled') {
                $groupMessageQuery->where('is_scheduled', true);
            }

        }

        // schedule date
        if ($date) {

            $filters[] = "Date: {$date}";

            // split date with -
            $dates = explode('-', $date);
            $startDate = Carbon::parse($dates[0]);
            $endDate = Carbon::parse($dates[1]);
            $groupMessageQuery->whereBetween('scheduled_at', [$startDate, $endDate]);
        }

        $messages = $groupMessageQuery
            ->with('group')
            ->orderBy('scheduled_at', 'desc')
            ->simplePaginate(100);

        return view('admin.groups.messages.index', compact('messages', 'title', 'filters'));

    }

}
