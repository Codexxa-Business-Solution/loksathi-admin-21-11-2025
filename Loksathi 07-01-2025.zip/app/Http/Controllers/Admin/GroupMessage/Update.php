<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\GroupMessage\UpdateGroupMessageRequest;
use App\Models\GroupMessage;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateGroupMessageRequest $request, $id): RedirectResponse
    {

        // store group
        $group = GroupMessage::find($id);
        $group->group_id = $request->get('group_id', $request->group_id);
        $group->type = $request->get('type', $group->type);
        $group->name = $request->get('name', $group->title);
        $group->message = $request->get('message', $group->message);
        $group->notification_title = $request->get('notification_title', $group->notification_title);

        if ($request->get('scheduled_at')) {
            $group->scheduled_at = Carbon::parse($request->get('scheduled_at'));
        }

        if ($request->get('is_scheduled') == "on") {
            $group->is_scheduled = true;
        } else {
            $group->is_scheduled = false;
        }

        if ($request->get('is_notified') == "on") {
            $group->is_notified = true;
        } else {
            $group->is_notified = false;
        }

        if ($request->get('is_published') == "on") {
            $group->is_published = true;
        } else {
            $group->is_published = false;
        }

        if ($request->get('is_pinned') == "on") {
            $group->is_pinned = true;
        } else {
            $group->is_pinned = false;
        }

        // image
        if ($request->has('file')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('file'), AppConstants::MESSAGE_DIR_NAME, $group->file); */
            $file = $request->file('file');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::MESSAGE_DIR_NAME, $name);
            $group->file = AppConstants::MESSAGE_DIR_NAME . $name;
        }

        // store
        $group->save();

        // flash message
        Session::flash('success', 'Message has been updated successfully.');

        return redirect()->route('admin.messages.index');


    }
}
