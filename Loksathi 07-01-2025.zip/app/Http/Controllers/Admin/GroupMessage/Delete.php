<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\GroupMessage;
use App\Models\Status;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $groupMessages = GroupMessage::find($id);

        if (!$groupMessages)
            abort(404);

        // delete
        $groupMessages->delete();

        // flash and redirect
        Session::flash('success', 'Group message has been deleted successfully.');
        return redirect()->route('admin.messages.index');

    }
}
