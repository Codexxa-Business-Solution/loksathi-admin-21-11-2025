<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\DiscussMessage;
use App\Models\Group;
use Illuminate\Http\Request;

class DiscussIndex extends Controller
{
    //
    public function __invoke(Request $request)
    {

        //
        $search = $request->get('search');

        $title = "List of all discuss messages";
        $groupMessageQuery = DiscussMessage::query()
            ->with('user', 'group');

        $filters = [];

        $group = Group::find(17);
        $filters[] = "Group: {$group->name}";

        // conditions
        if ($search) {
            $filters[] = "Condition: {$search}";
        }

        // search
        if ($search) {
            $groupMessageQuery->where(function ($query) use ($search) {
                $query->where('description', 'like', "%{$search}%");
            });
        }

        $messages = $groupMessageQuery
            ->with('group')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(100);

        return view('admin.groups.messages.discuss_index', compact('messages', 'title', 'filters'));

    }

}
