<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\GroupMessage;
use App\Models\Status;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        // find group
        $message = GroupMessage::find($id);

        // groups
        $type = $request->get('type');
        if ($type) {
            $groups = Group::where('type', $type)->get();
        } else {
            $groups = Group::all();
        }

        // check group exists
        if (!$message) {
            abort(404);
        }

        // return view
        return view('admin.groups.messages.edit', compact('message', 'groups'));

    }
}
