<?php

namespace App\Http\Controllers\Admin\GroupMessage;

use App\Http\Controllers\Controller;
use App\Models\BuySellMessage;
use App\Models\Group;
use Illuminate\Http\Request;

class HelpIndex extends Controller
{
    //
    public function __invoke(Request $request)
    {

        //
        $search = $request->get('search');

        $title = "List of all blood messages";
        $groupMessageQuery = BuySellMessage::query()->with('user', 'group');

        $filters = [];

        $group = Group::find(15);
        $filters[] = "Group: {$group->name}";
        $groupMessageQuery->where('buysell_group_id', $group->id);

        // conditions
        if ($search) {
            $filters[] = "Condition: {$search}";
        }

        // search
        if ($search) {
            $groupMessageQuery->where(function ($query) use ($search) {
                $query->where('description', 'like', "%{$search}%");
            });
        }

        $messages = $groupMessageQuery
            ->with('group')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(100);

        return view('admin.groups.messages.help_index', compact('messages', 'title', 'filters'));

    }

}
