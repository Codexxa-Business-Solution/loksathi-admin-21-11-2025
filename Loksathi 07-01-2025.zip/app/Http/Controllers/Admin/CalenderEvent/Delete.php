<?php

namespace App\Http\Controllers\Admin\CalenderEvent;

use App\Http\Controllers\Controller;
use App\Models\CalendarEvent;
use App\Models\Gr;
use App\Models\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $event = CalendarEvent::find($id);

        if (!$event)
            abort(404);

        // delete
        $event->delete();

        // flash and redirect
        Session::flash('success', 'Calender Event has been deleted successfully.');
        return redirect()->route('admin.calender_events.index');
    }
}
