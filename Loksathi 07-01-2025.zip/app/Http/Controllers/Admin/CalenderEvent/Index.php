<?php

namespace App\Http\Controllers\Admin\CalenderEvent;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\CalendarEvent;
use App\Models\Gr;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $events = CalendarEvent::orderBy('created_at', 'desc')
            ->get();

        return view('admin.calender_events.index', compact('events'));
    }
}
