<?php

namespace App\Http\Controllers\Admin\CalenderEvent;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CalenderEvent\UpdateCalenderEventRequest;
use App\Models\CalendarEvent;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateCalenderEventRequest $request, $id)
    {
        // store group
        $event = CalendarEvent::find($id);

        if (!$event)
            abort(404);

        $event->name = $request->get('name', $event->name);
        $event->description = $request->get('description', $event->description);
        $event->index = $request->get('index', $event->index);

        if ($request->get('dated_at')) {
            $event->dated_at = Carbon::parse($request->get('dated_at'));
        }

        // image
        if ($request->has('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(public_path(AppConstants::MESSAGE_DIR_NAME), $name);
            $event->image = AppConstants::MESSAGE_DIR_NAME . '/' . $name;
        }

        // store
        $event->save();

        // flash message
        Session::flash('success', 'Calender event has been updated successfully.');

        return redirect()->route('admin.calender_events.index');
    }
}
