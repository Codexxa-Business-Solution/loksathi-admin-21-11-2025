<?php

namespace App\Http\Controllers\Admin\CalenderEvent;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\CalendarEvent;
use App\Models\Gr;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $event = CalendarEvent::find($id);

        // check group exists
        if (!$event) {
            abort(404);
        }

        // return view
        return view('admin.calender_events.edit', compact('event'));

    }
}
