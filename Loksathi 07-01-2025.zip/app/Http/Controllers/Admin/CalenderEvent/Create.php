<?php

namespace App\Http\Controllers\Admin\CalenderEvent;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        return view('admin.calender_events.create');
    }
}
