<?php

namespace App\Http\Controllers\Admin\CalenderEvent;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CalenderEvent\StoreCalenderEventRequest;
use App\Models\CalendarEvent;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreCalenderEventRequest $request): RedirectResponse
    {

        // store group
        $event = new CalendarEvent();
        $event->name = $request->get('name');
        $event->description = $request->get('description');
        $event->index = $request->get('index');

        $event->dated_at = Carbon::parse($request->get('dated_at', Carbon::now()));

        // store file
        $file = $request->file('image');
        $name = md5($file . microtime()) . '.' . $file->extension();
        $file->move(public_path(AppConstants::MESSAGE_DIR_NAME), $name);
        $event->image = AppConstants::MESSAGE_DIR_NAME . '/' . $name;

        // store
        $event->save();

        // flash message
        Session::flash('success', 'Calender Event has been added successfully.');

        return redirect()->route('admin.calender_events.index');

    }
}
