<?php

namespace App\Http\Controllers\Admin\Users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class Index extends Controller
{
    public function __invoke(Request $request)
    {
        $query = $request->get('query');

        // $userQuery = User::query();
        
        $userQuery = User::with('referredBy');


        $filters = [];

        if ($query) {

            $userQuery->where('name', 'LIKE', "%$query%")
                ->orWhere('email', 'LIKE', "%$query%")
                ->orWhere('phone', 'LIKE', "%$query%");

            $filters[] = "Search: {$query}";
        }

        $users = $userQuery->simplePaginate(30);

        return view('admin.users.index', compact('users', 'filters'));
    }
}
