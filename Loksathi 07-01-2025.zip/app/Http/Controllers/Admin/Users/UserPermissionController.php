<?php

namespace App\Http\Controllers\Admin\Users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserPermissionController extends Controller
{
    //
    public function index(Request $request, $id)
    {
        //
        $user = User::findOrFail($id);
        return view('admin.users.add_permissions', compact('user'));

    }

    //
    public function create()
    {
        //
    }

    //
    public function store(Request $request)
    {
        //
    }

    //
    public function show($id)
    {
        //
    }

    //
    public function edit($id)
    {
        //
    }

    //
    public function update(Request $request, $id)
    {
        //
    }

    //
    public function destroy($id)
    {
        //
    }
}
