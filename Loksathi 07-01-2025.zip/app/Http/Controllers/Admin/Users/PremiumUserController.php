<?php

namespace App\Http\Controllers\Admin\Users;

use App\Models\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class PremiumUserController extends Controller
{
    //
    public function index()
    {
       $user = User::select('*')->get();

        return view('admin.users.plans.index', compact('user'));
    }
    

    //
    public function create()
    {
        //
    }

    //
    public function store(Request $request)
    {
        //
    }

    //
    public function show($id)
    {
        //
    }

    //
    public function edit($id)
    {
        //
    }

    //
    public function update(Request $request, $id)
    {
        //
    }

    //
    public function destroy($id)
    {
       DB::table('users')->where('id', $id)->delete();
        Session::flash('success', 'User has been deleted successfully.');
        return redirect()->back();
    }
}
