<?php

namespace App\Http\Controllers\Admin\Users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class UserPlanController extends Controller
{
    //
    public function index(Request $request, $id)
    {
        //
        $user = User::findOrFail($id);
        return view('admin.users.plans.index', compact('user'));
    }

    //
    public function store(Request $request, $id)
    {

        // user
        $user = User::findOrFail($id);
        $planPrice = $request->get('plan_price');
        $planDays = 0;

        if ($planPrice == "199") {
            $planDays = "30";
        } else if ($planPrice == "499") {
            $planDays = "180";
        } else if ($planPrice == "799") {
            $planDays = "365";
        }

        // update user
        $user->is_premium = true;
        $user->plan_expired_at = Carbon::today()->addDays($planDays);
        $user->save();

        // send user notification about plan

        // flash message
        Session::flash('success', 'User plan has been updated successfully.');

        return redirect()->back();

    }

}
