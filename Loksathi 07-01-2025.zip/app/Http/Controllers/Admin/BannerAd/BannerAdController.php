<?php

namespace App\Http\Controllers\Admin\BannerAd;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\BannerAd\StoreBannerAdRequest;
use App\Http\Requests\Admin\BannerAd\UpdateBannerAdRequest;
use App\Models\BannerAd;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;

class BannerAdController extends Controller
{
    //
    public function index()
    {

        $bannerAds = BannerAd::orderBy('created_at', 'desc')
            ->get();

        return view('admin.banner_ads.index', compact('bannerAds'));
    }

    //
    public function create()
    {
        return view('admin.banner_ads.create');
    }

    //
    public function store(StoreBannerAdRequest $request)
    {
        //
        $bannerAd = new BannerAd();
        $bannerAd->link = $request->get('link');

        // store file
        // $bunnyCdnStorage = new BunnyCdnStorage();
        // $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::BANNER_DIR_NAME);

        $file = $request->file('image');
        $name = md5($file . microtime()) . '.' . $file->extension();
        $file->move(AppConstants::BANNER_DIR_NAME, $name);
        $bannerAd->image = AppConstants::BANNER_DIR_NAME . $name;

        // store
        $bannerAd->save();

        // flash message
        Session::flash('success', 'Banner ad has been added successfully.');

        return redirect()->route('admin.banner_ads.index');
    }

    //
    public function show($id)
    {
        //
    }

    //
    public function edit($id)
    {
        //
        $bannerAd = BannerAd::find($id);
        return view('admin.banner_ads.edit', compact('bannerAd'));
    }

    //
    public function update(UpdateBannerAdRequest $request, $id)
    {
        //
        $bannerAd = BannerAd::find($id);
        $bannerAd->link = $request->get('link', $bannerAd->link);

        // store file
        if ($request->has('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::BANNER_DIR_NAME, $name);
            $bannerAd->image = AppConstants::BANNER_DIR_NAME . $name;
        }

        // store
        $bannerAd->save();

        // flash message
        Session::flash('success', 'Banner ad has been updated successfully.');

        return redirect()->route('admin.banner_ads.index');
    }

    //
    public function destroy($id)
    {
        //
        $bannerAd = BannerAd::find($id);

        if (!$bannerAd)
            abort(404);

        // delete
        $bannerAd->delete();

        // flash and redirect
        Session::flash('success', 'Banner ad has been deleted successfully.');

        return redirect()->route('admin.banner_ads.index');
    }
}
