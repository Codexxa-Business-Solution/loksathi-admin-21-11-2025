<?php

namespace App\Http\Controllers\Admin\PodcastParts;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PodcastParts\UpdatePodcastPartRequest;
use App\Models\PodcastParts;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdatePodcastPartRequest $request, $id): RedirectResponse
    {

        // update part
        $podcastPart = PodcastParts::find($id);
        $podcastPart->podcast_id = $request->get('podcast_id', $podcastPart->podcast_id);
        $podcastPart->name = $request->get('name', $podcastPart->name);
        $podcastPart->description = $request->get('description', $podcastPart->description);
        $podcastPart->index = $request->get('index', $podcastPart->index);
        $podcastPart->notification_title = $request->get('notification_title', $podcastPart->notification_title);

        // image
        if ($request->has('file')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('file'), AppConstants::PODCAST_DIR_NAME, $podcastPart->file); */
            $file = $request->file('file');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::PODCAST_DIR_NAME, $name);
            $podcastPart->file = AppConstants::PODCAST_DIR_NAME . $name;
        }

        if ($request->get('is_premium') == "on") {
            $podcastPart->is_premium = true;
        } else {
            $podcastPart->is_premium = false;
        }

        if ($request->get('scheduled_at')) {
            $podcastPart->scheduled_at = Carbon::parse($request->get('scheduled_at'));
        }
        if ($request->get('is_scheduled') == "on") {
            $podcastPart->is_scheduled = true;
        } else {
            $podcastPart->is_scheduled = false;
        }

        if ($request->get('is_notified') == "on") {
            $podcastPart->is_notified = true;
        } else {
            $podcastPart->is_notified = false;
        }

        // store
        $podcastPart->save();

        // flash message
        Session::flash('success', 'Podcast part has been updated successfully.');

        return redirect()->route('admin.podcast_parts.index');

    }

}
