<?php

namespace App\Http\Controllers\Admin\PodcastParts;

use App\Http\Controllers\Controller;
use App\Models\Podcast;
use App\Models\PodcastParts;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $part = PodcastParts::find($id);
        $podcasts = Podcast::all();

        // check group exists
        if (!$part) {
            abort(404);
        }

        // return view
        return view('admin.podcasts.parts.edit', compact('part', 'podcasts'));

    }
}
