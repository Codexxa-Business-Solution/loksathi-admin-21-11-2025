<?php

namespace App\Http\Controllers\Admin\PodcastParts;

use App\Http\Controllers\Controller;
use App\Models\PodcastParts;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $podcastId = $request->get('podcast_id', null);

        $partQuery = PodcastParts::query();

        if ($podcastId) {
            $partQuery->where('podcast_id', $podcastId);
        }

        $parts = $partQuery->get();

        return view('admin.podcasts.parts.index', compact('parts'));
    }
}
