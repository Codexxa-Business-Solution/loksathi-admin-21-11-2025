<?php

namespace App\Http\Controllers\Admin\PodcastParts;

use App\Http\Controllers\Controller;
use App\Models\PodcastParts;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $podcast = PodcastParts::find($id);

        if (!$podcast)
            abort(404);

        // delete
        $podcast->delete();

        // flash and redirect
        Session::flash('success', 'Podcast Part has been deleted successfully.');
        return redirect()->route('admin.podcast_parts.index');
    }

}
