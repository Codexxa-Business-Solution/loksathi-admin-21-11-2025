<?php

namespace App\Http\Controllers\Admin\PodcastParts;

use App\Http\Controllers\Controller;
use App\Models\Podcast;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $podcasts = Podcast::all();
        return view('admin.podcasts.parts.create', compact('podcasts'));
    }
}
