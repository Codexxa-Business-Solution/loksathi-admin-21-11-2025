<?php

namespace App\Http\Controllers\Admin\PodcastParts;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PodcastParts\StorePodcastPartRequest;
use App\Models\PodcastParts;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StorePodcastPartRequest $request): RedirectResponse
    {

        ini_set('upload_max_size', '64M');
        ini_set('post_max_size', '64M');
        ini_set('max_execution_time', '300');

        // store part
        $podcastPart = new PodcastParts();
        $podcastPart->podcast_id = $request->get('podcast_id');
        $podcastPart->name = $request->get('name');
        $podcastPart->description = $request->get('description');
        $podcastPart->index = $request->get('index');
        $podcastPart->notification_title = $request->get('notification_title');

        // image
        if ($request->has('file')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('file'), AppConstants::PODCAST_DIR_NAME); */
            $file = $request->file('file');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::PODCAST_DIR_NAME, $name);
            $podcastPart->file = AppConstants::PODCAST_DIR_NAME . $name;
        }

        if ($request->get('is_premium') == "on") {
            $podcastPart->is_premium = true;
        } else {
            $podcastPart->is_premium = false;
        }

        $podcastPart->scheduled_at = Carbon::parse($request->get('scheduled_at', Carbon::now()));
        if ($request->get('is_scheduled') == "on") {
            $podcastPart->is_scheduled = true;
        } else {
            $podcastPart->is_scheduled = false;
        }

        if ($request->get('is_notified') == "on") {
            $podcastPart->is_notified = true;
        } else {
            $podcastPart->is_notified = false;
        }

        // store
        $podcastPart->save();

        // flash message
        Session::flash('success', 'Podcast part has been added successfully.');

        return redirect()->route('admin.podcast_parts.index');

    }
}
