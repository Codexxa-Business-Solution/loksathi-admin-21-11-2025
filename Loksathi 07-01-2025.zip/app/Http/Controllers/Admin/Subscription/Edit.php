<?php

namespace App\Http\Controllers\Admin\Subscription;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        // find group
        $group = Subscription::find($id);

        // check group exists
        if (!$group) {
            abort(404);
        }

        // return view
        return view('admin.subscriptions.edit', compact('group'));

    }
}
