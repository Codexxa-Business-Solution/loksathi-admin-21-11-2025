<?php

namespace App\Http\Controllers\Admin\Subscription;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $Subscription = Subscription::all();
        return view('admin.subscriptions.index', compact('Subscription'));

    }
}
