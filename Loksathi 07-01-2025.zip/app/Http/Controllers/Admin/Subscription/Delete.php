<?php

namespace App\Http\Controllers\Admin\Subscription;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $statusGroup = Subscription::find($id);

        $type = 'success';
        $message = 'Subscription has been deleted successfully.';

        if (!$statusGroup)
            abort(404);

        // delete
        try {
            $statusGroup->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'Subscription cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.subscriptions.index');
    }
}
