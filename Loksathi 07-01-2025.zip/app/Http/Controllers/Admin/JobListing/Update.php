<?php

namespace App\Http\Controllers\Admin\JobListing;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateJobListingRequest;
use App\Models\JobListing;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    public function __invoke(UpdateJobListingRequest $request, $id): RedirectResponse
    {
        $jobListing = JobListing::find($id);

        if (!$jobListing) {
            abort(404);
        }

        $title = $request->input('title');
        $description = $request->input('description');
        $job_contact_person = $request->input('job_contact_person');
        $job_address = $request->input('job_address');
    
        $languageIds = [];
    
        if (!empty($title['en']) || !empty($description['en']) || !empty($job_contact_person['en']) || !empty($job_address['en'])) {
            $languageIds[] = 3; 
        }
        if (!empty($title['hi']) || !empty($description['hi']) || !empty($job_contact_person['hi']) || !empty($job_address['hi'])) {
            $languageIds[] = 2; 
        }
        if (!empty($title['mr']) || !empty($description['mr']) || !empty($job_contact_person['mr']) || !empty($job_address['mr'])) {
            $languageIds[] = 1; 
        }

        $jobListing->language_id = json_encode($languageIds);
        $jobListing->title = json_encode($title, JSON_UNESCAPED_UNICODE);
        $jobListing->description = json_encode($description, JSON_UNESCAPED_UNICODE);
        $jobListing->job_contact_person = json_encode($job_contact_person, JSON_UNESCAPED_UNICODE);
        $jobListing->job_address = json_encode($job_address, JSON_UNESCAPED_UNICODE);


        $jobListing->location = $request->get('location');
        $jobListing->latitude = $request->get('latitude');
        $jobListing->longitude = $request->get('longitude');
        $jobListing->salary = $request->get('salary');
        $jobListing->experience = $request->get('experience');
        $jobListing->job_type = $request->get('job_type');
        $jobListing->position = $request->get('position');
        $jobListing->contact_number = $request->get('contact_number');
        $jobListing->contact_name = $request->get('contact_name');
        $jobListing->job_category_id = $request->get('job_category_id');
        $jobListing->expiry_date = $request->get('expiry_date');
        $jobListing->is_published = $request->has('is_published');
        $jobListing->is_premium = $request->has('is_premium');

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::JOB_LISTINGS_DIR_NAME, $name);
            $jobListing->image = AppConstants::JOB_LISTINGS_DIR_NAME . $name;
        }

        $jobListing->save();

        if ($request->has('tags')) {
            $jobListing->tags()->sync($request->get('tags'));
        }

        Session::flash('success', 'Job listing has been updated successfully.');

        return redirect()->route('admin.job_listings.index');
    }
}
