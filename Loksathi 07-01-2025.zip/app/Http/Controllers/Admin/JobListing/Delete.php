<?php

namespace App\Http\Controllers\Admin\JobListing;

use App\Http\Controllers\Controller;
use App\Models\JobListing;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    public function __invoke(Request $request, $id): RedirectResponse
    {
        // find job listing
        $jobListing = JobListing::find($id);

        // check job listing exists
        if (!$jobListing) {
            abort(404);
        }

        // delete job listing
        $jobListing->delete();

        Session::flash('success', 'Job listing has been deleted successfully.');
        return redirect()->route('admin.job_listings.index');
    }
}
