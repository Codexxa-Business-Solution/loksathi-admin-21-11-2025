<?php

namespace App\Http\Controllers\Admin\JobListing;

use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use App\Models\GroupCategory;
use App\Models\Tag;
use Illuminate\Http\Request;

class Create extends Controller
{
    public function __invoke(Request $request)
    {
        $jobCategories = JobCategory::orderBy('name')->get();
        $groupCategories = GroupCategory::all();
        $tags = Tag::orderBy('name')->get();
        return view('admin.job_listings.create', compact('jobCategories', 'tags','groupCategories'));
    }
}