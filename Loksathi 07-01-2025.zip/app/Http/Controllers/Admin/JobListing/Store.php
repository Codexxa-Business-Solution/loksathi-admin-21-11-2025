<?php

namespace App\Http\Controllers\Admin\JobListing;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreJobListingRequest;
use App\Models\JobListing;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use App\Models\GroupCategory;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

class Store extends Controller
{
    public function __invoke(StoreJobListingRequest $request): RedirectResponse
    {
        $jobListing = new JobListing();
    
        $title = $request->input('title');
        $description = $request->input('description');
        $job_contact_person = $request->input('job_contact_person');
        $job_address = $request->input('job_address');
    
        $languageIds = [];
    
        if (!empty($title['en']) || !empty($description['en']) || !empty($job_contact_person['en']) || !empty($job_address['en'])) {
            $languageIds[] = 3; 
        }
        if (!empty($title['hi']) || !empty($description['hi']) || !empty($job_contact_person['hi']) || !empty($job_address['hi'])) {
            $languageIds[] = 2; 
        }
        if (!empty($title['mr']) || !empty($description['mr']) || !empty($job_contact_person['mr']) || !empty($job_address['mr'])) {
            $languageIds[] = 1; 
        }
    
        $jobListing->language_id = json_encode($languageIds); 
        $jobListing->title = json_encode($title, JSON_UNESCAPED_UNICODE);
        $jobListing->description = json_encode($description, JSON_UNESCAPED_UNICODE);
        
        $jobListing->job_contact_person = json_encode($job_contact_person, JSON_UNESCAPED_UNICODE);
        $jobListing->job_address = json_encode($job_address, JSON_UNESCAPED_UNICODE);
        

        $jobListing->location = $request->get('location');
        $jobListing->latitude = $request->get('latitude');
        $jobListing->longitude = $request->get('longitude');
        $jobListing->salary = $request->get('salary');
        $jobListing->experience = $request->get('experience');
        $jobListing->job_type = $request->get('job_type');
        $jobListing->position = $request->get('position');
        $jobListing->contact_number = $request->get('contact_number');
        $jobListing->contact_name = $request->get('contact_name');
        $jobListing->job_category_id = $request->get('job_category_id');
        $jobListing->expiry_date = $request->get('expiry_date');
        $jobListing->is_published = $request->has('is_published');
        $jobListing->is_premium = $request->has('is_premium');
        $jobListing->notification_title = $request->get('notification_title');
        
// $notificationTitle = html_entity_decode(strip_tags($request->get('notification_title'), '<br>'));
// $notificationTitle = str_replace(['<br>', '<br/>', '<br />'], "\n", $notificationTitle);
// $notificationTitle = preg_replace('/\s+/', ' ', trim($notificationTitle));

// // Convert newlines to visible line breaks for notifications
// $notificationTitle = str_replace(["\r\n", "\r", "\n"], "\n", $notificationTitle);

// $titling = "New Job -\n" . $notificationTitle;



$rawHtml = $request->get('notification_title');

// 1️⃣ Decode HTML entities (&nbsp;, etc.)
$notificationTitle = html_entity_decode($rawHtml);

// 2️⃣ Replace all <br> and </h3> tags with actual newlines
$notificationTitle = preg_replace('/<\s*br\s*\/?>/i', "\n", $notificationTitle);
$notificationTitle = preg_replace('/<\/h[1-6]>|<\/p>/i', "\n", $notificationTitle);

// 3️⃣ Strip all other HTML tags
$notificationTitle = strip_tags($notificationTitle);

// 4️⃣ Clean up extra spaces and multiple line breaks
$notificationTitle = preg_replace("/\n\s*\n+/", "\n", $notificationTitle);
$notificationTitle = trim($notificationTitle);

// 5️⃣ Build your notification message
$titling = "New Job -\n" . $notificationTitle;



    
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::JOB_LISTINGS_DIR_NAME, $name);
            $jobListing->image = AppConstants::JOB_LISTINGS_DIR_NAME . $name;
        }
    
        $jobListing->save();
    
        if ($request->has('tags')) {
            $jobListing->tags()->sync($request->get('tags'));
        }
        
      try {
            $firebaseFactory = (new Factory)->withServiceAccount(base_path('dignityapp-1cbe2-firebase-adminsdk-npyf1-0c03e2f34b.json'));
            $messaging = $firebaseFactory->createMessaging();
        
            $languages = $jobListing->language_id;
        
            if (is_string($languages)) {
                $languages = json_decode($languages, true); 
            }
        
            if (is_string($languages) && strpos($languages, ',') !== false) {
                $languages = explode(',', $languages);
            }
        
            $langs = \DB::table('languages')->whereIn('id', $languages)->pluck('short_name')->toArray();
        
            $tokens = User::whereNotNull('android_push_token')->pluck('android_push_token')->filter();
        
            $title = $titling;
            $body = $request->get('message'); 
            $image = "https://loksathinews.in/job_listings/notificationlogo.png";  
            $dynamic = "https://loksathinews.in/router?s=job_listings&job_listings_id=" . $jobListing->id;

            foreach (array_chunk($tokens->toArray(), 95) as $tokenGroup) {
                foreach ($tokenGroup as $token) {
                    try {
                        foreach ($langs as $lang) {
                            $message = CloudMessage::fromArray([
                                'token' => $token,
                                'data' => [
                                    "title" => $titling,
                                    "body" => "",
                                    "image" => $image,
                                    "dynamic" => $dynamic,
                                    "lang" => $lang
                                ],
                                'android' => [
                                    'priority' => 'high',
                                ],
                            ]);
        
                            $messaging->send($message);
                        }
                    } catch (\Exception $e) {
                        \Log::error("Failed to send notification for token: {$token}, error: " . $e->getMessage());
                        continue;
                    }
                }
            }
        
        } catch (\Exception $e) {
            Session::flash('error', 'Failed to send notifications: ' . $e->getMessage());
        }
        Session::flash('success', 'Job listing has been added successfully.');
        return redirect()->route('admin.job_listings.index');
    }


}
