<?php

namespace App\Http\Controllers\Admin\JobListing;

use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use App\Models\JobListing;
use App\Models\Tag;
use Illuminate\Http\Request;
use App\Models\GroupCategory;

class Edit extends Controller
{
    public function __invoke(Request $request, $id)
    {
        // find job listing
        $jobListing = JobListing::find($id);
         $groupCategories = GroupCategory::all();

        // check job listing exists
        if (!$jobListing) {
            abort(404);
        }

        $jobCategories = JobCategory::orderBy('name')->get();
        $tags = Tag::orderBy('name')->get();
        $selectedTags = $jobListing->tags->pluck('id')->toArray();

        // return view
        return view('admin.job_listings.edit', compact('jobListing', 'jobCategories', 'tags', 'selectedTags','groupCategories'));
    }
}