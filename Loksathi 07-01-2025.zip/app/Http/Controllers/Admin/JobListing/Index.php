<?php

namespace App\Http\Controllers\Admin\JobListing;

use App\Http\Controllers\Controller;
use App\Models\JobListing;
use Illuminate\Http\Request;

class Index extends Controller
{
    public function __invoke(Request $request)
    {
        $jobListings = JobListing::orderBy('id', 'desc')
            ->simplePaginate(30);
        return view('admin.job_listings.index', compact('jobListings'));
    }
}