<?php

namespace App\Http\Controllers\Admin\PodcastCategory;

use App\Http\Controllers\Controller;
use App\Models\PodcastCategory;
use App\Models\ProductCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $category = PodcastCategory::find($id);

        // check group exists
        if (!$category) {
            abort(404);
        }

        // return view
        return view('admin.podcasts.categories.edit', compact('category'));

    }
}
