<?php

namespace App\Http\Controllers\Admin\PodcastCategory;

use App\Http\Controllers\Controller;
use App\Models\PodcastCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $category = PodcastCategory::find($id);

        $type = 'success';
        $message = 'Podcast category has been deleted successfully.';

        if (!$category)
            abort(404);

        // delete
        try {
            $category->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'Podcast category cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.podcast_categories.index');
    }
}
