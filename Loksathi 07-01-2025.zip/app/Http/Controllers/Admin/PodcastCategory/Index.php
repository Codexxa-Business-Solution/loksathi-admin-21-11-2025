<?php

namespace App\Http\Controllers\Admin\PodcastCategory;

use App\Http\Controllers\Controller;
use App\Models\PodcastCategory;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $categories = PodcastCategory::all();
        return view('admin.podcasts.categories.index', compact('categories'));
    }
}
