<?php

namespace App\Http\Controllers\Admin\PodcastCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PodcastCategory\UpdatePodcastCategoryRequest;
use App\Models\PodcastCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdatePodcastCategoryRequest $request, $id): RedirectResponse
    {

        // store quiz category
        $podcastCategory = PodcastCategory::find($id);
        $podcastCategory->name = $request->get('name', $podcastCategory->name);
        $podcastCategory->description = $request->get('description', $podcastCategory->description);
        $podcastCategory->index = $request->get('index', $podcastCategory->index);
        $podcastCategory->language_id = $request->get('language', $podcastCategory->language_id);

        if ($request->get('is_published') == "on") {
            $podcastCategory->is_published = true;
        } else {
            $podcastCategory->is_published = false;
        }
        if ($request->get('is_featured') == "on") {
            $podcastCategory->is_featured = true;
        } else {
            $podcastCategory->is_featured = false;
        }

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::NEWS_DIR_NAME, $podcastCategory->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::NEWS_DIR_NAME, $name);
            $podcastCategory->image = AppConstants::NEWS_DIR_NAME . $name;
        }

        // store
        $podcastCategory->save();

        // flash message
        Session::flash('success', 'Podcast category has been updated successfully.');

        return redirect()->route('admin.podcast_categories.index');

    }

}
