<?php

namespace App\Http\Controllers\Admin\PodcastCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PodcastCategory\StorePodcastCategoryRequest;
use App\Models\PodcastCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StorePodcastCategoryRequest $request): RedirectResponse
    {

        // store quiz category
        $podcastCategory = new PodcastCategory();
        $podcastCategory->name = $request->get('name');
        $podcastCategory->description = $request->get('description');
        $podcastCategory->index = $request->get('index');
        $podcastCategory->language_id = $request->get('language');

        if ($request->get('is_published') == "on") {
            $podcastCategory->is_published = true;
        } else {
            $podcastCategory->is_published = false;
        }

        if ($request->get('is_featured') == "on") {
            $podcastCategory->is_featured = true;
        } else {
            $podcastCategory->is_featured = false;
        }

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::PODCAST_DIR_NAME, $name);
            $podcastCategory->image = AppConstants::PODCAST_DIR_NAME . $name;
        }

        // store
        $podcastCategory->save();

        // flash message
        Session::flash('success', 'Podcast category has been added successfully.');

        return redirect()->route('admin.podcast_categories.index');
    }
}
