<?php

namespace App\Http\Controllers\Admin\Suggestion;

use App\Http\Controllers\Controller;
use App\Models\Suggestion;
use Illuminate\Http\Request;

class Delete extends Controller
{
    public function __invoke(Request $request, $id)
    {
        $suggestion = Suggestion::findOrFail($id);
        $suggestion->delete();

        return redirect()->route('admin.suggestions.index')
            ->with('success', 'Suggestion deleted successfully!');
    }
}
