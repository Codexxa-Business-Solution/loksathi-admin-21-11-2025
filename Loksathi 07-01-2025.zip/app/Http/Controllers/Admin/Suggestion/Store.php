<?php

namespace App\Http\Controllers\Admin\Suggestion;

use App\Http\Controllers\Controller;
use App\Models\Suggestion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class Store extends Controller
{
    public function __invoke(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'username' => 'required|string',
            'name' => 'required|string',
            'image' => 'nullable',
            'social_type' => 'required',
            'social_link' => 'nullable',
            'index' => 'required|integer|min:0',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        Suggestion::create($request->all());

        return redirect()->route('admin.suggestions.index')
            ->with('success', 'Suggestion created successfully!');
    }
}
