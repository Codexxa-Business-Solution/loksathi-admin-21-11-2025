<?php

namespace App\Http\Controllers\Admin\Suggestion;

use App\Http\Controllers\Controller;
use App\Models\Suggestion;
use Illuminate\Http\Request;

class Index extends Controller
{
    public function __invoke(Request $request)
    {
        $suggestions = Suggestion::orderBy('index', 'asc')
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);
        return view('admin.suggestions.index', compact('suggestions'));
    }
}
