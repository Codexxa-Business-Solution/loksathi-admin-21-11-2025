<?php

namespace App\Http\Controllers\Admin\Suggestion;

use App\Http\Controllers\Controller;
use App\Models\Suggestion;
use Illuminate\Http\Request;

class Edit extends Controller
{
    public function __invoke(Request $request, $id)
    {
        $suggestion = Suggestion::findOrFail($id);
        return view('admin.suggestions.edit', compact('suggestion'));
    }
}
