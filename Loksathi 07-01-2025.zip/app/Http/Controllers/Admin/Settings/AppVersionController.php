<?php

namespace App\Http\Controllers\Admin\Settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;

class AppVersionController extends Controller
{
    public function index()
    {
        $versionName = env('APP_VERSION_NAME', '1.0.0');
        $versionCode = env('APP_VERSION_CODE', 26);
        
        return view('admin.settings.app_version', compact('versionName', 'versionCode'));
    }
    
    public function update(Request $request)
    {
        $request->validate([
            'version_name' => 'required|string',
            'version_code' => 'required|integer|min:1',
        ]);
        
        $envFile = base_path('.env');
        
        if (File::exists($envFile)) {
            $envContent = File::get($envFile);
            
            // Update or add APP_VERSION_NAME
            if (strpos($envContent, 'APP_VERSION_NAME=') !== false) {
                $envContent = preg_replace('/APP_VERSION_NAME=(.*)/', 'APP_VERSION_NAME=' . $request->version_name, $envContent);
            } else {
                $envContent .= "\nAPP_VERSION_NAME=" . $request->version_name;
            }
            
            // Update or add APP_VERSION_CODE
            if (strpos($envContent, 'APP_VERSION_CODE=') !== false) {
                $envContent = preg_replace('/APP_VERSION_CODE=(.*)/', 'APP_VERSION_CODE=' . $request->version_code, $envContent);
            } else {
                $envContent .= "\nAPP_VERSION_CODE=" . $request->version_code;
            }
            
            File::put($envFile, $envContent);
            
            // Clear config cache
            Artisan::call('config:clear');
            
            return redirect()->route('admin.settings.app_version')->with('success', 'App version updated successfully.');
        }
        
        return redirect()->route('admin.settings.app_version')->with('error', 'Failed to update app version. .env file not found.');
    }
}