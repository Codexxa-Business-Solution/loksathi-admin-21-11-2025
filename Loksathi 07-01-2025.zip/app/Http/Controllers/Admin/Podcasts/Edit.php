<?php

namespace App\Http\Controllers\Admin\Podcasts;

use App\Http\Controllers\Controller;
use App\Models\Podcast;
use App\Models\PodcastCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $podcast = Podcast::find($id);
        $podcastCategories = PodcastCategory::all();

        // check group exists
        if (!$podcast) {
            abort(404);
        }

        // return view
        return view('admin.podcasts.edit', compact('podcast', 'podcastCategories'));

    }
}
