<?php

namespace App\Http\Controllers\Admin\Podcasts;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Podcast\UpdatePodcastRequest;
use App\Models\Podcast;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdatePodcastRequest $request, $id): RedirectResponse
    {

        // store podcasts
        $podcast = Podcast::find($id);
        $podcast->podcast_category_id = $request->get('podcast_category_id', $podcast->podcast_category_id);
        $podcast->name = $request->get('name', $podcast->name);
        $podcast->description = $request->get('description', $podcast->description);
        $podcast->index = $request->get('index', $podcast->index);

        if ($request->get('is_published') == "on") {
            $podcast->is_featured = true;
        } else {
            $podcast->is_featured = false;
        }

        if ($request->get('is_published') == "on") {
            $podcast->is_published = true;
        } else {
            $podcast->is_published = false;
        }

        if ($request->get('is_notified') == "on") {
            $podcast->is_notified = true;
        } else {
            $podcast->is_notified = false;
        }

        if ($request->get('is_premium') == "on") {
            $podcast->is_premium = true;
        } else {
            $podcast->is_premium = false;
        }

        if ($request->get('scheduled_at')) {
            $podcast->scheduled_at = Carbon::parse($request->get('scheduled_at'));
        }
        if ($request->get('is_scheduled') == "on") {
            $podcast->is_scheduled = true;
        } else {
            $podcast->is_scheduled = false;
        }

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::PODCAST_DIR_NAME, $podcast->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::PODCAST_DIR_NAME, $name);
            $podcast->image = AppConstants::PODCAST_DIR_NAME . $name;
        }

        // store
        $podcast->save();

        // flash message
        Session::flash('success', 'Podcast has been updated successfully.');

        return redirect()->route('admin.podcasts.index');

    }

}
