<?php

namespace App\Http\Controllers\Admin\Podcasts;

use App\Http\Controllers\Controller;
use App\Models\Podcast;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $podcasts = Podcast::all();
        return view('admin.podcasts.index', compact('podcasts'));
    }
}
