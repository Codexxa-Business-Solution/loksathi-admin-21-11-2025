<?php

namespace App\Http\Controllers\Admin\Podcasts;

use App\Http\Controllers\Controller;
use App\Models\PodcastCategory;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $podcastCategories = PodcastCategory::all();
        return view('admin.podcasts.create', compact('podcastCategories'));
    }
}
