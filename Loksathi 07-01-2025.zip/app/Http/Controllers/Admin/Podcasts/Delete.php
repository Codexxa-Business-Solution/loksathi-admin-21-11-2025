<?php

namespace App\Http\Controllers\Admin\Podcasts;

use App\Http\Controllers\Controller;
use App\Models\Podcast;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $podcast = Podcast::find($id);

        $type = 'success';
        $message = 'Podcast has been deleted successfully.';

        if (!$podcast)
            abort(404);

        // delete
        try {
            $podcast->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'Podcast cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.podcasts.index');
    }

}
