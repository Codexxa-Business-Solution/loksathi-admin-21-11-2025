<?php

namespace App\Http\Controllers\Admin\Podcasts;

use App\Enums\AppConstants;
use App\Enums\GroupMessageType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Podcast\StorePodcastRequest;
use App\Models\Podcast;
use App\Models\User;
use App\Services\BunnyCdnStorage;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StorePodcastRequest $request): RedirectResponse
    {

        // store podcasts
        $podcast = new Podcast();
        $podcast->podcast_category_id = $request->get('podcast_category_id');
        $podcast->name = $request->get('name');
        $podcast->description = $request->get('description');
        $podcast->index = $request->get('index');

        if ($request->get('is_featured') == "on") {
            $podcast->is_featured = true;
        } else {
            $podcast->is_featured = false;
        }

        if ($request->get('is_published') == "on") {
            $podcast->is_published = true;
        } else {
            $podcast->is_published = false;
        }

        if ($request->get('is_notified') == "on") {
            $podcast->is_notified = true;
        } else {
            $podcast->is_notified = false;
        }

        if ($request->get('is_premium') == "on") {
            $podcast->is_premium = true;
        } else {
            $podcast->is_premium = false;
        }

        $podcast->scheduled_at = Carbon::parse($request->get('scheduled_at', Carbon::now()));
        if ($request->get('is_scheduled') == "on") {
            $podcast->is_scheduled = true;
        } else {
            $podcast->is_scheduled = false;
        }

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::PODCAST_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::PODCAST_DIR_NAME, $name);
            $podcast->image = AppConstants::PODCAST_DIR_NAME . $name;
        }

        // store
        $podcast->save();

        // flash message
        Session::flash('success', 'Podcast has been added successfully.');

        return redirect()->route('admin.podcasts.index');

    }
}
