<?php

namespace App\Http\Controllers\Admin\JobCategory;

use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    public function __invoke(Request $request, $id)
    {
        // find job category
        $jobCategory = JobCategory::find($id);

        if (!$jobCategory) {
            return redirect()->route('admin.job_categories.index')
                ->with('error', 'Job category not found.');
        }

        return view('admin.job_categories.edit', compact('jobCategory'));
    }
}