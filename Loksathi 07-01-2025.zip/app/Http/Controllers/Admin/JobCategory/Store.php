<?php

namespace App\Http\Controllers\Admin\JobCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class Store extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'description' => 'nullable|string',
        ]);

        // Create new job category
        $jobCategory = new JobCategory();
        $jobCategory->name = $request->get('name');
        $jobCategory->description = $request->get('description');

        // Handle image upload if provided
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::JOB_CATEGORIES_DIR_NAME, $name);
            $jobCategory->image = AppConstants::JOB_CATEGORIES_DIR_NAME . $name;
        }

        // Save job category
        $jobCategory->save();

        return redirect()->route('admin.job_categories.index')
            ->with('success', 'Job category created successfully.');
    }
}