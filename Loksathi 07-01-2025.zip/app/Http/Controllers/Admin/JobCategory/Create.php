<?php

namespace App\Http\Controllers\Admin\JobCategory;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Create extends Controller
{
    public function __invoke(Request $request)
    {
        return view('admin.job_categories.create');
    }
}