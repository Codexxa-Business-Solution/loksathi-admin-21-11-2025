<?php

namespace App\Http\Controllers\Admin\JobCategory;

use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use Illuminate\Http\Request;

class Index extends Controller
{
    public function __invoke(Request $request)
    {
        $jobCategories = JobCategory::orderBy('created_at', 'desc')
            ->simplePaginate(30);
        return view('admin.job_categories.index', compact('jobCategories'));
    }
}