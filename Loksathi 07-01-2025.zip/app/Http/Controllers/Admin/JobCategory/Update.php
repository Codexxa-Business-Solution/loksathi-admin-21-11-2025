<?php

namespace App\Http\Controllers\Admin\JobCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class Update extends Controller
{
    public function __invoke(Request $request, $id): RedirectResponse
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'description' => 'nullable|string',
        ]);

        $jobCategory = JobCategory::find($id);

        if (!$jobCategory) {
            return redirect()->route('admin.job_categories.index')
                ->with('error', 'Job category not found.');
        }

        // Update job category
        $jobCategory->name = $request->get('name');
        $jobCategory->description = $request->get('description');
        
        // Handle image upload if provided
        if ($request->hasFile('image')) {
            // Delete old image if it exists
            if ($jobCategory->image && File::exists(public_path($jobCategory->image))) {
                File::delete(public_path($jobCategory->image));
            }
            
            // Upload new image
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::JOB_CATEGORIES_DIR_NAME, $name);
            $jobCategory->image = AppConstants::JOB_CATEGORIES_DIR_NAME . $name;
        }

        // Save job category
        $jobCategory->save();

        return redirect()->route('admin.job_categories.index')
            ->with('success', 'Job category updated successfully.');
    }
}