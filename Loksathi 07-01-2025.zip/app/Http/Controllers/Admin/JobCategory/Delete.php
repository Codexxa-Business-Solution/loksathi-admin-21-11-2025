<?php

namespace App\Http\Controllers\Admin\JobCategory;

use App\Http\Controllers\Controller;
use App\Models\JobCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class Delete extends Controller
{
    public function __invoke(Request $request, $id): RedirectResponse
    {
        // find job category
        $jobCategory = JobCategory::find($id);

        if (!$jobCategory) {
            return redirect()->route('admin.job_categories.index')
                ->with('error', 'Job category not found.');
        }

        $jobCategory->delete();

        return redirect()->route('admin.job_categories.index')
            ->with('success', 'Job category deleted successfully.');
    }
}