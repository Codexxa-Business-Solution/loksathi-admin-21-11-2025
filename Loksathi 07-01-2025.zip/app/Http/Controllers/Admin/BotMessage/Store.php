<?php

namespace App\Http\Controllers\Admin\BotMessage;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\BotMessage\StoreBotMessageRequest;
use App\Models\BotMessage;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreBotMessageRequest $request): RedirectResponse
    {

        // store group
        $botMessage = new BotMessage();
        $botMessage->bot_id = $request->get('bot_id');
        $botMessage->type = $request->get('type');
        $botMessage->name = $request->get('name');
        $botMessage->title_prefix = $request->get('title_prefix');
        $botMessage->message = $request->get('message');
        $botMessage->key = $request->get('key');
        $botMessage->sub_key = $request->get('sub_key');
        $botMessage->main_key = $request->get('main_key');
        $botMessage->main_key_title = $request->get('main_title');
        $botMessage->main_sub_key = $request->get('main_sub_key');
        $botMessage->main_sub_key_title = $request->get('main_sub_key_title');
        $botMessage->slide_info = $request->get('slide_info');

        // image
        if ($request->has('file')) {
            // store file
            $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('file'), AppConstants::GROUP_DIR_NAME);
            $botMessage->file = AppConstants::GROUP_DIR_NAME . $name;
        }

        // store
        $botMessage->save();

        // flash message
        Session::flash('success', 'Bot message has been added successfully.');

        return redirect()->route('admin.bot_messages.index');

    }
}
