<?php

namespace App\Http\Controllers\Admin\BotMessage;

use App\Http\Controllers\Controller;
use App\Models\BotMessage;
use App\Models\GroupMessage;
use App\Models\Status;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $groupMessages = BotMessage::find($id);

        if (!$groupMessages)
            abort(404);

        // delete
        $groupMessages->delete();

        // flash and redirect
        Session::flash('success', 'Bot message has been deleted successfully.');
        return redirect()->route('admin.bot_messages.index');

    }
}
