<?php

namespace App\Http\Controllers\Admin\BotMessage;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\BotMessage;
use App\Models\Group;
use App\Models\GroupMessage;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $botId = $request->get('bot_id');

        if ($botId) {
            $group = Bot::find($botId);
            $messages = BotMessage::where('bot_id', $botId)
                ->with('bot')->get();
            $title = "List of all messages of group " . $group->name;
        } else {
            $title = "List of all messages";
            $messages = BotMessage::with('bot')->get();
        }

        return view('admin.bot.messages.index', compact('messages', 'title'));
    }
}
