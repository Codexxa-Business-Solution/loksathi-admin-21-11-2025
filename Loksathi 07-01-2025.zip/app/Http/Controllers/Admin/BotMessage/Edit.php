<?php

namespace App\Http\Controllers\Admin\BotMessage;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\BotMessage;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        // find group
        $message = BotMessage::find($id);
        $bots = Bot::all();

        // check group exists
        if (!$message) {
            abort(404);
        }

        // return view
        return view('admin.bot.messages.edit', compact('message', 'bots'));

    }
}
