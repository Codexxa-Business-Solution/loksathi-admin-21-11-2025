<?php

namespace App\Http\Controllers\Admin\BotMessage;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\BotMessage\UpdateBotMessageRequest;
use App\Models\BotMessage;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateBotMessageRequest $request, $id): RedirectResponse
    {

        // store group
        $botMessage = BotMessage::find($id);
        $botMessage->bot_id = $request->get('bot_id', $botMessage->bot_id);
        $botMessage->type = $request->get('type', $botMessage->type);
        $botMessage->name = $request->get('name', $botMessage->name);
        $botMessage->title_prefix = $request->get('title_prefix');
        $botMessage->message = $request->get('message', $botMessage->message);
        $botMessage->key = $request->get('key', $botMessage->key);
        $botMessage->sub_key = $request->get('sub_key', $botMessage->sub_key);
        $botMessage->main_key = $request->get('main_key');
        $botMessage->main_key_title = $request->get('main_title');
        $botMessage->main_sub_key = $request->get('main_sub_key');
        $botMessage->main_sub_key_title = $request->get('main_sub_key_title');
        $botMessage->slide_info = $request->get('slide_info', $botMessage->slide_info);

        // image
        if ($request->has('file')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('file'), AppConstants::GROUP_DIR_NAME, $botMessage->file); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::GROUP_DIR_NAME, $name);
            $botMessage->file = AppConstants::GROUP_DIR_NAME . $name;
        }

        // store
        $botMessage->save();

        // flash message
        Session::flash('success', 'Bot message has been updated successfully.');

        return redirect()->route('admin.bot_messages.index');

    }
}
