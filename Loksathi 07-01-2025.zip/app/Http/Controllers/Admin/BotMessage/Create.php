<?php

namespace App\Http\Controllers\Admin\BotMessage;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {

        // bots
        $bots = Bot::all();

        return view('admin.bot.messages.create', compact('bots'));
    }
}
