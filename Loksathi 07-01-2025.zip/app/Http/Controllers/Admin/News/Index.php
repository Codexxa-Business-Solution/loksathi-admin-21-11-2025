<?php

namespace App\Http\Controllers\Admin\News;

use App\Http\Controllers\Controller;
use App\Models\News;
use App\Models\NewsComment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $newses = News::withCount('comments', 'likes')->orderBy('created_at', 'desc')
            ->simplePaginate(30);
        return view('admin.news.index', compact('newses'));
    }

    public function comments($newsId)
    {
        $newses = NewsComment::join('users', 'users.id', '=', 'news_comments.id')
            ->select(['users.name', 'news_comments.*'])
            ->orderBy('created_at', 'desc')
            ->simplePaginate(30);
        return view('admin.news.comment', compact('newses'));
    }

    public function reportedComments()
    {
        $results = DB::table('news_comment_reports')
            ->join('news_comments', 'news_comments.id', '=', 'news_comment_reports.comment_id')
            ->select(DB::raw('comment_id, CONCAT(reason, ": ", COUNT(*)) AS reported_reason'))
            ->groupBy('comment_id', 'reason');

        $newses = DB::table(DB::raw("({$results->toSql()}) as reasons"))
            ->mergeBindings($results)
            ->select(
                'reasons.comment_id',
                DB::raw('GROUP_CONCAT(reported_reason ORDER BY reported_reason ASC SEPARATOR ",") AS reported_reasons'),
                'news.name as news',
                'users.name',
                'news_comments.is_inactive',
                'news_comments.comment'
            )
            ->join('news_comments', 'news_comments.id', 'reasons.comment_id')
            ->join('news', 'news.id', 'news_comments.news_id')
            ->join('users', 'users.id', 'news_comments.user_id')
            ->groupBy('comment_id', 'users.name', 'news.name', 'news_comments.comment', 'news_comments.is_inactive')
            ->orderBy('news_comments.created_at', 'desc')
            ->orderBy('news_comments.is_inactive', 'asc')
            ->paginate(30);
            
            
        return view('admin.news.reported-comment', compact('newses'));
    }
    
    public function deleteComment($comment_id, $status)
    {

        $comment = NewsComment::find($comment_id);

        if (!$comment)
            abort(404);

       $comment->update(['is_inactive' => $status]);

        $res = ['activated', 'inactivated'];

        Session::flash('success', "Comment has been {$res[$status]} successfully.");
        return redirect()->route('admin.news.reported-comments');
    }
}
