<?php

namespace App\Http\Controllers\Admin\News;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\News;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $news = News::find($id);

        if (!$news)
            abort(404);

        // delete
        $news->delete();

        // flash and redirect
        Session::flash('success', 'News has been deleted successfully.');
        return redirect()->route('admin.news.index');
    }

}
