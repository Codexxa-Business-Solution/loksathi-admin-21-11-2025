<?php

namespace App\Http\Controllers\Admin\News;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\News\UpdateNewsRequest;
use App\Models\News;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateNewsRequest $request, $id): RedirectResponse
    {

        $news = News::find($id);
        $news->news_category_id = $request->get('news_category_id', $news->news_category_id);
        $news->district_id = $request->get('district_id', $news->district_id);
        $news->type = $request->get('type', $news->type);
        $news->name = $request->get('name', $news->name);
        $news->message = $request->get('message', $news->message);
        $news->link = $request->get('link', $news->link);
        $news->notification_title = $request->get('notification_title', $news->notification_title);

        if ($request->get('scheduled_at')) {
            $news->scheduled_at = Carbon::parse($request->get('scheduled_at'));
        }
        if ($request->get('is_scheduled') == "on") {
            $news->is_scheduled = true;
        } else {
            $news->is_scheduled = false;
        }

        if ($request->get('is_published') == "on") {
            $news->is_published = true;
        } else {
            $news->is_published = false;
        }

        if ($request->get('is_notified') == "on") {
            $news->is_notified = true;
        } else {
            $news->is_notified = false;
        }

        // image
        if ($request->has('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::NEWS_DIR_NAME, $name);
            $news->image = AppConstants::NEWS_DIR_NAME . $name;
        }

        //
        if ($request->hasFile('images')) {
            $images = array();
            foreach ($request->file('images') as $image) {
                $name = md5($image . microtime()) . '.' . $image->extension();
                $image->move(AppConstants::NEWS_DIR_NAME, $name);
                $images[] = AppConstants::NEWS_DIR_NAME . $name;
            }
            $news->images = json_encode($images);
        }

        // store
        $news->save();

        // flash message
        Session::flash('success', 'News has been updated successfully.');

        return redirect()->route('admin.news.index');

    }

}
