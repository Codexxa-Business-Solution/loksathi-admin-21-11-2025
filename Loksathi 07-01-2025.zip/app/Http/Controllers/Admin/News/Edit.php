<?php

namespace App\Http\Controllers\Admin\News;

use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\News;
use App\Models\NewsCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $news = News::find($id);

        // check group exists
        if (!$news) {
            abort(404);
        }

        $newsCategories = NewsCategory::all();
        $districts = District::orderBy('name_en')->get();

        // return view
        return view('admin.news.edit', compact('news', 'newsCategories', 'districts'));

    }
}
