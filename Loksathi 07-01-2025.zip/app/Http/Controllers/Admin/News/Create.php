<?php

namespace App\Http\Controllers\Admin\News;

use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\NewsCategory;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $newsCategories = NewsCategory::all();
        $districts = District::orderBy('name_en')->get();
        return view('admin.news.create', compact('newsCategories', 'districts'));
    }
}
