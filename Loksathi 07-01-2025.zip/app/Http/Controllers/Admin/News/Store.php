<?php

namespace App\Http\Controllers\Admin\News;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\News\StoreNewsRequest;
use App\Models\News;
use App\Models\NewsCategory;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

class Store extends Controller
{
    public function __invoke(StoreNewsRequest $request): RedirectResponse
    {
        // Store news
        $news = new News();
        $news->news_category_id = $request->get('news_category_id');
        $news->district_id = $request->get('district_id');
        $news->type = $request->get('type');
        $news->name = $request->get('name');
        $news->message = $request->get('message');
        $news->link = $request->get('link');
        $news->notification_title = $request->get('notification_title');
        $news->scheduled_at = Carbon::parse($request->get('scheduled_at', Carbon::now()));
        $news->is_scheduled = $request->has('is_scheduled');
        $news->is_published = $request->has('is_published');
        $news->is_notified = $request->has('is_notified');

        // image
        if ($request->has('image')) {
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::NEWS_DIR_NAME, $name);
            $news->image = AppConstants::NEWS_DIR_NAME . $name;
        }

        //
        if ($request->hasFile('images')) {
            $images = array();
            foreach ($request->file('images') as $image) {
                $name = md5($image . microtime()) . '.' . $image->extension();
                $image->move(AppConstants::NEWS_DIR_NAME, $name);
                $images[] = AppConstants::NEWS_DIR_NAME . $name;
            }
            $news->images = json_encode($images);
        }

        // Store news
        $news->save();

        if (!$news->is_scheduled && $news->is_notified && $news->is_published) {

            try {

                $firebaseFactory = (new Factory)->withServiceAccount(base_path('dignityapp-1cbe2-firebase-adminsdk-npyf1-0c03e2f34b.json'));
                $messaging = $firebaseFactory->createMessaging();

                $lang = NewsCategory::join('languages', 'languages.id', '=', 'news_categories.language_id')
                    ->where('news_categories.id', $news->news_category_id)
                    ->select('languages.short_name')
                    ->first()
                    ->short_name;

                $tokens = User::whereNotNull('android_push_token')
                    ->pluck('android_push_token')->filter();

                $title = $request->get('notification_title');
                $body = $request->get('message');
                
                $plainText = strip_tags($body);

                
                $image = "https://loksathinews.in/" . $news->image;
                $dynamic = "https://loksathinews.in/router?s=news&news_id=" . $news->id;

                foreach (array_chunk($tokens->toArray(), 95) as $tokenGroup) {
                    foreach ($tokenGroup as $token) {
                        try {
                            $message = CloudMessage::fromArray([
                                'token' => $token,
                                'data' => [
                                    "title" => $title,
                                    "body" => $plainText,
                                    "image" => $image,
                                    "dynamic" => $dynamic,
                                    "lang" => $lang
                                ],
                                'android' => [
                                    'priority' => 'high',
                                ],
                            ]);

                            $messaging->send($message);
                        } catch (\Exception $e) {
                            \Log::error("Failed to send notification for token: {$token}, error: " . $e->getMessage());
                            continue;
                        }
                    }
                }

            } catch (\Exception $e) {
                Session::flash('error', 'Failed to send notifications: ' . $e->getMessage());
            }
        }

        Session::flash('success', 'News has been added successfully.');
        return redirect()->route('admin.news.index');
    }
}
