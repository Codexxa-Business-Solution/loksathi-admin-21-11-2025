<?php

namespace App\Http\Controllers\Admin\Status;

use App\Http\Controllers\Controller;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $groups = StatusGroup::all();
        return view('admin.statuses.create', compact('groups'));
    }
}
