<?php

namespace App\Http\Controllers\Admin\Status;

use App\Http\Controllers\Controller;
use App\Models\Status;
use App\Models\StatusGroup;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $status = Status::find($id);

        if (!$status)
            abort(404);

        // delete
        $status->delete();

        // flash and redirect
        Session::flash('success', 'Status has been deleted successfully.');
        return redirect()->route('admin.statuses.index');

    }

}
