<?php

namespace App\Http\Controllers\Admin\Status;

use App\Enums\AppConstants;
use App\Enums\StatusType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Status\StoreStatusRequest;
use App\Models\Status;
use App\Services\BunnyCdnStorage;
use App\Services\PushService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreStatusRequest $request): RedirectResponse
    {

        if ($request->get('type') == StatusType::TYPE_TEXT || $request->get('type') == StatusType::TYPE_LINK) {
            if (is_null($request->get('message'))) {
                Session::flash('error', 'Status message is required for type ' . $request->get('type'));
                return redirect()->back();
            }
        }

        if ($request->get('type') == StatusType::TYPE_VIDEO || $request->get('type') == StatusType::TYPE_IMAGE) {
            if (!$request->has('file')) {
                Session::flash('error', 'Status file is required for type ' . $request->get('type'));
                return redirect()->back();
            }
        }

        if ($request->get('type') == StatusType::TYPE_AD) {
            if ((!$request->has('file')) && is_null($request->get('message'))) {
                Session::flash('error', 'Status message or Status file is required for type ' . $request->get('type'));
                return redirect()->back();
            }
        }

        // store group
        $status = new Status();
        $status->type = $request->get('type');
        $status->status_group_id = $request->get('status_group_id');
        $status->message = $request->get('message');
        $status->scheduled_at = Carbon::parse($request->get('scheduled_at', Carbon::now()));
        $status->color_bg = $request->get('color_bg');
        $status->index = $request->get('index');
        $status->color_text = $request->get('color_text');
        $status->notification_title = $request->get('notification_title');

        if ($request->get('is_scheduled') == "on") {
            $status->is_scheduled = true;
        } else {
            $status->is_scheduled = false;
        }

        if ($request->get('is_notified') == "on") {
            $status->is_notified = true;
        } else {
            $status->is_notified = false;
        }

        if ($request->get('is_premium') == "on") {
            $status->is_premium = true;
        } else {
            $status->is_premium = false;
        }

        // image
        if ($request->has('file')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('file'), AppConstants::STATUS_DIR_NAME); */
            $file = $request->file('file');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::STATUS_DIR_NAME, $name);
            $status->file = AppConstants::STATUS_DIR_NAME . $name;
        }

        // store
        $status->save();

        // send instant push notification
        if (!$status->is_scheduled && $status->is_notified) {
            PushService::sendStatusNotification($status);
        }

        // flash message
        Session::flash('success', 'Status has been added successfully.');

        return redirect()->route('admin.statuses.index');
    }
}
