<?php

namespace App\Http\Controllers\Admin\Status;

use App\Http\Controllers\Controller;
use App\Models\Status;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $groupId = $request->get('group_id');
        if ($groupId) {
            $group = StatusGroup::find($groupId);
            $statuses = Status::where('status_group_id', $groupId)
                ->with('group')
                ->latest()
                ->get();
            $title = "List of all statuses of group " . $group->name;
        } else {
            $title = "List of all statuses";
            $statuses = Status::with('group')
            ->latest()->get();
        }
        return view('admin.statuses.index', compact('statuses', 'title'));
    }
}
