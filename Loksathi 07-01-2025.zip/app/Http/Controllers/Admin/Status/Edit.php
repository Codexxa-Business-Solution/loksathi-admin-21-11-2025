<?php

namespace App\Http\Controllers\Admin\Status;

use App\Http\Controllers\Controller;
use App\Models\Status;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        // find group
        $status = Status::find($id);
        $groups = StatusGroup::all();

        // check group exists
        if (!$status) {
            abort(404);
        }

        // return view
        return view('admin.statuses.edit', compact('status', 'groups'));

    }
}
