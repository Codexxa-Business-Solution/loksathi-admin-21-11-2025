<?php

namespace App\Http\Controllers\Admin\Status;

use App\Enums\AppConstants;
use App\Enums\StatusType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Status\UpdateStatusRequest;
use App\Models\Status;
use App\Services\BunnyCdnStorage;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateStatusRequest $request, $id): RedirectResponse
    {

        // store group
        $status = Status::find($id);
        $status->type = $request->get('type', $status->type);
        $status->status_group_id = $request->get('status_group_id', $status->status_group_id);
        $status->message = $request->get('message', $status->message);
        $status->scheduled_at = Carbon::parse($request->get('scheduled_at', $status->scheduled_at));
        $status->color_bg = $request->get('color_bg', $status->color_bg);
        $status->index = $request->get('index', $status->index);
        $status->color_text = $request->get('color_text', $status->color_text);
        $status->notification_title = $request->get('notification_title', $status->notification_title);

        if ($request->get('is_scheduled') == "on") {
            $status->is_scheduled = true;
        } else {
            $status->is_scheduled = false;
        }

        if ($request->get('is_notified') == "on") {
            $status->is_notified = true;
        } else {
            $status->is_notified = false;
        }

        if ($request->get('is_premium') == "on") {
            $status->is_premium = true;
        } else {
            $status->is_premium = false;
        }

        // image
        if ($request->has('file')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('file'), AppConstants::STATUS_DIR_NAME, $status->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::STATUS_DIR_NAME, $name);
            $status->file = AppConstants::STATUS_DIR_NAME . $name;
        }

        // store
        $status->save();

        // flash message
        Session::flash('success', 'Status has been updated successfully.');

        return redirect()->route('admin.statuses.index');

    }
}
