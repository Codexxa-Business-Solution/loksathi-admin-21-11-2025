<?php

namespace App\Http\Controllers\Admin\QuizMessage;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\QuizCategory;
use App\Models\QuizMessage;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $category = QuizMessage::find($id);

        // check group exists
        if (!$category) {
            abort(404);
        }

        // return view
        return view('admin.quizzes.categories.edit', compact('category'));

    }
}
