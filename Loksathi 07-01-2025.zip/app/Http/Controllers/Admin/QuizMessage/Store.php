<?php

namespace App\Http\Controllers\Admin\QuizMessage;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\QuizCategory\StoreQuizCategoryRequest;
use App\Models\QuizCategory;
use App\Services\BunnyCdnStorage;
use App\Services\PushService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreQuizCategoryRequest $request): RedirectResponse
    {

        // store quiz category
        $groupCategory = new QuizCategory();
        $groupCategory->name = $request->get('name');
        $groupCategory->description = $request->get('description');
        $groupCategory->index = $request->get('index');
        $groupCategory->language_id = $request->get('language');

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::QUIZ_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::QUIZ_DIR_NAME, $name);
            $groupCategory->image = AppConstants::QUIZ_DIR_NAME . $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'Quiz category has been added successfully.');

        return redirect()->route('admin.quiz_categories.index');

    }
}
