<?php

namespace App\Http\Controllers\Admin\QuizMessage;

use App\Enums\GroupType;
use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\QuizCategory;
use App\Models\QuizMessage;
use Illuminate\Http\Request;

class NewCreate extends Controller
{
    //
    public function __invoke(Request $request)
    {

        // id
        $quizId = $request->get('quiz_id');

        // data
        $quizGroups = Group::where('type', GroupType::TYPE_QUIZ)
            ->get();
        $quizCategories = QuizCategory::all();
        $quizMessage = QuizMessage::find($quizId);

        return view('admin.quizzes.new_create', compact('quizGroups', 'quizCategories', 'quizMessage'));
    }
}
