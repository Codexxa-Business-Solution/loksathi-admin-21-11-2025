<?php

namespace App\Http\Controllers\Admin\QuizMessage;

use App\Enums\GroupType;
use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\QuizCategory;
use App\Models\QuizMessage;
use Illuminate\Http\Request;

class NewStore extends Controller
{
    //
    public function __invoke(Request $request)
    {



    }
}
