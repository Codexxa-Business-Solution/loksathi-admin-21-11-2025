<?php

namespace App\Http\Controllers\Admin\QuizMessage;

use App\Http\Controllers\Controller;
use App\Models\QuizMessage;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $quizMessages = QuizMessage::orderBy('created_at', 'desc')
            ->simplePaginate(50);
        return view('admin.quizzes.index', compact('quizMessages'));
    }
}
