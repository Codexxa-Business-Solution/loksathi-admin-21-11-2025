<?php

namespace App\Http\Controllers\Admin\QuizMessage;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\QuizCategory;
use App\Models\QuizMessage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        $group = QuizMessage::find($id);

        $type = 'success';
        $message = 'Podcast has been deleted successfully.';

        if (!$group)
            abort(404);

        // delete
        try {
            $group->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'group cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);

        return redirect()->route('admin.quiz_messages.index');
    }
}
