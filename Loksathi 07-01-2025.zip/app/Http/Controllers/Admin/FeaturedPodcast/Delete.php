<?php

namespace App\Http\Controllers\Admin\FeaturedPodcast;

use App\Http\Controllers\Controller;
use App\Models\FeaturedPodcast;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $group = FeaturedPodcast::find($id);

        if (!$group)
            abort(404);

        // delete
        $group->delete();

        // flash and redirect
        Session::flash('success', 'Featured podcast has been deleted successfully.');
        return redirect()->route('admin.featured_podcasts.index');


    }
}
