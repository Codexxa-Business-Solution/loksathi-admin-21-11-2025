<?php

namespace App\Http\Controllers\Admin\FeaturedPodcast;

use App\Http\Controllers\Controller;
use App\Models\FeaturedPodcast;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $featuredPodcasts = FeaturedPodcast::with('podcast', 'category')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('admin.featured_podcasts.index', compact('featuredPodcasts'));
    }
}
