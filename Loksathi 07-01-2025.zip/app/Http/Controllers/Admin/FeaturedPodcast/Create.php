<?php

namespace App\Http\Controllers\Admin\FeaturedPodcast;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        return view('admin.featured_podcasts.create');
    }
}
