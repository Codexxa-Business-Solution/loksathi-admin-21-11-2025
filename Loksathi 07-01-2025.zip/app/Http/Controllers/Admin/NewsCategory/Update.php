<?php

namespace App\Http\Controllers\Admin\NewsCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\NewsCategory\UpdateNewsCategoryRequest;
use App\Models\NewsCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateNewsCategoryRequest $request, $id): RedirectResponse
    {

        // store quiz category
        $groupCategory = NewsCategory::find($id);
        $groupCategory->name = $request->get('name', $groupCategory->name);
        $groupCategory->description = $request->get('description', $groupCategory->description);
        $groupCategory->index = $request->get('index', $groupCategory->index);
        $groupCategory->language_id = $request->get('language', $groupCategory->language_id);

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::NEWS_DIR_NAME, $groupCategory->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::NEWS_DIR_NAME, $name);
            $groupCategory->image = AppConstants::NEWS_DIR_NAME . $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'News category has been updated successfully.');

        return redirect()->route('admin.news_categories.index');
    }
}
