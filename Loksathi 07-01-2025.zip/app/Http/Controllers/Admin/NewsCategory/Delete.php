<?php

namespace App\Http\Controllers\Admin\NewsCategory;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\NewsCategory;
use App\Models\QuizCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $category = NewsCategory::find($id);



        $type = 'success';
        $message = 'News category has been deleted successfully.';

        if (!$category)
            abort(404);

        // delete
        try {
            $category->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'News category cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.news_categories.index');
    }
}
