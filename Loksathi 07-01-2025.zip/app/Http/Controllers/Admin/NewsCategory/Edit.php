<?php

namespace App\Http\Controllers\Admin\NewsCategory;

use App\Http\Controllers\Controller;
use App\Models\NewsCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $category = NewsCategory::find($id);

        // check group exists
        if (!$category) {
            abort(404);
        }

        // return view
        return view('admin.news.categories.edit', compact('category'));

    }
}
