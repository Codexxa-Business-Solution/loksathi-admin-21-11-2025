<?php

namespace App\Http\Controllers\Admin\NewsCategory;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\NewsCategory\StoreNewsCategoryRequest;
use App\Models\NewsCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreNewsCategoryRequest $request): RedirectResponse
    {

        // store quiz category
        $groupCategory = new NewsCategory();
        $groupCategory->name = $request->get('name');
        $groupCategory->description = $request->get('description');
        $groupCategory->index = $request->get('index');
        $groupCategory->language_id = $request->get('language');

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::NEWS_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::NEWS_DIR_NAME, $name);
            $groupCategory->image = AppConstants::NEWS_DIR_NAME . $name;
        }

        // store
        $groupCategory->save();

        // flash message
        Session::flash('success', 'News category has been added successfully.');

        return redirect()->route('admin.news_categories.index');
    }
}
