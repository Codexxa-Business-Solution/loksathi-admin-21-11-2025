<?php

namespace App\Http\Controllers\Admin\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\BloodGroupMessage;
use App\Models\Business;
use App\Models\BuySellMessage;
use App\Models\DiscussMessage;
use App\Models\GroupComment;
use App\Models\User;


use App\Models\JobListing;
use App\Models\Subscription;
use App\Models\Agent;
use App\Models\PlanPurchase;
use App\Models\Group;
use App\Models\Gr;
use App\Models\Status;
use App\Models\CustomAd;
use App\Models\News;
use App\Enums\PaymentStatus;


use Illuminate\Http\Request;

class Index extends Controller
{
    public function __invoke(Request $request)
    {
        $businessesCount = Business::query()->count();
        $bloodMessagesCount = BloodGroupMessage::query()->count();
        $helpMessagesCount = BuySellMessage::query()->count();
        $activeUserCount = User::query()->count();
        $discussMessagesCount = DiscussMessage::query()->count();
        $commentsCount = GroupComment::query()->count();
        
        $jobsCount = JobListing::query()->count();
        $subscriptionCount = Subscription::query()->count();
        $agentCount = Agent::query()->count();
        $planCount = PlanPurchase::leftJoin('users', 'plan_purchases.user_id', '=', 'users.id')
            ->leftJoin('agents', 'plan_purchases.agent_id', '=', 'agents.id')
            ->leftJoin('subscriptions', 'plan_purchases.subscription_id', '=', 'subscriptions.id')
            ->where('plan_purchases.status',PaymentStatus::STATUS_PAID)
            ->count();
        
        $groupCount = Group::query()->count();
        $grCount = Gr::query()->count();
        $statusCount = Status::query()->count();
        $customadCount = CustomAd::query()->count();
        $newsCount = News::query()->count();

        $actionData = array(
            array('name' => 'Total Users', 'value' => $activeUserCount, 'link' => route('admin.users.index')),
            array('name' => 'Total Businesses', 'value' => $businessesCount, 'link' => route('admin.extras.index')),
            array('name' => 'Blood Messages', 'value' => $bloodMessagesCount, 'link' => route('admin.messages.blood.index')),
            array('name' => 'Help Messages', 'value' => $helpMessagesCount, 'link' => route('admin.messages.help.index')),
            array('name' => 'Discuss Messages', 'value' => $discussMessagesCount, 'link' => route('admin.messages.discuss.index')),
            array('name' => 'Total Comments', 'value' => $commentsCount, 'link' => route('admin.comments.index')),
            array('name' => 'Total Jobs', 'value' => $jobsCount, 'link' => route('admin.job_listings.index')),
            array('name' => 'Total Subscriptions', 'value' => $subscriptionCount, 'link' => route('admin.subscriptions.index')),
            array('name' => 'Total Agents', 'value' => $agentCount, 'link' => route('admin.agents.index')),
            array('name' => 'Total Subscribed Users','value' => $planCount,'link' => route('admin.subscribed.index')),
            array('name' => 'Total Groups','value' => $groupCount,'link' => route('admin.groups.index')),
            array('name' => 'Total GR','value' => $grCount,'link' => route('admin.grs.index')),
            array('name' => 'Total Status','value' => $statusCount,'link' => route('admin.statuses.index')),
            array('name' => 'Total Custom Ads','value' => $customadCount,'link' => route('admin.custom_ads.index')),
            array('name' => 'Total News','value' => $newsCount,'link' => route('admin.news.index')),
        );

        return view('admin.homepage', compact('actionData'));
    }
}
