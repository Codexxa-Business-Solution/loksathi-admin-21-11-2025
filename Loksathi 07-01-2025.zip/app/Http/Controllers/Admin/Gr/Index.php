<?php

namespace App\Http\Controllers\Admin\Gr;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\Gr;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $grs = Gr::orderBy('created_at', 'desc')
            ->get();

        return view('admin.grs.index', compact('grs'));
    }
}
