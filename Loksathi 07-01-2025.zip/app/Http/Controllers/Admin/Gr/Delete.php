<?php

namespace App\Http\Controllers\Admin\Gr;

use App\Http\Controllers\Controller;
use App\Models\Gr;
use App\Models\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $gr = Gr::find($id);

        if (!$gr)
            abort(404);

        // delete
        $gr->delete();

        // flash and redirect
        Session::flash('success', 'Gr has been deleted successfully.');
        return redirect()->route('admin.grs.index');
    }
}
