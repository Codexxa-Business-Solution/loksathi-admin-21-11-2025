<?php

namespace App\Http\Controllers\Admin\Gr;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Gr\StoreGrRequest;
use App\Models\Gr;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreGrRequest $request): RedirectResponse
    {

        // store group
        $gr = new Gr();
        $gr->result = $request->get('result');
        $gr->sector_name = $request->get('sector_name');
        $gr->number = $request->get('number');
        $gr->language_id = $request->get('language');

        if ($request->get('is_featured') == "on") {
            $gr->is_featured = true;
        } else {
            $gr->is_featured = false;
        }

        $gr->dated_at = Carbon::parse($request->get('dated_at', Carbon::now()));

        // store file
        $file = $request->file('file_path');
        $name = md5($file . microtime()) . '.' . $file->extension();
        $file->move(public_path(AppConstants::MESSAGE_DIR_NAME), $name);
        $gr->file_path = AppConstants::MESSAGE_DIR_NAME . '/' . $name;

        // store
        $gr->save();

        // flash message
        Session::flash('success', 'Gr has been added successfully.');

        return redirect()->route('admin.grs.index');

    }
}
