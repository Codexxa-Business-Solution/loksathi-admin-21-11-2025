<?php

namespace App\Http\Controllers\Admin\Gr;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\Gr;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $gr = Gr::find($id);

        // check group exists
        if (!$gr) {
            abort(404);
        }

        // return view
        return view('admin.grs.edit', compact('gr'));

    }
}
