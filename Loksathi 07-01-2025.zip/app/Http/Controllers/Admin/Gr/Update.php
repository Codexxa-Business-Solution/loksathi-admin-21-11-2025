<?php

namespace App\Http\Controllers\Admin\Gr;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Gr\UpdateGrRequest;
use App\Models\Gr;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateGrRequest $request, $id)
    {
        // store group
        $gr = Gr::find($id);

        if (!$gr)
            abort(404);

        $gr->result = $request->get('result', $gr->result);
        $gr->sector_name = $request->get('sector_name', $gr->sector_name);
        $gr->number = $request->get('number', $gr->number);
        $gr->language_id = $request->get('language', $gr->language_id);

        if ($request->get('is_featured') == "on") {
            $gr->is_featured = true;
        } else {
            $gr->is_featured = false;
        }

        if ($request->get('dated_at')) {
            $gr->dated_at = Carbon::parse($request->get('dated_at'));
        }

        // image
        if ($request->has('file_path')) {
            $file = $request->file('file_path');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(public_path(AppConstants::MESSAGE_DIR_NAME), $name);
            $gr->file_path = AppConstants::MESSAGE_DIR_NAME . '/' . $name;
        }

        // store
        $gr->save();

        // flash message
        Session::flash('success', 'Gr has been updated successfully.');

        return redirect()->route('admin.grs.index');
    }
}
