<?php

namespace App\Http\Controllers\Admin\Bot;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Bot\UpdateBotRequest;
use App\Models\Bot;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateBotRequest $request, $id)
    {
        // store group
        $bot = Bot::find($id);

        if (!$bot)
            abort(404);

        $bot->name = $request->get('name', $bot->name);
        $bot->sub_title = $request->get('title', $bot->sub_title);
        $bot->description = $request->get('description', $bot->description);
        $bot->start_message = $request->get('start_message', $bot->start_message);
        $bot->index = $request->get('index', $bot->indec);
        $bot->language_id = $request->get('language', $bot->language_id);

        if ($request->get('is_featured') == "on") {
            $bot->is_featured = true;
        } else {
            $bot->is_featured = false;
        }

        if ($request->get('is_premium') == "on") {
            $bot->is_premium = true;
        } else {
            $bot->is_premium = false;
        }

        // image
        if ($request->has('image')) {
            // store file
            $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::BOT_DIR_NAME, $bot->image);
            $bot->image = $name;
        }

        // store
        $bot->save();

        // flash message
        Session::flash('success', 'Bot has been updated successfully.');

        return redirect()->route('admin.bots.index');
    }
}
