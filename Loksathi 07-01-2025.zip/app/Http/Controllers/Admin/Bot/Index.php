<?php

namespace App\Http\Controllers\Admin\Bot;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $bots = Bot::orderBy('created_at', 'desc')
            ->get();

        return view('admin.bot.index', compact('bots'));
    }
}
