<?php

namespace App\Http\Controllers\Admin\Bot;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use App\Models\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $group = Bot::find($id);

        if (!$group)
            abort(404);

        // delete
        $group->delete();

        // flash and redirect
        Session::flash('success', 'Bot has been deleted successfully.');
        return redirect()->route('admin.bots.index');
    }
}
