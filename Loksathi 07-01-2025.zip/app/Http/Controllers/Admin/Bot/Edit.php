<?php

namespace App\Http\Controllers\Admin\Bot;

use App\Http\Controllers\Controller;
use App\Models\Bot;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $bot = Bot::find($id);

        // check group exists
        if (!$bot) {
            abort(404);
        }

        // return view
        return view('admin.bot.edit', compact('bot'));

    }
}
