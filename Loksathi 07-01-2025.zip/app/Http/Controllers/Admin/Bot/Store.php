<?php

namespace App\Http\Controllers\Admin\Bot;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Bot\StoreBotRequest;
use App\Models\Bot;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreBotRequest $request): RedirectResponse
    {

        // store group
        $bot = new Bot();
        $bot->name = $request->get('name');
        $bot->sub_title = $request->get('title');
        $bot->description = $request->get('description');
        $bot->start_message = $request->get('start_message');
        $bot->index = $request->get('index');
        $bot->language_id = $request->get('language');

        if ($request->get('is_featured') == "on") {
            $bot->is_featured = true;
        } else {
            $bot->is_featured = false;
        }

        if ($request->get('is_premium') == "on") {
            $bot->is_premium = true;
        } else {
            $bot->is_premium = false;
        }

        // store file
        $bunnyCdnStorage = new BunnyCdnStorage();
        $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::BOT_DIR_NAME);
        $bot->image = $name;

        // store
        $bot->save();

        // flash message
        Session::flash('success', 'Bot has been added successfully.');

        return redirect()->route('admin.bots.index');

    }
}
