<?php

namespace App\Http\Controllers\Admin\UserSubscription;

use App\Http\Controllers\Controller;
use App\Models\Subscription;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        return view('admin.subscriptions.create');
    }
}
