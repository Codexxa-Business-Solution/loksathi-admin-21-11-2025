<?php

namespace App\Http\Controllers\Admin\UserSubscription;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Subscription\StoreSubscriptionRequest;
use App\Models\Subscription;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreSubscriptionRequest $request)
    {

        $group = new Subscription();
        $group->name = $request->get('name');
        $group->amount = $request->get('amount');
        $group->days = $request->get('days');
        $group->features = implode(',', $request->features);
        $group->note = $request->get('note');
        $group->status = $request->has('status') ? 1 : 0;
        $group->save();

        Session::flash('success', 'Subscription has been added successfully.');

        return redirect()->route('admin.subscriptions.index');
    }
}
