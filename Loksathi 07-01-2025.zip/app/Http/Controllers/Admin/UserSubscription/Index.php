<?php

namespace App\Http\Controllers\Admin\UserSubscription;

use App\Http\Controllers\Controller;
use App\Models\PlanPurchase;
use Illuminate\Http\Request;
use App\Enums\PaymentStatus;


class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $Subscription = PlanPurchase::leftJoin('users', 'plan_purchases.user_id', '=', 'users.id')
            ->leftJoin('agents', 'plan_purchases.agent_id', '=', 'agents.id')
            ->leftJoin('subscriptions', 'plan_purchases.subscription_id', '=', 'subscriptions.id')
            ->select(
                'plan_purchases.id as plan_purchase_id', 
                'plan_purchases.user_id', 
                'plan_purchases.agent_id', 
                'plan_purchases.subscription_id', 
                'plan_purchases.plan_price',
                'plan_purchases.plan_days', 
                'plan_purchases.expired_at', 
                'plan_purchases.created_at as plan_purchase_created_at', 
                'plan_purchases.updated_at as plan_purchase_updated_at', 
                'agents.id as agent_id', 
                'agents.agent_code', 
                'agents.name as agent_name', 
                'subscriptions.id as subscription_id',
                'subscriptions.name as subscription_name', 
                'users.id as user_id', 
                'users.name as user_name', 
                'users.email', 
                'users.created_at as user_created_at' 
            )
            ->where('plan_purchases.status',PaymentStatus::STATUS_PAID)
            ->get();

        return view('admin.users_subscriptions.index', compact('Subscription'));

    }
}

