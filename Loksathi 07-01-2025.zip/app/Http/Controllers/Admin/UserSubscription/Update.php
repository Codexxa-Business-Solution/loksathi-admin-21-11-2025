<?php

namespace App\Http\Controllers\Admin\UserSubscription;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Subscription\UpdateSubscriptionRequest;
use App\Models\Subscription;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateSubscriptionRequest $request, $id): RedirectResponse
    {

        $group = Subscription::find($id);
        $group->name = $request->get('name');
        $group->amount = $request->get('amount');
        $group->days = $request->get('days');
        $group->features = implode(',', $request->features);
        $group->note = $request->get('note');
        $group->status = $request->input('status', 0);
        $group->save();

        // flash message
        Session::flash('success', 'Subscription has been added successfully.');

        return redirect()->route('admin.subscriptions.index');
    }
}
