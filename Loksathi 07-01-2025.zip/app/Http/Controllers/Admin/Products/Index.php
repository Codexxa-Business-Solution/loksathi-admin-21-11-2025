<?php

namespace App\Http\Controllers\Admin\Products;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $products = Product::query()
            ->with('category')
            ->get();
        return view('admin.products.index', compact('products'));
    }
}
