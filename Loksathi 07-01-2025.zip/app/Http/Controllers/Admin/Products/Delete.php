<?php

namespace App\Http\Controllers\Admin\Products;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $product = Product::find($id);

        if (!$product)
            abort(404);

        // delete
        $product->delete();

        // flash and redirect
        Session::flash('success', 'Product has been deleted successfully.');
        return redirect()->route('admin.products.index');
    }

}
