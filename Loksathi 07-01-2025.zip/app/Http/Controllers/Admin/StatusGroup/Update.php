<?php

namespace App\Http\Controllers\Admin\StatusGroup;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StatusGroup\UpdateStatusGroupRequest;
use App\Models\StatusGroup;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateStatusGroupRequest $request, $id): RedirectResponse
    {

        // store group
        $group = StatusGroup::find($id);
        $group->name = $request->get('name', $group->name);
        $group->description = $request->get('description', $group->description);
        $group->index = $request->get('index', $group->index);
        $group->language_id = $request->get('language', $group->language);

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::STATUS_DIR_NAME, $group->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::STATUS_DIR_NAME, $name);
            $group->image = AppConstants::STATUS_DIR_NAME . $name;
        }

        if ($request->get('is_premium') == "on") {
            $group->is_premium = true;
        } else {
            $group->is_premium = false;
        }

        // store
        $group->save();

        // flash message
        Session::flash('success', 'Status group has been added successfully.');

        return redirect()->route('admin.status_groups.index');
    }
}
