<?php

namespace App\Http\Controllers\Admin\StatusGroup;

use App\Http\Controllers\Controller;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        // find group
        $group = StatusGroup::find($id);

        // check group exists
        if (!$group) {
            abort(404);
        }

        // return view
        return view('admin.status_groups.edit', compact('group'));

    }
}
