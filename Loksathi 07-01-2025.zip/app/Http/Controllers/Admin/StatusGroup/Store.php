<?php

namespace App\Http\Controllers\Admin\StatusGroup;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StatusGroup\StoreStatusGroupRequest;
use App\Models\StatusGroup;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreStatusGroupRequest $request)
    {

        // store group
        $group = new StatusGroup();
        $group->name = $request->get('name');
        $group->description = $request->get('description');
        $group->index = $request->get('index');
        $group->language_id = $request->get('language');

        // image
        /* $bunnyCdnStorage = new BunnyCdnStorage();
        $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::STATUS_DIR_NAME); */
        $file = $request->file('image');
        $name = md5($file . microtime()) . '.' . $file->extension();
        $file->move(AppConstants::PODCAST_DIR_NAME, $name);

        $group->image = AppConstants::PODCAST_DIR_NAME . $name;

        if ($request->get('is_premium') == "on") {
            $group->is_premium = true;
        } else {
            $group->is_premium = false;
        }

        // store
        $group->save();

        // flash message
        Session::flash('success', 'Status group has been added successfully.');

        return redirect()->route('admin.status_groups.index');
    }
}
