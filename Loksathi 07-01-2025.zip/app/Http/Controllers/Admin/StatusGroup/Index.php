<?php

namespace App\Http\Controllers\Admin\StatusGroup;

use App\Http\Controllers\Controller;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $statusGroups = StatusGroup::all();
        return view('admin.status_groups.index', compact('statusGroups'));

    }
}
