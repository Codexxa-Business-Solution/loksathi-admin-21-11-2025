<?php

namespace App\Http\Controllers\Admin\StatusGroup;

use App\Http\Controllers\Controller;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        return view('admin.status_groups.create');
    }
}
