<?php

namespace App\Http\Controllers\Admin\StatusGroup;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\StatusGroup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $statusGroup = StatusGroup::find($id);

        $type = 'success';
        $message = 'Status group has been deleted successfully.';

        if (!$statusGroup)
            abort(404);

        // delete
        try {
            $statusGroup->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'Status group cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.status_groups.index');
    }
}
