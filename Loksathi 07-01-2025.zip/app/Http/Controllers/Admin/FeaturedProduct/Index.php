<?php

namespace App\Http\Controllers\Admin\FeaturedProduct;

use App\Http\Controllers\Controller;
use App\Models\FeaturedProduct;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $featuredProducts = FeaturedProduct::with('product', 'category')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('admin.featured_products.index', compact('featuredProducts'));
    }
}
