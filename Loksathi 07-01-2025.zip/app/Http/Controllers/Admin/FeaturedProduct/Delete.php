<?php

namespace App\Http\Controllers\Admin\FeaturedProduct;

use App\Http\Controllers\Controller;
use App\Models\FeaturedProduct;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{

    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $group = FeaturedProduct::find($id);

        if (!$group)
            abort(404);

        // delete
        $group->delete();

        // flash and redirect
        Session::flash('success', 'Featured product has been deleted successfully.');
        return redirect()->route('admin.featured_products.index');


    }
}
