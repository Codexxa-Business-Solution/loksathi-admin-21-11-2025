<?php

namespace App\Http\Controllers\Admin\Language;

use App\Http\Controllers\Controller;
use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        //
        $language = Language::find($id);

        $type = 'success';
        $message = 'Language has been deleted successfully.';

        if (!$language)
            abort(404);

        // delete
        try {
            $language->delete();
        } catch (\Throwable $th) {
            $type = 'error';
            $message = 'Language cannot be deleted';
        }


        // flash and redirect
        Session::flash($type, $message);
        return redirect()->route('admin.languages.index');

    }
}
