<?php

namespace App\Http\Controllers\Admin\Language;

use App\Http\Controllers\Controller;
use App\Models\Language;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {

        // find group
        $language = Language::find($id);

        // check group exists
        if (!$language) {
            abort(404);
        }

        // return view
        return view('admin.languages.edit', compact('language'));

    }
}
