<?php

namespace App\Http\Controllers\Admin\Language;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Language\StoreLanguageRequest;
use App\Models\Language;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreLanguageRequest $request)
    {

        // store group
        $language = new Language();
        $language->name = $request->get('name');
        $language->short_name = $request->get('short_name');

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::LANGUAGE_DIR_NAME); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::LANGUAGE_DIR_NAME, $name);
            $language->image = AppConstants::LANGUAGE_DIR_NAME . $name;
        }

        // store
        $language->save();

        // flash message
        Session::flash('success', 'Language has been added successfully.');

        return redirect()->route('admin.languages.index');
    }
}
