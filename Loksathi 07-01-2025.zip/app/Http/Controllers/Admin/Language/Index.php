<?php

namespace App\Http\Controllers\Admin\Language;

use App\Http\Controllers\Controller;
use App\Models\Language;
use App\Models\StatusGroup;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $languages = Language::all();
        return view('admin.languages.index', compact('languages'));

    }
}
