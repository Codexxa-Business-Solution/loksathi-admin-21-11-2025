<?php

namespace App\Http\Controllers\Admin\Language;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StatusGroup\UpdateStatusGroupRequest;
use App\Models\Language;
use App\Services\BunnyCdnStorage;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateStatusGroupRequest $request, $id)
    {

        // store group
        $group = Language::find($id);
        $group->name = $request->get('name', $group->name);
        $group->short_name = $request->get('name', $group->short_name);

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::LANGUAGE_DIR_NAME, $group->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::LANGUAGE_DIR_NAME, $name);
            $group->image = AppConstants::LANGUAGE_DIR_NAME . $name;
        }

        // store
        $group->save();

        // flash message
        Session::flash('success', 'Language has been updated successfully.');

        return redirect()->route('admin.languages.index');


    }
}
