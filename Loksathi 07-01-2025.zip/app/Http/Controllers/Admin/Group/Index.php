<?php

namespace App\Http\Controllers\Admin\Group;

use App\Http\Controllers\Controller;
use App\Models\Group;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $type = $request->get('type');
        $categoryId = $request->get('category_id');
        $languageId = $request->get('language_id');

        $groupQuery = Group::query();

        // type
        if ($type)
            $groupQuery->where('type', $type);

        // category
        if ($categoryId)
            $groupQuery->where('group_category_id', $categoryId);

        // language
        if ($languageId)
            $groupQuery->where('language_id', $languageId);

        // groups
        $groups = $groupQuery->orderByDesc('created_at')
            ->get();

        return view('admin.groups.index', compact('groups'));
    }

}
