<?php

namespace App\Http\Controllers\Admin\Group;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Group\StoreGroupRequest;
use App\Models\Group;
use App\Models\GroupCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(StoreGroupRequest $request): RedirectResponse
    {

        // store group
        $group = new Group();
        $group->name = $request->get('name');
        $group->description = $request->get('description');
        $group->type = $request->get('type');
        $group->group_category_id = $request->get('group_category_id');
        $group->sub_title = $request->get('sub_title');
        $group->index = $request->get('index');
        $group->language_id = GroupCategory::find($request->get('group_category_id'))->language_id;

        if ($request->get('is_published') == "on") {
            $group->is_published = true;
        } else {
            $group->is_published = false;
        }

        if ($request->get('is_admin') == "on") {
            $group->is_admin = true;
        } else {
            $group->is_admin = false;
        }

        if ($request->get('is_featured') == "on") {
            $group->is_featured = true;
        } else {
            $group->is_featured = false;
        }

        if ($request->get('is_premium') == "on") {
            $group->is_premium = true;
        } else {
            $group->is_premium = false;
        }

        // image
        /* $bunnyCdnStorage = new BunnyCdnStorage();
        $name = $bunnyCdnStorage->upload($request->file('image'), AppConstants::GROUP_DIR_NAME); */
        $file = $request->file('image');
        $name = md5($file . microtime()) . '.' . $file->extension();
        $file->move(AppConstants::GROUP_DIR_NAME, $name);
        $group->image = AppConstants::GROUP_DIR_NAME . $name;

        // store
        $group->save();

        // flash message
        Session::flash('success', 'Group has been added successfully.');

        return redirect()->route('admin.groups.index');
    }
}
