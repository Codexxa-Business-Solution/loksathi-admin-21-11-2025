<?php

namespace App\Http\Controllers\Admin\Group;

use App\Enums\AppConstants;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Group\UpdateGroupRequest;
use App\Models\Group;
use App\Models\GroupCategory;
use App\Services\BunnyCdnStorage;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Update extends Controller
{
    //
    public function __invoke(UpdateGroupRequest $request, $id): RedirectResponse
    {

        // store group
        $group = Group::find($id);

        if (!$group)
            abort(404);

        $group->name = $request->get('name', $group->name);
        $group->description = $request->get('description', $group->description);
        $group->type = $request->get('type', $group->type);
        $group->index = $request->get('index', $group->indec);
        $group->sub_title = $request->get('sub_title', $group->sub_title);
        $group->group_category_id = $request->get('group_category_id', $group->group_category_id);
        $group->language_id = GroupCategory::find($request->get('group_category_id'))->language_id;


        if ($request->get('is_published') == "on") {
            $group->is_published = true;
        } else {
            $group->is_published = false;
        }

        if ($request->get('is_admin') == "on") {
            $group->is_admin = true;
        } else {
            $group->is_admin = false;
        }

        if ($request->get('is_featured') == "on") {
            $group->is_featured = true;
        } else {
            $group->is_featured = false;
        }

        if ($request->get('is_premium') == "on") {
            $group->is_premium = true;
        } else {
            $group->is_premium = false;
        }

        // image
        if ($request->has('image')) {
            /* $bunnyCdnStorage = new BunnyCdnStorage();
            $name = $bunnyCdnStorage->removeUpload($request->file('image'), AppConstants::EXTRA_DIR_NAME, $group->image); */
            $file = $request->file('image');
            $name = md5($file . microtime()) . '.' . $file->extension();
            $file->move(AppConstants::EXTRA_DIR_NAME, $name);
            $group->image = AppConstants::EXTRA_DIR_NAME . $name;
        }

        // store
        $group->save();

        // flash message
        Session::flash('success', 'Group has been updated successfully.');

        return redirect()->route('admin.groups.index');

    }
}
