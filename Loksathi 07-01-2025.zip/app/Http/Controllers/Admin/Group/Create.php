<?php

namespace App\Http\Controllers\Admin\Group;

use App\Http\Controllers\Controller;
use App\Models\GroupCategory;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
    public function __invoke(Request $request)
    {
        $groupCategories = GroupCategory::all();
        return view('admin.groups.create', compact('groupCategories'));
    }
}
