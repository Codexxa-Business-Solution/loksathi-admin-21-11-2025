<?php

namespace App\Http\Controllers\Admin\Group;

use App\Http\Controllers\Controller;
use App\Models\Group;
use App\Models\GroupCategory;
use Illuminate\Http\Request;

class Edit extends Controller
{
    //
    public function __invoke(Request $request, $id)
    {
        // find group
        $group = Group::find($id);
        $groupCategories = GroupCategory::all();

        // check group exists
        if (!$group) {
            abort(404);
        }

        // return view
        return view('admin.groups.edit', compact('group', 'groupCategories'));

    }
}
