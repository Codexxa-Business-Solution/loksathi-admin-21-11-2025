<?php

namespace App\Http\Controllers\Admin\Group;

use App\Http\Controllers\Controller;
use App\Models\Group;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $group = Group::find($id);

        if (!$group)
            abort(404);

        // delete
        $group->delete();

        // flash and redirect
        Session::flash('success', 'Group has been deleted successfully.');
        return redirect()->route('admin.groups.index');
    }
}
