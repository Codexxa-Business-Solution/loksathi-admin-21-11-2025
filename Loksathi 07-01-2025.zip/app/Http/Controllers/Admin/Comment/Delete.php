<?php

namespace App\Http\Controllers\Admin\Comment;

use App\Http\Controllers\Controller;
use App\Models\GroupComment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    //
    public function __invoke(Request $request, $id): RedirectResponse
    {

        //
        $comment = GroupComment::find($id);

        if (!$comment)
            abort(404);

        // delete
        $comment->delete();

        // flash and redirect
        Session::flash('success', 'Comment been deleted successfully.');
        return redirect()->route('admin.comments.index');
    }
}
