<?php

namespace App\Http\Controllers\Admin\Comment;

use App\Http\Controllers\Controller;
use App\Models\GroupComment;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {

        $commentQuery = GroupComment::query();

        // groups
        $comments = $commentQuery->orderByDesc('created_at')
            ->get();

        return view('admin.comments.index', compact('comments'));
    }

}
