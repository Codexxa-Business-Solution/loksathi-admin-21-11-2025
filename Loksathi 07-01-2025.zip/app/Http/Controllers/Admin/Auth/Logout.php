<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Logout extends Controller
{
    //
    public function __invoke(Request $request)
    {
        //
        Auth::logout();

        //
        return redirect()->route('admin.login');

    }
}
