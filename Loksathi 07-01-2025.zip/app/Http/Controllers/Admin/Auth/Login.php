<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Enums\UserRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Auth\LoginRequest;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class Login extends Controller
{
    //
    public function __invoke(LoginRequest $request): RedirectResponse
    {
        // check user
        $user = User::where('email', $request->get('email'))->first();
        if (!$user) {
            Session::flash('error', 'User does\'t exist in database.');
            return redirect()->back();
        }

        // check password
        if (bcrypt($request->get('password')) == $user->password) {
            Session::flash('error', 'Credential does\'t match.');
            return redirect()->back();
        }

        // check admin
        if ($user->role != UserRole::ROLE_ADMIN) {
            Session::flash('error', 'User does\'t exist in database.');
            return redirect()->back();
        }

        // login and redirect
        Auth::login($user, $request->get('remember'));
        return redirect()->route('admin.homepage');

    }
}
