<?php

namespace App\Http\Controllers\Admin\Live;

use App\Http\Controllers\Controller;
use App\Models\LiveVideo;
use Illuminate\Http\Request;

class Index extends Controller
{
    //
    public function __invoke(Request $request)
    {
        //
        $liveVideo = LiveVideo::first();
        return view('admin.live.create', compact('liveVideo'));
    }
}
