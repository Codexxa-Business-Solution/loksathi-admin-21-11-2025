<?php

namespace App\Http\Controllers\Admin\Live;

use App\Http\Controllers\Controller;
use App\Models\LiveVideo;
use App\Services\PushService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class Store extends Controller
{
    //
    public function __invoke(Request $request): RedirectResponse
    {
        //
        $liveVideo = LiveVideo::first();
        if (!$liveVideo) {
            $liveVideo = new LiveVideo();
        }
        $liveVideo->youtube_id = $request->youtube_id;
        $liveVideo->name = $request->name;
        $liveVideo->save();

        // send push notification
        if ($request->get('is_notified') == "on") {
            PushService::sendLiveNotification($liveVideo);
        }

        Session::flash('success', 'Live video has been updated successfully.');
        return redirect()->route('admin.live.index');

    }
}
