<?php

namespace App\Http\Controllers\Admin\Tag;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTagRequest;
use App\Models\Tag;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class Store extends Controller
{
    public function __invoke(StoreTagRequest $request): RedirectResponse
    {
        // Store tag
        $tag = new Tag();
        $tag->name = $request->get('name');
        $tag->slug = Str::slug($request->get('name'));
        $tag->save();

        Session::flash('success', 'Tag has been added successfully.');
        return redirect()->route('admin.job_tags.index');
    }
}