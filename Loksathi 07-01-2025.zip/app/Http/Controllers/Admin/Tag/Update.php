<?php

namespace App\Http\Controllers\Admin\Tag;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateTagRequest;
use App\Models\Tag;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class Update extends Controller
{
    public function __invoke(UpdateTagRequest $request, $id): RedirectResponse
    {
        // Find tag
        $tag = Tag::findOrFail($id);

        // Update tag
        $tag->name = $request->get('name');
        $tag->slug = Str::slug($request->get('name'));
        $tag->save();

        Session::flash('success', 'Tag has been updated successfully.');
        return redirect()->route('admin.job_tags.index');
    }
}