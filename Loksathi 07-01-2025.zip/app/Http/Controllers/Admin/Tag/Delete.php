<?php

namespace App\Http\Controllers\Admin\Tag;

use App\Http\Controllers\Controller;
use App\Models\Tag;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Session;

class Delete extends Controller
{
    public function __invoke($id): RedirectResponse
    {
        // Find tag
        $tag = Tag::findOrFail($id);

        // Delete tag
        $tag->delete();

        Session::flash('success', 'Tag has been deleted successfully.');
        return redirect()->route('admin.tags.index');
    }
}