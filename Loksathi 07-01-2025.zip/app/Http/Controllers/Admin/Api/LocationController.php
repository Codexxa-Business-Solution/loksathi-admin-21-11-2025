<?php

namespace App\Http\Controllers\Admin\Api;

use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\Taluka;
use App\Models\ExtraCategory;
use Illuminate\Http\Request;

class LocationController extends Controller
{
    public function getDistricts($stateId)
    {
        $districts = District::where('state_id', $stateId)
            ->select('id', 'name_en', 'name_mr')
            ->get();
            
        return response()->json($districts);
    }
    
    public function getTalukas($districtId)
    {
        $talukas = Taluka::where('district_id', $districtId)
            ->select('id', 'name_en', 'name_mr')
            ->get();
            
        return response()->json($talukas);
    }
    
    public function getCategories($type)
    {
        $categories = ExtraCategory::where('type', $type)
            ->where('is_published', true)
            ->select('id', 'name', 'description')
            ->get();
            
        return response()->json($categories);
    }
}