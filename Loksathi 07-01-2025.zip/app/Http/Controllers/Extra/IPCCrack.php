<?php

namespace App\Http\Controllers\Extra;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class IPCCrack extends Controller
{
    //
    public function __invoke(Request $request): JsonResponse
    {
        //
        $id = $request->get('id');
        $serial = $request->get('serial');

        if ($id === "dignity" && $serial === "dignity") {
            return response()->json([
                'name' => 'Z3r0CoO!',
                'status' => 0,
                'message' => "LOL. Logged in successfully.",
            ]);
        } else {
            return response()->json([
                'status' => 1,
                'message' => "LOL. Invalid username and password combination",
            ]);
        }

    }
}
