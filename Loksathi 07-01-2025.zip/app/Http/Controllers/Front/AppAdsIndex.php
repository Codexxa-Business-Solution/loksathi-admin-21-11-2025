<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Api\BaseApiController;
use Barryvdh\Debugbar\Facades\Debugbar;
use Illuminate\Http\Request;

class AppAdsIndex extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {
        // disable debug bar
        Debugbar::disable();
        return view('front.app_ads');
    }

}
