<?php

namespace App\Http\Controllers\Home;

use App\Http\Controllers\Api\BaseApiController;
use Barryvdh\Debugbar\Facades\Debugbar;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class Index extends BaseApiController
{
    //
    public function __invoke(Request $request)
    {
        // disable debug bar
        Debugbar::disable();
        return view('front.welcome');
    }

}
