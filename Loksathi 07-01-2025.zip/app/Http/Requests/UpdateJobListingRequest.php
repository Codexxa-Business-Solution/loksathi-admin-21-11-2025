<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateJobListingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title.en' => 'nullable|string|max:255',
            'title.hi' => 'nullable|string|max:255',
            'title.mr' => 'nullable|string|max:255',
            'description.en' => 'nullable|string',
            'description.hi' => 'nullable|string',
            'description.mr' => 'nullable|string',
            
                        
            'job_contact_person.en' => 'nullable|string',
            'job_contact_person.hi' => 'nullable|string',
            'job_contact_person.mr' => 'nullable|string',
            
            'job_address.en' => 'nullable|string',
            'job_address.hi' => 'nullable|string',
            'job_address.mr' => 'nullable|string',
            
            
            'location' => 'required|string|max:255',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'salary' => 'nullable|string|max:255',
            'experience' => 'nullable|string|max:255',
            'job_type' => 'nullable|in:fulltime,remote,parttime',
            'position' => 'nullable|string|max:255',
            'contact_number' => 'nullable|string|max:20',
            'contact_name' => 'nullable|string|max:255',
            'expiry_date' => 'required|date',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ];
    }
}
