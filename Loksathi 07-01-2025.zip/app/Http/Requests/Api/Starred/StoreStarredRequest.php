<?php

namespace App\Http\Requests\Api\Starred;

use App\Http\Requests\Api\BaseApiRequest;

class StoreStarredRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'save_type' => 'required',
            'save_id' => 'required',
        ];
    }
}
