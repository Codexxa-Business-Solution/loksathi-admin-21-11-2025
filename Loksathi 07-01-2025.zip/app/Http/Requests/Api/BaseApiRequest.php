<?php

namespace App\Http\Requests\Api;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Symfony\Component\HttpFoundation\Response;

abstract class BaseApiRequest extends FormRequest
{
    //
    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json(
                [
                    'status' => 'failed',
                    'message' => $validator->errors()->first(),
                    'data' => null,
                    'error' => $validator->errors()->first()
                ], Response::HTTP_OK
            ));
    }

    protected function failedAuthorization()
    {
        throw new HttpResponseException(
            response()->json(
                [
                    'status' => 'failed',
                    'message' => 'You are not authorized to perform this action.',
                    'data' => null,
                    'error' => 'You are not authorized to perform this action.'
                ], Response::HTTP_OK
            ));
    }

}
