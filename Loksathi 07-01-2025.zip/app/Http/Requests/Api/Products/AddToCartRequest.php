<?php

namespace App\Http\Requests\Api\Products;

use App\Http\Requests\Api\BaseApiRequest;

class AddToCartRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'product_id' => 'required',
            'variant_id' => 'required',
            'quantity' => 'required',
        ];
    }
}
