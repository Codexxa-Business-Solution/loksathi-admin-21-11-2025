<?php

namespace App\Http\Requests\Api\Products;

use App\Http\Requests\Api\BaseApiRequest;

class StoreAddressRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'name' => 'required',
            'mobile_number' => 'required',
            'line_one' => 'required',
            'line_two' => 'required',
            'pincode' => 'required',
            'state' => 'required',
            'city' => 'required',
        ];
    }
}
