<?php

namespace App\Http\Requests\Api\Profile;

use App\Http\Requests\Api\BaseApiRequest;

class UpdateLocationRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //'state_id' => 'required|exists:states,id',
            //'district_id' => 'required|exists:districts,id',
            //'taluka_id' => 'required|exists:talukas,id',
            'address' => 'required|string|max:255',
        ];
    }
}
