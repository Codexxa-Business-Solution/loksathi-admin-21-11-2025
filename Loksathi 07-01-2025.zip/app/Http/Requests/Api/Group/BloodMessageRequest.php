<?php

namespace App\Http\Requests\Api\Group;

use App\Http\Requests\Api\BaseApiRequest;

class BloodMessageRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'group_id' => 'required',
            'patient_name' => 'required',
            'contact_number' => 'required',
            'description' => 'required',
            'address' => 'required',
            'blood_group' => 'required',
            'state_id' => 'required',
            'district_id' => 'required',
            'taluka_id' => 'required',
        ];
    }
}
