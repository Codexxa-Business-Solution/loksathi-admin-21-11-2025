<?php

namespace App\Http\Requests\Api\Group;

use App\Http\Requests\Api\BaseApiRequest;

class DiscussMessageRequest extends BaseApiRequest
{
    //
    public function authorize(): bool
    {
        return true;
    }

    //
    public function rules(): array
    {
        return [
            'group_id' => 'required',
            'description' => 'required',
        ];
    }
}
