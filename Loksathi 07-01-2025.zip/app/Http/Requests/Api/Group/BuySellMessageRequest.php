<?php

namespace App\Http\Requests\Api\Group;

use App\Http\Requests\Api\BaseApiRequest;

class BuySellMessageRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'type' => 'required',
            'category' => 'required',
            'group_id' => 'required',
            'description' => 'required',
            'address' => 'required',
            'whatsapp_number' => 'required',
        ];
    }
}
