<?php

namespace App\Http\Requests\Api\Group;

use App\Http\Requests\Api\BaseApiRequest;
use Illuminate\Foundation\Http\FormRequest;

class SubmitMessageRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'group_id' => 'required',
            'title' => 'required',
            'name' => 'required',
            'message' => 'required',
            'images' => 'required',
        ];
    }
}
