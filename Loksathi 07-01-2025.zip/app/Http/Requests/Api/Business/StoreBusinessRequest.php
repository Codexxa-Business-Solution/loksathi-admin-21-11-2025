<?php

namespace App\Http\Requests\Api\Business;

use App\Http\Requests\Api\BaseApiRequest;

class StoreBusinessRequest extends BaseApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'type' => 'required|in:business,service,social',
            // 'category' => 'required|exists:extra_categories,id',
            'name.en' => 'nullable|string|max:255',
            'name.hi' => 'nullable|string|max:255',
            'name.mr' => 'nullable|string|max:255',
            'description.en' => 'nullable|string',
            'description.hi' => 'nullable|string',
            'description.mr' => 'nullable|string',
            'owner_name' => 'required',
            // 'email' => 'required',
            'whatsapp_number' => 'required',
            'address' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'contact_number' => 'required',
            'opening_time' => 'required',
            'closing_time' => 'required',
            'closing_day' => 'required',
            'is_delivery' => 'required',
            // 'state_id' => 'required',
            // 'district_id' => 'required',
            // 'taluka_id' => 'required',
        ];
    }
}
