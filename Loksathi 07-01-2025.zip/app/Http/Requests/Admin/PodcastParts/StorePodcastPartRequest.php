<?php

namespace App\Http\Requests\Admin\PodcastParts;

use Illuminate\Foundation\Http\FormRequest;

class StorePodcastPartRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'podcast_id' => 'required',
            'name' => 'required',
            'file' => 'required',
            'index' => 'required',
        ];
    }
}
