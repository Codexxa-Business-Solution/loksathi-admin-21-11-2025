<?php

namespace App\Http\Requests\Admin\BannerAd;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBannerAdRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,svg', 'max:4084'],
            'link' => ['required', 'url'],
        ];
    }
}
