<?php

namespace App\Http\Requests\Admin\Gr;

use Illuminate\Foundation\Http\FormRequest;

class UpdateGrRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'result' => ['string'],
            'sector_name' => ['string'],
            'number' => ['string'],
            'file_path' => ['file', 'mimes:pdf', 'max:4084'],
        ];
    }
}
