<?php

namespace App\Http\Requests\Admin\Gr;

use Illuminate\Foundation\Http\FormRequest;

class StoreGrRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'result' => ['required', 'string'],
            'sector_name' => ['required', 'string'],
            'number' => ['required', 'string'],
            'dated_at' => ['required'],
            'file_path' => ['required', 'file', 'mimes:pdf', 'max:4084'],
        ];
    }
}
