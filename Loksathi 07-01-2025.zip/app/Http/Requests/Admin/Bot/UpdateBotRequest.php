<?php

namespace App\Http\Requests\Admin\Bot;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBotRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['string'],
            'title' => ['string'],
            'description' => ['string'],
            'start_message' => ['string'],
            'image' => ['image', 'mimes:jpeg,png,jpg,gif,svg', 'max:4084'],
            'index' => ['integer'],
        ];
    }
}
