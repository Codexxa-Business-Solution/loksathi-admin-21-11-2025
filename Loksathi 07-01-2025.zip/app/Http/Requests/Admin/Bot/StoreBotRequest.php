<?php

namespace App\Http\Requests\Admin\Bot;

use Illuminate\Foundation\Http\FormRequest;

class StoreBotRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', 'string'],
            'title' => ['required', 'string'],
            'description' => ['required', 'string'],
            'start_message' => ['required', 'string'],
            'image' => ['required', 'image', 'mimes:jpeg,png,jpg,gif,svg', 'max:4084'],
            'is_premium' => ['required'],
            'index' => ['required', 'integer'],
            'language' => ['required'],
        ];
    }
}
