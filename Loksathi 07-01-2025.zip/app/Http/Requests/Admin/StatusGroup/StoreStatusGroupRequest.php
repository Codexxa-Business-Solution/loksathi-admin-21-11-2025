<?php

namespace App\Http\Requests\Admin\StatusGroup;

use Illuminate\Foundation\Http\FormRequest;

class StoreStatusGroupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required', 'string'],
            'image' => ['required', 'image', 'mimes:jpeg,png,jpg,gif,svg', 'max:4084'],
            'index' => ['required', 'integer'],
            'language' => ['required'],
        ];
    }
}
