<?php

namespace App\Http\Requests\Admin\GroupMessage;

use Illuminate\Foundation\Http\FormRequest;

class StoreGroupMessageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'group_id' => 'required',
            'type' => 'required',
            'name' => 'required',
            'message' => 'required',
            'image' => 'max:2024'
        ];
    }
}
