<?php

namespace App\Http\Requests\Admin\CalenderEvent;

use Illuminate\Foundation\Http\FormRequest;

class UpdateCalenderEventRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['string'],
            'description' => ['string'],
            'index' => ['string'],
            'image' => ['file', 'mimes:jpeg,png,jpg', 'max:4084'],
        ];
    }
}
