<?php

namespace App\Http\Requests\Admin\BotMessage;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBotMessageRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'bot_id' => 'required',
            'type' => 'required',
            'name' => 'required',
            'key' => 'required',
            'message' => 'required',
        ];
    }
}
