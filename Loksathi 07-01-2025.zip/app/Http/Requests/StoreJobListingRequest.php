<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreJobListingRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'title.en' => 'nullable|string|max:255',
            'title.hi' => 'nullable|string|max:255',
            'title.mr' => 'nullable|string|max:255',
            'description.en' => 'nullable|string',
            'description.hi' => 'nullable|string',
            'description.mr' => 'nullable|string',
            
            
            'job_contact_person.en' => 'nullable|string',
            'job_contact_person.hi' => 'nullable|string',
            'job_contact_person.mr' => 'nullable|string',
            
            'job_address.en' => 'nullable|string',
            'job_address.hi' => 'nullable|string',
            'job_address.mr' => 'nullable|string',
            
            
            
            
            
            
            'location' => 'required|string|max:255',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'salary' => 'nullable|string|max:255',
            'experience' => 'nullable|string|max:255',
            'job_type' => 'nullable|in:fulltime,remote,parttime',
            'position' => 'nullable|string|max:255',
            'contact_number' => 'nullable|string|max:20',
            'contact_name' => 'nullable|string|max:255',
            'expiry_date' => 'required|date',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ];
    }
    
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $title = $this->input('title', []);  // Get title field
            $description = $this->input('description', []);
            $job_contact_person = $this->input('job_contact_person', []);
            $job_address = $this->input('job_address', []);// Get description field
    
            // Check if at least one language has a non-empty title and description
            $titleFilled = !empty($title['en']) || !empty($title['hi']) || !empty($title['mr']);
            $descriptionFilled = !empty($description['en']) || !empty($description['hi']) || !empty($description['mr']);
    
    
            $contactFilled = !empty($job_contact_person['en']) || !empty($job_contact_person['hi']) || !empty($job_contact_person['mr']);
            $addressFilled = !empty($job_address['en']) || !empty($job_address['hi']) || !empty($job_address['mr']);

    
    
    
            if (!$titleFilled || !$descriptionFilled || !$contactFilled || !$addressFilled) {
                // Add a custom error if title or description is not filled in any language
                $validator->errors()->add('title', 'At least one language for title must be provided.');
                $validator->errors()->add('description', 'At least one language for description must be provided.');
                $validator->errors()->add('job_contact_person', 'At least one language for contact person name must be provided.');
                $validator->errors()->add('job_address', 'At least one language for address must be provided.');
            }
        });
    }
}
