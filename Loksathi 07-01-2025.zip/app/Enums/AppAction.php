<?php

namespace App\Enums;

class AppAction
{
    const ACTION_NONE = "none";
    const ACTION_UPDATE = "update";
    const ACTION_LOGIN = "login";

    // types
    const TYPES = [
        self::ACTION_NONE,
        self::ACTION_UPDATE,
        self::ACTION_LOGIN
    ];

}
