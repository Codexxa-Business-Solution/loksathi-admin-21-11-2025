<?php

namespace App\Enums;

class StatusType
{
    const TYPE_IMAGE = "image";
    const TYPE_VIDEO = "video";
    const TYPE_AD = "ad";
    const TYPE_TEXT = "text";
    const TYPE_LINK = "link";
    const TYPE_PRODUCT = "product";
    const TYPE_PODCAST = "podcast";
    const TYPE_GROUP = "group";

    const TYPES = [
        self::TYPE_IMAGE,
        self::TYPE_VIDEO,
        self::TYPE_TEXT,
        self::TYPE_AD,
        self::TYPE_LINK,
        self::TYPE_PRODUCT,
        self::TYPE_PODCAST,
        self::TYPE_GROUP,
    ];

}
