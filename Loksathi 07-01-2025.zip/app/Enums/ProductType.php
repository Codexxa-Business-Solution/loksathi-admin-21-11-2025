<?php

namespace App\Enums;

class ProductType
{
    const TYPE_BOOK = "book";
    const TYPE_SHIRT = "shirt";

    const TYPES = [
        self::TYPE_BOOK,
        self::TYPE_SHIRT,
    ];

}
