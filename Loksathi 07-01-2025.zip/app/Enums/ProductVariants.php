<?php

namespace App\Enums;

class ProductVariants
{
    // sizes
    const SIZE_XS = "xs";
    const SIZE_S = "s";
    const SIZE_M = "m";
    const SIZE_L = "l";
    const SIZE_XL = "xl";
    const SIZE_2XL = "2xl";
    const SIZE_3XL = "3xl";
    const SIZES = [
        self::SIZE_XS,
        self::SIZE_S,
        self::SIZE_M,
        self::SIZE_L,
        self::SIZE_XL,
        self::SIZE_2XL,
        self::SIZE_3XL,
    ];

    // colors
    const COLOR_WHITE = "white";
    const COLOR_BLACK = "black";
    const COLOR_RED = "red";
    const COLOR_BLUE = "blue";
    const COLOR_GREEN = "green";
    const COLOR_YELLOW = "yellow";
    const COLORS = [
        self::COLOR_WHITE,
        self::COLOR_BLACK,
        self::COLOR_RED,
        self::COLOR_BLUE,
        self::COLOR_GREEN,
        self::COLOR_YELLOW,
    ];

}
