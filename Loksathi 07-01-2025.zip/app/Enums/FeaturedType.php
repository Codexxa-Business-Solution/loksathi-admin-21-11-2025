<?php

namespace App\Enums;

class FeaturedType
{
    const TYPE_ITEM = "item";
    const TYPE_CATEGORY = "category";
    const TYPE_AD = "ad";

    const TYPES = [
        self::TYPE_ITEM,
        self::TYPE_CATEGORY,
        self::TYPE_AD,
    ];
}
