<?php

namespace App\Enums;

class UserRole
{

    const ROLE_SUPER_ADMIN = "super_admin";
    const ROLE_ADMIN = "admin";
    const ROLE_STATUS_MANAGER = "status_manager";
    const ROLE_GROUP_MANAGER = "group_manager";
    const ROLE_QUIZ_MANAGER = "quiz_manager";
    const ROLE_NEWS_MANAGER = "news_manager";
    const ROLE_PRODUCT_MANAGER = "product_manager";
    const ROLE_USER = "user";

}
