<?php

namespace App\Enums;

class PaymentStatus
{

    const STATUS_CREATED = "created";
    const STATUS_PAID = "paid";

}
