<?php

namespace App\Enums;

class GroupType
{
    const TYPE_GROUP = "group";
    const TYPE_QUIZ = "quiz";
    const TYPE_AD = "ad";
    const TYPE_POEM = "poem";
    const TYPE_ARTICLE = "article";
    const TYPE_BLOOD_GROUP = "blood_group";
    const TYPE_BUY_SELL = "buy_sell";
    const TYPE_LADIES = "ladies";
    const TYPE_DISCUSS = "discuss";

    // types
    const TYPES = [
        self::TYPE_GROUP,
        self::TYPE_QUIZ,
        // self::TYPE_AD,
        self::TYPE_POEM,
        // self::TYPE_ARTICLE,
        // self::TYPE_BLOOD_GROUP,
        // self::TYPE_BUY_SELL,
        // self::TYPE_LADIES,
        // self::TYPE_DISCUSS,
    ];

}
