<?php

namespace App\Enums;

class NewsType
{
    const TYPE_MESSAGE = "message";
    const TYPE_IMAGE = "image";
    const TYPE_VIDEO = "video";
    const TYPE_AD = "ad";
    const TYPE_YOUTUBE = "yt";

    const TYPES = [
        self::TYPE_MESSAGE,
        self::TYPE_IMAGE,
        self::TYPE_AD,
        self::TYPE_VIDEO,
        self::TYPE_YOUTUBE,
    ];
}
