<?php

namespace App\Enums;

class OrderStatus
{

    const STATUS_CREATED = "created";
    const STATUS_CONFIRMED = "confirmed";
    const STATUS_DISPATCHED = "dispatched";
    const STATUS_DELIVERED = "delivered";
    const STATUS_CANCELLED = "cancelled";

    // types
    const TYPES = [
        self::STATUS_CREATED,
        self::STATUS_CONFIRMED,
        self::STATUS_DISPATCHED,
        self::STATUS_DELIVERED,
        self::STATUS_CANCELLED,
    ];

}
