<?php

namespace App\Enums;

class BotMessageType
{
    const TYPE_MESSAGE = "message";
    const TYPE_IMAGE = "image";
    const TYPE_AD = "ad";
    const TYPE_VIDEO = "video";
    const TYPE_LINK = "link";
    const TYPE_AUDIO = "audio";
    const TYPE_FILE = "file";
    const TYPE_PDF = "pdf";
    const TYPE_GIF = "gif";

    const TYPES = [
        self::TYPE_MESSAGE,
        self::TYPE_IMAGE,
        self::TYPE_AD,
        self::TYPE_VIDEO,
        self::TYPE_LINK,
        self::TYPE_AUDIO,
        self::TYPE_FILE,
        self::TYPE_PDF,
        self::TYPE_GIF,
    ];
}
