<?php

namespace App\Enums;

class GroupMessageType
{
    const TYPE_MESSAGE = "message";
    const TYPE_IMAGE = "image";
    const TYPE_AD = "ad";
    const TYPE_VIDEO = "video";
    const TYPE_LINK = "link";
    const TYPE_AUDIO = "audio";
    const TYPE_FILE = "file";
    const TYPE_PDF = "pdf";
    const TYPE_GIF = "gif";

    const TYPES = [
        self::TYPE_IMAGE,
        self::TYPE_AUDIO,
        self::TYPE_PDF,
    ];
}
