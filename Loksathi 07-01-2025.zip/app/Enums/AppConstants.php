<?php

namespace App\Enums;

class AppConstants
{

    // dirs names
    const BOT_DIR_NAME = 'bots/';
    const GROUP_DIR_NAME = 'groups/';
    const BUYSELL_DIR_NAME = 'buysell/';
    const DISCUSS_DIR_NAME = 'discuss/';
    const NEWS_DIR_NAME = 'news/';
    const QUIZ_DIR_NAME = 'quizzes/';
    const STATUS_DIR_NAME = 'statuses/';
    const MESSAGE_DIR_NAME = 'messages/';
    const PODCAST_DIR_NAME = 'podcasts/';
    const PRODUCT_DIR_NAME = 'products/';
    const LANGUAGE_DIR_NAME = 'languages/';
    const BANNER_DIR_NAME = 'banners/';
    const AD_DIR_NAME = 'ads/';
    const FEATURED_DIR_NAME = 'featured/';
    const EXTRA_DIR_NAME = 'extras/';
    const PROFILE_DIR_NAME = 'profiles/';
    const JOB_LISTINGS_DIR_NAME = 'job_listings/';
    const JOB_CATEGORIES_DIR_NAME = 'job_categories/';

}
