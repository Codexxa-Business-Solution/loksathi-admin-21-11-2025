<?php

namespace App\Enums;

class AddressType
{

    const TYPE_HOME = "home";
    const TYPE_OFFICE = "office";

    // types
    const TYPES = [
        self::TYPE_HOME,
        self::TYPE_OFFICE,
    ];

}
