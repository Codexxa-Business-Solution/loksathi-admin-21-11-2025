<?php

namespace App\Enums;

class ErrorMessage
{

}
