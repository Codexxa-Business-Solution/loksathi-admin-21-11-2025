<?php

namespace App\Console\Commands;

use Database\Seeders\UpdateJobListingsSeeder;
use Illuminate\Console\Command;

class UpdateJobListingsCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'job-listings:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update existing job listings with sample data for new fields';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Updating existing job listings with sample data...');
        
        // Run the seeder
        $seeder = new UpdateJobListingsSeeder();
        $seeder->setCommand($this);
        $seeder->run();
        
        $this->info('Job listings have been updated successfully!');
        
        return 0;
    }
}