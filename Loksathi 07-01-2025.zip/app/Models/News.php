<?php

namespace App\Models;

use App\Models\NewsComment;
use App\Models\NewsLike;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class News extends Model
{
    use HasFactory;

    public $appends = ['display_date'];

    //
    public function getDisplayDateAttribute($value): string
    {
        if ($this->scheduled_at) {
            return Carbon::parse($this->scheduled_at)->format('d/m/Y g:i A');
        } else {
            return Carbon::parse($this->created_at)->format('d/m/Y g:i A');
        }
    }

    public function comments()
    {
        return $this->hasMany(NewsComment::class)->where('is_inactive', 0);
    }

    public function likes()
    {
        return $this->hasMany(NewsLike::class);
    }

    public function user_like()
    {
        return $this->hasOne(NewsLike::class)->where('user_id', auth()->user()->id);
    }
    
    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }
}
