<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Gr extends Model
{
    use HasFactory;

    // language
    public function language(): BelongsTo
    {
        return $this->belongsTo(Language::class);
    }

    // Accessor for formatted created_at
    public function getDatedAtAttribute($value)
    {
        return \Carbon\Carbon::parse($value)->format('d/m/Y');
    }
}
