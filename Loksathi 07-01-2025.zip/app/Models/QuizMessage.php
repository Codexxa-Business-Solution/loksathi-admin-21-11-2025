<?php

namespace App\Models;

use App\Traits\Reads\Readable;
use App\Traits\Reads\ReadableInterface;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class QuizMessage extends Model implements ReadableInterface
{
    use HasFactory, Readable;

    protected $appends = ['display_time'];

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    //
    public function getDisplayTimeAttribute($value): string
    {
        if ($this->scheduled_at) {
            return Carbon::parse($this->scheduled_at)->format('d/m/Y g:i A');
        } else {
            return Carbon::parse($this->created_at)->format('d/m/Y g:i A');
        }
    }

    protected $casts = [
        "questions" => "array",
    ];

    // category
    public function category(): BelongsTo
    {
        return $this->belongsTo(QuizCategory::class, 'quiz_category_id', 'id');
    }

    // group
    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class, 'quiz_group_id', 'id');
    }


    // group
    public function answers(): HasMany
    {
        return $this->hasMany(QuizAnswer::class, 'quiz_message_id', 'id');
    }

    //
    public function question(string $name, $default = null)
    {

        if (!$this->questions) {
            $this->questions = array();
        }

        if (array_key_exists($name, $this->questions)) {
            return $this->questions[$name];
        }
        return $default;
    }

    //
    public function updateQuestion(array $revisions, bool $save = true): self
    {
        if (!$this->questions) {
            $this->questions = array();
        }

        $this->questions = array_merge($this->questions, $revisions);

        if ($save) {
            $this->save();
        }
        return $this;
    }

    // answer
    public function scopeUserAnswer(): HasMany
    {
        return $this->answers()
            ->where('user_id', auth()->user()->id);
    }

}
