<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Cart extends Model
{
    use HasFactory;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }


    protected $casts = [
        'variant' => 'array'
    ];

    // users
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // products
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

}
