<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserSave extends Model
{
    use HasFactory;

    // group message
    public function groupMessage(): BelongsTo
    {
        return $this->belongsTo(GroupMessage::class, 'save_id', 'id');
    }

    // quiz message
    public function quizMessage(): BelongsTo
    {
        return $this->belongsTo(QuizMessage::class, 'save_id', 'id');
    }

}
