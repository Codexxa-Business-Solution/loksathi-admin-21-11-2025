<?php

namespace App\Models;

use App\Traits\Reads\Readable;
use App\Traits\Reads\ReadableInterface;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Podcast extends Model implements ReadableInterface
{
    use HasFactory, Readable;

    protected $hidden = ['reads'];

    protected $casts = [
        'is_premium' => 'boolean',
    ];

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    // category
    public function category(): BelongsTo
    {
        return $this->belongsTo(PodcastCategory::class, 'podcast_category_id', 'id');
    }

    // parts
    public function parts(): HasMany
    {
        return $this->hasMany(PodcastParts::class);
    }

}
