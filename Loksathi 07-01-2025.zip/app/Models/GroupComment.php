<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GroupComment extends Model
{
    use HasFactory;

    protected $appends = ['display_time'];

    // user
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    //
    public function getDisplayTimeAttribute($value): string
    {
        return Carbon::parse($this->created_at)->format('d/m/Y g:i A');
    }


}
