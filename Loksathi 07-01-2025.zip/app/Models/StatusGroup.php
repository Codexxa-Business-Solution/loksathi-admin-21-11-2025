<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StatusGroup extends Model
{
    use HasFactory;

    // casts
    protected $casts = [
        'is_premium' => 'bool'
    ];

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    // language
    public function language(): BelongsTo
    {
        return $this->belongsTo(Language::class);
    }

    // statuses
    public function statuses(): HasMany
    {
        return $this->hasMany(Status::class);
    }

    // statuses
    public function scopeTodayStatus(): HasMany
    {
        return $this->statuses()
            ->where('scheduled_at', '>', Carbon::now()->subHours(24))
            ->where('scheduled_at', '<', Carbon::now());
    }

}
