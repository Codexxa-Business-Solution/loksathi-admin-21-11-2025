<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Status extends Model
{
    use HasFactory;

    protected $hidden = ['reads'];

    protected $appends = [
         'display_time'
    ];

    // reads
    public function reads(): HasMany
    {
        return $this->hasMany(StatusView::class);
    }

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    //
    public function getDisplayTimeAttribute($value): string
    {
        return Carbon::parse($this->scheduled_at)->format('d/m/Y g:i A');
    }

    // group
    public function group(): BelongsTo
    {
        return $this->belongsTo(StatusGroup::class, 'status_group_id', 'id');
    }

    // mark as read
    public function markAsRead(User $user)
    {
        // delete reads by user
        // $this->reads()->where('user_id', $user->id)->delete();

        // add read
        $this->reads()->insertOrIgnore([
            'user_id' => $user->id,
            'status_id' => $this->id,
        ]);
    }

    // get read attribute
//     public function getReadAttribute(): bool
//     {
//         return false;
// //        $user = auth()->user();
// //        $readCount = $this->reads()
// //            ->where('status_id', $this->id)
// //            ->where('user_id', $user->id)
// //            ->count();
// //        return $readCount > 0;
//     }

}
