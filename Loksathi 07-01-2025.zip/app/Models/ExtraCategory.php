<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ExtraCategory extends Model
{
    use HasFactory;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }


    // language
    public function language(): BelongsTo
    {
        return $this->belongsTo(Language::class);
    }

    // parent
    public function parent(): BelongsTo
    {
        return $this->belongsTo(ExtraCategory::class, 'parent_id', 'id');
    }

    // categories
    public function categories(): HasMany
    {
        return $this->hasMany(ExtraCategory::class, 'parent_id', 'id');
    }

    // products
    public function ads(): HasMany
    {
        return $this->hasMany(ExtraAd::class);
    }

}
