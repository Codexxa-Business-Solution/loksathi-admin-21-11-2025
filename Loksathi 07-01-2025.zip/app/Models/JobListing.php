<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class JobListing extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'job_category_id',
        'title',
        'image',
        'description',
        'expiry_date',
        'location',
        'latitude',
        'longitude',
        'salary',
        'experience',
        'job_type',
        'position',
        'contact_number',
        'contact_name',
        'is_published',
        'notification_title',
        'is_premium',
        'job_contact_person',
        'job_address'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'expiry_date' => 'date',
        'is_published' => 'boolean',
        'is_premium' => 'boolean',
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = ['display_date'];

    /**
     * Get the formatted display date
     *
     * @return string
     */
    public function getDisplayDateAttribute(): string
    {
        if ($this->expiry_date) {
            return Carbon::parse($this->expiry_date)->format('d/m/Y');
        } else {
            return Carbon::parse($this->created_at)->format('d/m/Y');
        }
    }

    /**
     * Get the category that owns the job listing.
     */
    public function jobCategory()
    {
        return $this->belongsTo(JobCategory::class);
    }
    
    /**
     * Get the tags for the job listing.
     */
    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class, 'job_listing_tag');
    }
    
    
      // language
    public function language(): BelongsTo
    {
        return $this->belongsTo(Language::class);
    }
    
    /**
     * Get comma-separated list of tag names
     * 
     * @return string
     */
    public function getTagListAttribute(): string
    {
        return $this->tags->pluck('name')->implode(', ');
    }
}
