<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Group extends Model
{
    use HasFactory;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    protected $casts = [
        'is_admin' => 'boolean',
        'is_premium' => 'boolean',
    ];

    public $appends = ['unread_messages_count'];

    // language
    public function language(): BelongsTo
    {
        return $this->belongsTo(Language::class);
    }

    // category
    public function category(): BelongsTo
    {
        return $this->belongsTo(GroupCategory::class, 'group_category_id', 'id');
    }

    // messages
    public function messages(): HasMany
    {
        return $this->hasMany(GroupMessage::class);
    }

    // messages
    public function getUnreadMessagesCountAttribute(): int
    {

//        return 0;

        // user
        $user = auth()->user();

        // saved count
        $groupMessageReadCount = GroupMessageReadCount::where('group_id', $this->id)
            ->where('user_id', $user->id)
            ->first();

        // check unread count
        $unreadCount = $this->group_message_count;
        if ($groupMessageReadCount) {
            $unreadCount = $unreadCount - $groupMessageReadCount->read_count;
        }

        // check is greater than 99
        if ($unreadCount > 99) {
            return 99;
        } else {
            return $unreadCount;
        }

    }

    // quiz messages
    public function quiz_messages(): HasMany
    {
        return $this->hasMany(QuizMessage::class, 'quiz_group_id', 'id');
    }

    // blood messages
    public function blood_messages(): HasMany
    {
        return $this->hasMany(BloodGroupMessage::class, 'blood_group_id', 'id');
    }

    // blood messages
    public function buy_messages(): HasMany
    {
        return $this->hasMany(BuySellMessage::class, 'buysell_group_id', 'id');
    }

    // discuss messages
    public function discuss_messages(): HasMany
    {
        return $this->hasMany(DiscussMessage::class, 'discuss_group_id', 'id');
    }

}
