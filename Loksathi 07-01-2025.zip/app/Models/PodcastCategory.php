<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PodcastCategory extends Model
{
    use HasFactory;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }


    // language
    public function language(): BelongsTo
    {
        return $this->belongsTo(Language::class);
    }

    // podcasts
    public function podcasts(): HasMany
    {
        return $this->hasMany(Podcast::class);
    }


}
