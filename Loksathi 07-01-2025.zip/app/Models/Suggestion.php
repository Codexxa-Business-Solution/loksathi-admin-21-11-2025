<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Suggestion extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username',
        'name',
        'image',
        'social_type',
        'social_link',
        'index',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'index' => 'integer',
    ];

    /**
     * Get the social type options
     */
    public static function getSocialTypeOptions(): array
    {
        return [
            'insta' => 'Instagram',
            'fb' => 'Facebook',
            'x' => 'Twitter/X',
        ];
    }

    /**
     * Get the social type label
     */
    public function getSocialTypeLabelAttribute(): string
    {
        return self::getSocialTypeOptions()[$this->social_type] ?? $this->social_type;
    }
}
