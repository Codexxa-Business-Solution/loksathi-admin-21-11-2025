<?php

namespace App\Models;

use App\Traits\Reads\Readers;
use App\Traits\Reads\ReadersInterface;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use phpDocumentor\Reflection\Types\Boolean;
use Spatie\Permission\Traits\HasRoles;

/**
 * @property ?string name
 * @property ?string image
 * @property ?string phone
 * @property ?string email
 * @property ?string password
 * @property boolean is_registered
 * @property ?string android_push_id
 * @property ?integer otp_limit
 * @property ?string api_token
 * @property ?string phone_verified_at
 * @property ?string otp_reset_time
 * @property float wallet_balance
 * @property ?string referral_code
 */
class User extends Authenticatable implements ReadersInterface
{
    use HasFactory, Notifiable, Readers, HasRoles;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    //
    public function getPlanDisplayDateAttribute(): string
    {
        try {
            return Carbon::parse($this->plan_expired_at)->format('Y-m-d');
        } catch (\Exception $exception) {
            return '';
        }
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'image',
        'referral_code',
        'referred_by',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'user_info'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'is_registered' => 'boolean',
        'is_premium' => 'boolean',
        'user_info' => 'array',
        'wallet_balance' => 'decimal:2',
    ];

    protected $appends = [
        'user_location', 'is_active', 'plan_display_date'
    ];

    public function info(string $name, $default = null)
    {

        if (!$this->user_info) {
            $this->user_info = array();
        }

        if (array_key_exists($name, $this->user_info)) {
            return $this->user_info[$name];
        }
        return $default;
    }

    //
    public function updateInfo(array $revisions, bool $save = true): self
    {

        if (!$this->user_info) {
            $this->user_info = array();
        }

        $this->user_info = array_merge($this->user_info, $revisions);
        if ($save) {
            $this->save();
        }
        return $this;
    }

    // addresses
    public function addresses(): HasMany
    {
        return $this->hasMany(Address::class);
    }

    // wallet transactions
    public function walletTransactions(): HasMany
    {
        return $this->hasMany(WalletTransaction::class);
    }

    // user location attribute
    public function getUserLocationAttribute(): array
    {
        return [
            'state' => State::find($this->info('state_id')),
            'district' => District::find($this->info('district_id')),
            'taluka' => Taluka::find($this->info('taluka_id')),
            'latitude' => $this->info('latitude'),
            'longitude' => $this->info('longitude'),
            'address' => $this->info('address'),
        ];
    }

    // user location attribute
    public function getIsActiveAttribute(): bool
    {
        return $this->is_premium && ($this->plan_expired_at > Carbon::today());
    }

    public function routeNotificationForFcm(): string
    {
        return $this->android_push_token;
    }

    /**
     * Add money to wallet
     */
    public function addToWallet(float $amount, string $transactionType, ?string $referenceId = null, ?string $description = null, ?array $metadata = null): WalletTransaction
    {
        $balanceBefore = $this->wallet_balance;
        $this->wallet_balance += $amount;
        $this->save();

        return $this->walletTransactions()->create([
            'type' => WalletTransaction::TYPE_CREDIT,
            'amount' => $amount,
            'balance_before' => $balanceBefore,
            'balance_after' => $this->wallet_balance,
            'transaction_type' => $transactionType,
            'reference_id' => $referenceId,
            'description' => $description,
            'metadata' => $metadata,
            'status' => WalletTransaction::STATUS_COMPLETED,
        ]);
    }

    /**
     * Deduct money from wallet
     */
    public function deductFromWallet(float $amount, string $transactionType, ?string $referenceId = null, ?string $description = null, ?array $metadata = null): WalletTransaction
    {
        if ($this->wallet_balance < $amount) {
            throw new \Exception('Insufficient wallet balance');
        }

        $balanceBefore = $this->wallet_balance;
        $this->wallet_balance -= $amount;
        $this->save();

        return $this->walletTransactions()->create([
            'type' => WalletTransaction::TYPE_DEBIT,
            'amount' => $amount,
            'balance_before' => $balanceBefore,
            'balance_after' => $this->wallet_balance,
            'transaction_type' => $transactionType,
            'reference_id' => $referenceId,
            'description' => $description,
            'metadata' => $metadata,
            'status' => WalletTransaction::STATUS_COMPLETED,
        ]);
    }

    /**
     * Check if user has sufficient wallet balance
     */
    public function hasSufficientBalance(float $amount): bool
    {
        return $this->wallet_balance >= $amount;
    }

    /**
     * Get formatted wallet balance
     */
    public function getFormattedWalletBalanceAttribute(): string
    {
        return '₹' . number_format($this->wallet_balance, 2);
    }

    /**
     * Generate a unique referral code for the user
     * 
     * @return string
     */
    public function generateReferralCode(): string
    {
        if ($this->referral_code) {
            return $this->referral_code;
        }
        
        // Keep generating until we find a unique code
        do {
            // Generate a 6-digit code
            $code = 'LS' . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
            // Check if code already exists
            $exists = self::where('referral_code', $code)->exists();
        } while ($exists);
        
        $this->referral_code = $code;
        $this->save();
        
        return $code;
    }
    
    public function referredBy()
    {
        return $this->belongsTo(User::class, 'referred_by'); // 'referred_by' is the foreign key
    }
}
