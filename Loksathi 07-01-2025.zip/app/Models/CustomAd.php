<?php

namespace App\Models;

use App\Traits\Reads\Readable;
use App\Traits\Reads\ReadableInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomAd extends Model implements ReadableInterface
{
    use HasFactory, Readable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'image',
        'url',
        'position',
        'positions',
        'display_order',
        'expiry_date',
        'location',
        'latitude',
        'longitude'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'positions' => 'array',
        'expiry_date' => 'date',
    ];

    /**
     * Available position options
     *
     * @var array
     */
    public static $positionOptions = [
        'home' => 'Home',
        'job_ads' => 'Job Ads',
        'business' => 'Business',
        'gr' => 'GR',
        'news' => 'News',
        // 'podcast' => 'Podcast',
        // 'status' => 'Status',
        // 'quiz' => 'Quiz',
    ];

    /**
     * Get positions for display (handles backward compatibility)
     *
     * @return array
     */
    public function getDisplayPositions()
    {
        // If new positions field exists and has data, use it
        if ($this->positions && is_array($this->positions)) {
            return $this->positions;
        }
        
        // Fall back to old position field if it exists
        if ($this->position) {
            return [$this->position];
        }
        
        return [];
    }

    /**
     * Check if the ad is expired
     *
     * @return bool
     */
    public function isExpired()
    {
        if (!$this->expiry_date) {
            return false; // No expiry date means never expires
        }
        
        return $this->expiry_date->isPast();
    }

    /**
     * Check if the ad is active (not expired)
     *
     * @return bool
     */
    public function isActive()
    {
        return !$this->isExpired();
    }

    /**
     * Scope to get only active (non-expired) ads
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where(function ($q) {
            $q->whereNull('expiry_date')
              ->orWhere('expiry_date', '>', now()->toDateString());
        });
    }

    /**
     * Scope to get expired ads
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeExpired($query)
    {
        return $query->where('expiry_date', '<=', now()->toDateString());
    }
}