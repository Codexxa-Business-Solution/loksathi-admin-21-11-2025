<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuizAnswer extends Model
{
    use HasFactory;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }


    protected $casts = [
        "answers" => "array",
        "calculations" => "array",
    ];

    //
    public function updateAnswer(array $revisions, bool $save = true): self
    {
        if (!$this->answers) {
            $this->answers = array();
        }

        $this->answers = array_merge($this->answers, $revisions);

        if ($save) {
            $this->save();
        }
        return $this;
    }

    //
    public function updateCalculation(array $revisions, bool $save = true): self
    {
        if (!$this->calculations) {
            $this->calculations = array();
        }

        $this->calculations = array_merge($this->calculations, $revisions);

        if ($save) {
            $this->save();
        }
        return $this;
    }

}
