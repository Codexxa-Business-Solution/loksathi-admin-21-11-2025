<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NewsComment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
'news_id',
'comment','is_inactive', 'is_edited'];

  // user
  public function user(): BelongsTo
  {
      return $this->belongsTo(User::class);
  }

}
