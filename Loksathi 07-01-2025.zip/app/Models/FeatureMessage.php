<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FeatureMessage extends Model
{
    use HasFactory;

    protected $guarded = [];

    // message
    public function message(): BelongsTo
    {
        return $this->belongsTo(GroupMessage::class, 'group_message_id', 'id');
    }

}
