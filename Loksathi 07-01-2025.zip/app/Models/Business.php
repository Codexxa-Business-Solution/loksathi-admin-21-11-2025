<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Business extends Model
{
    use HasFactory;

    protected $appends = [
        'is_open',
        'opening_time_display',
        'closing_time_display',
    ];

    protected $casts = [
        'is_delivery' => 'boolean',
        'is_paid' => 'boolean',
    ];

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    // close status
    public function getIsOpenAttribute(): string
    {

        // times
        $time = Carbon::now()->format('H:i:s');
        $start = Carbon::parse($this->opening_time)->format('H:i:s');
        $end = Carbon::parse($this->closing_time)->format('H:i:s');

        if ($time >= $start && $time <= $end) {
            return true;
        }

        return false;

    }

    //
    public function getOpeningTimeDisplayAttribute(): string
    {
        return Carbon::parse($this->opening_time)->format('g:i A');
    }

    //
    public function getClosingTimeDisplayAttribute(): string
    {
        return Carbon::parse($this->closing_time)->format('g:i A');
    }

    // user
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // state
    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }

    // district
    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    // taluka
    public function taluka(): BelongsTo
    {
        return $this->belongsTo(Taluka::class);
    }

    // taluka
    public function category(): BelongsTo
    {
        return $this->belongsTo(ExtraCategory::class, 'category_id', 'id');
    }

    // category
    public function categoryName(): BelongsTo
    {
        return $this->belongsTo(ExtraCategory::class, 'category_id', 'id');
    }

}
