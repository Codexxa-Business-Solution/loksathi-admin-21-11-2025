<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FeaturedPodcast extends Model
{
    use HasFactory;

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    // podcast
    public function podcast(): BelongsTo
    {
        return $this->belongsTo(Podcast::class, 'podcast_id', 'id');
    }

    // podcast categories
    public function category(): BelongsTo
    {
        return $this->belongsTo(PodcastCategory::class, 'podcast_category_id', 'id');
    }

}
