<?php

namespace App\Models;

use App\Traits\Reads\Readable;
use App\Traits\Reads\ReadableInterface;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BloodGroupMessage extends Model implements ReadableInterface
{
    use HasFactory, Readable;

    protected $appends = ['display_time'];

    //
    public function getCreatedAtAttribute($value): string
    {
        return Carbon::parse($value)->format('Y-m-d H:i:s');
    }

    //
    public function getDisplayTimeAttribute($value): string
    {
        return Carbon::parse($this->created_at)->format('d/m/Y g:i A');
    }

    // group
    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class, 'blood_group_id', 'id');
    }

    // user
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // comments
    public function comments(): HasMany
    {
        return $this->hasMany(GroupComment::class, 'group_message_id', 'id')
            ->where('group_type', 'blood');
    }

    // state
    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }

    // district
    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    // taluka
    public function taluka(): BelongsTo
    {
        return $this->belongsTo(Taluka::class);
    }

    // comment count
    public function getCommentCountAttribute($value): string
    {
        return $this->intWithStyle($value);
    }

    // int with style
    private function intWithStyle($n): string
    {
        if ($n < 1000) return $n . "";
        $suffix = ['', 'k', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
        $power = floor(log($n, 1000));
        return round($n / (1000 ** $power), 1, PHP_ROUND_HALF_EVEN) . $suffix[$power];
    }


}
